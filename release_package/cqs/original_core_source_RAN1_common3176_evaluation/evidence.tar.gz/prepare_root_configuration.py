#!/usr/bin/env python3
"""Assemble actual saved evidence before the new cohort, without model calls."""
from collections import Counter
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
LOOP = HERE.parent
SOURCE = LOOP / 'RAN1_RAN3_RAN4'
NATIVE = LOOP / 'root_RAN1_three_source_variants_common3176_native_v1'
SECOND = LOOP / 'RAN2_RAN5/source_lane13/RAN1_common3176_independent_scorer_and_semantic_audit_v1'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def pin(path):
    path = path.resolve(strict=True)
    return {'path': str(path), 'sha256': sha(path)}


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    cfg = read(HERE / 'root_configuration_TEMPLATE_INCOMPLETE_DO_NOT_EXECUTE.json')
    native_path = NATIVE / 'actual_native_manifest.json'
    native = read(native_path)
    capture_path = NATIVE / 'actual_native_three_column_source_capture.json'
    capture = read(capture_path)
    sql_path = NATIVE / 'actual_immutable_SQL_three_column_reference.json'
    sql = read(sql_path)
    assert sha(capture_path) == native['capture']['sha256']
    assert native['owned_container_stopped'] is True
    assert set(capture) == set(sql['rows']) and len(capture) == 7
    query_checks = []
    for key, outcome in capture.items():
        assert outcome['complete'] and not outcome['truncated'] and outcome['transaction_rolled_back']
        assert outcome['contains_updates'] is False and outcome['actual_query_type'] == 'r'
        # The original DMRS query permits different legal membership at the cutoff.
        is_unordered_dmrs_selection = key == 'RAN1_P2_CQ5-11/selected'
        if not is_unordered_dmrs_selection:
            assert Counter(map(canonical, outcome['rows'])) == Counter(map(canonical, sql['rows'][key])), key
        if key in ('RAN1_P2_CQ5-3/selected', 'RAN1_P2_CQ5-13/selected'):
            assert outcome['rows'] == sql['rows'][key]
        query_checks.append({'key': key, 'native_rows': len(outcome['rows']),
                             'SQL_rows': len(sql['rows'][key]),
                             'whole_multiset_equal': not is_unordered_dmrs_selection,
                             'DMRS_selected_checked_by_original_boundary_policy_below': is_unordered_dmrs_selection})
    sys.path.insert(0, str(HERE / 'scoring'))
    scorer = load(HERE / 'scoring/original_scorer.py', 'root_prospective_scorer')
    reference_checks = []
    for ident, case in cfg['cases'].items():
        rows_path = HERE / 'native_reference' / (ident + '.jsonl')
        rows = [json.loads(line) for line in rows_path.read_text().splitlines() if line]
        lineage_path = rows_path.with_suffix('.lineage.json')
        lineage = read(lineage_path)
        assert lineage['input_capture_sha256'] == sha(capture_path)
        assert lineage['output_sha256'] == sha(rows_path)
        actual = capture[lineage['input_capture_key']]
        aliases = lineage['column_aliases']
        expected = [{aliases.get(name, name): value for name, value in zip(actual['columns'], row)} for row in actual['rows']]
        assert rows == expected
        definition = read(Path(case['definition']['path']))
        projected = [{field['name']: row[field['name']] for field in definition['required_fields']} for row in rows]
        groups = scorer.make_order_groups(definition, rows, projected) if definition['collection']['kind'] == 'top_k_boundary_ties' else None
        selected = capture[ident + '/selected']
        selected_records = [dict(zip(selected['columns'], row)) for row in selected['rows']]
        predicted = [{'resolutionId': row['a.resolutionId']} for row in selected_records]
        value = scorer.score(definition, projected, predicted, diagnostic=True, order_groups=groups)
        assert value['exact'] is True and value['f1'] == 1.0
        reference_checks.append({'id': ident, 'native_reference_rows': len(rows), 'native_selected_score': value,
                                 'lineage': pin(lineage_path), 'reference': pin(rows_path)})
        case['actual_reference_rows'] = dict(pin(rows_path), provenance='actual_owned_native_capture')
    agreement_path = HERE / 'actual_root_saved_native_SQL_and_reference_projection_checks.json'
    save(agreement_path, {'status': 'PASS_ALL_SEVEN_CAPTURE_QUERIES_AND_THREE_NATIVE_REFERENCE_PROJECTIONS',
                          'native_capture': pin(capture_path), 'immutable_SQL_capture': pin(sql_path),
                          'query_checks': query_checks, 'three_reference_checks': reference_checks,
                          'queries_or_values_modified': False, 'API_or_native_or_SQL_calls': 0})
    second_path = SECOND / 'secondary_review_v3/actual_independent_secondary_three_question_review_receipt.json'
    kernel_path = SECOND / 'actual_independent_generic_scorer_and_DMRS_boundary_audit.json'
    fts_path = SOURCE / 'loop121_RAN1_generic_fullgraph_FTS_disjoint_repeat_merge/manifest.json'
    cfg['gate_receipts'] = {
        'whole_native_reference_capture': dict(pin(native_path), assertions=[{'key_path': ['status'], 'equals': native['status']}, {'key_path': ['owned_container_stopped'], 'equals': True}, {'key_path': ['measured_counts', 'total_nodes'], 'equals': 165418}]),
        'whole_independent_SQL_agreement': dict(pin(agreement_path), assertions=[{'key_path': ['status'], 'equals': read(agreement_path)['status']}, {'key_path': ['queries_or_values_modified'], 'equals': False}]),
        'independent_second_seven_unit_semantics': dict(pin(second_path), assertions=[{'key_path': ['status'], 'equals': 'PASS_THREE_INDEPENDENT_SECONDARY_SEMANTIC_REVIEWS_AND_SCHEMA_CHECKS_NOT_ADMITTED'}, {'key_path': ['original_files_unchanged'], 'equals': True}]),
        'generic_and_boundary_scoring_controls': dict(pin(kernel_path), assertions=[{'key_path': ['status'], 'equals': 'PASS_INDEPENDENT_GENERIC_POLICY_AND_SCORE_ORACLES_NOT_INSTALLED'}, {'key_path': ['exhaustive_duplicate_admission_cases'], 'equals': 1458}, {'key_path': ['exhaustive_score_oracle_cases'], 'equals': 2801}, {'key_path': ['unique_pool_old_new_score_equivalence_cases'], 'equals': 1555}]),
        'whole_source_and_FTS_equivalence': dict(pin(fts_path), assertions=[{'key_path': ['status'], 'equals': 'PASS_GENERIC_SOURCE_CORPUS_NOT_MODEL_EVALUATED'}, {'key_path': ['every_wholegraph_fact_reconstructed_and_SQLite_equal'], 'equals': True}, {'key_path': ['added_generic_sourceRecordWindowText_properties'], 'equals': 3176}, {'key_path': ['fact_selection_task_query_answer_inputs'], 'equals': []}]),
    }
    cfg['native_manifest'] = pin(native_path)
    cfg['native_container'] = {'name': native['target']['container'], 'port': 57915,
                               'bolt': native['target']['bolt'], 'run_uuid': native['run_uuid'],
                               'source_sha256': native['source']['sha256'], 'image_id': native['image_id']}
    cfg['trial_directory'] = str(HERE / 'actual_call_trial_v1')
    cfg['budget_usd'] = 8.0
    cfg['budget_is_approximate_guard_not_actual_charge'] = True
    cfg['cost_unknown_policy'] = 'Halt subsequent, not-yet-admitted sends including retries; up to four admitted or in-flight stages can finish; preserve all results and all twelve method items.'
    cfg['ready_for_root_review'] = True
    cfg['scoring_files'] = [pin(HERE / 'scoring' / path.name) for path in (HERE / 'scoring').iterdir() if path.is_file()]
    extra = {Path(__file__), capture_path, sql_path, NATIVE / 'actual_root_full_public_parse_vs_SQL_all_facts.json'}
    for rel in [
        'loop114_RAN1_ten_report_generic_source_text_and_DMRS_tie_proposal_NOT_ADMITTED/evidence',
        'loop116_RAN1_ten_report_generic_text_whole_snapshot_output_only',
        'loop117_generic_top_k_strictly_below_boundary_duplicate_proposal',
        'loop119_three_keyword_CQs_original_authority_and_no_added_new_change_gate',
        'loop121_RAN1_generic_fullgraph_FTS_disjoint_repeat_merge',
        'loop122_three_question_common3176_definitions_and_primary_reviews_NOT_ADMITTED',
    ]:
        for path in (SOURCE / rel).rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix not in ('.sqlite', '.sqlite3', '.ttl'):
                extra.add(path)
    for path in (SECOND / 'secondary_review_v3').rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            extra.add(path)
    extra.add(kernel_path)
    for pattern in ('*.diff', 'native_reference/*.lineage.json'):
        extra.update(HERE.glob(pattern))
    cfg['additional_evidence_files'] = [pin(path) for path in sorted(extra)]
    save(HERE / 'root_configuration.json', cfg)
    print(json.dumps({'status': 'ROOT_CONFIGURATION_ASSEMBLED_NOT_YET_FROZEN_OR_CALLED',
                      'native_SQL_queries_checked': 7, 'source_reference_self_checks': 3,
                      'additional_evidence_files': len(extra), 'budget_guard_usd': cfg['budget_usd'],
                      'original560_admissions': 0, 'API_or_native_or_SQL_calls': 0}))


if __name__ == '__main__':
    main()
