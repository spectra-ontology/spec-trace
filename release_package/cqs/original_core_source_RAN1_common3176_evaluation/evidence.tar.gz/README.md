# RAN1 common3176 saved first15 evaluation replay

This is a separate three-question source-variant cohort; original560 admissions0. The primary first attempt remains all four method macro F1=0 (N=3 each). Three initial Cypher executions failed before database access because ROOT launched isolated Python without installed user-site neo4j. This operational dependency-preflight omission is separate from model behavior.

A separately saved infrastructure-only diagnostic calls the same frozen Cypher executor with identical query/source/reference/scorer bytes in the installed dependency environment. SRS and PUCCH are exact1; DMRS remains CypherSyntaxError0 (diagnostic macro2/3). It does not replace the primary result, pool cohorts, rewrite a query, relax parsing, or make a new model call.

The other primary failures are preserved: three SQL executions return10 rows with no gold overlap; they use the Agreement-to-AgendaItem relationship as if it targeted Meeting. Six retrieval answers contain prose plus fenced JSON and fail the supplied whole-content strict JSON parser. Their inner abstain:false is not a valid parsed answer. No failure is removed from N.

Place the separate source134 evidence directory beside this directory as `../original_core_source_RAN1_common3176`, or supply it explicitly:

```sh
python3 -B -I verify_saved_outputs.py --source-evidence ../original_core_source_RAN1_common3176
```

This command rehashes the closed local inventory and source134 manifest+71 files, maps158 included precall freeze pins (58 shared source pins+100 evaluation-only pins), reconstructs15 exact saved prompts, checks15 attempt0 HTTP200 stop responses and Decimal provider-reported cost $1.463315, applies the unchanged strict parsers, and recomputes12 primary plus3 diagnostic scores. It imports unchanged retrieval source after removing only the two unused ROOT/CORPUS_DIR environment assignments in the in-memory AST; it does not edit source bytes.

Exactly3 large derived source artifacts (TTL, source SQLite and FTS SQLite) are omitted and declared in frozen_path_bridge.json. This verifier does not open them, execute SQL/FTS/Cypher, restore containers, rerun retrieval, or call a provider. Reconstructing source facts is a separate source134 recipe and is not executed here. Source134 literal reproduction is not a claim that all3176 windows are owned technical-topic answers: the known foreign-boundary counterexamples remain included. Bounded retrieval is not whole-answer completeness or equal method exposure. Costs are saved provider reports, not independently verified account balance. Human expert validation N=0.

All frozen source/runtime/requests/responses remain byte-exact. Absolute host paths are retained as historical provenance but never used as fallbacks in this offline replay.
