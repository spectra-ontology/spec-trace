#!/usr/bin/env python3
"""Offline audit of immutable first calls and separate environment-only diagnostics."""
from pathlib import Path
from collections import Counter
from datetime import datetime
from decimal import Decimal
import ast, hashlib, importlib.util, json, re, sqlite3, sys, urllib.request

sys.dont_write_bytecode = True
P=Path("/home/sihyeon/workspace/spectra/logs/pending-tasks/spectracq-core-contract-2026-10-13/empirical/overnight_reaudit/root_evidence/two_agent_unresolved_loop/root_RAN1_common3176_prepared_evaluation_v1")
O=P.parent
T=P/'actual_call_trial_v1'
D=O/'root_RAN1_common3176_saved_query_environment_diagnostic_v1'
OUT=Path(__file__).resolve().parent
def refuse(*args,**kwargs):raise AssertionError('Audit forbids network and database connections')
sqlite3.connect=refuse
urllib.request.urlopen=refuse
def read(p):return json.loads(Path(p).read_text())
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def pin(p):return {'path':str(p),'bytes':Path(p).stat().st_size,'sha256':sha(p)}
def load(p,name):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def save(n,d):
 p=OUT/n
 assert not p.exists()
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

cfg=read(P/'root_configuration.json')
frozen=read(P/'precall_freeze.json')
assert frozen['root_configuration_sha256']==sha(P/'root_configuration.json')
assert len(frozen['pinned_files'])==161
verified=[]
for i in frozen['pinned_files']:
 got=pin(i['path']);assert got['sha256']==i['sha256'] and got['bytes']==i['bytes'];verified.append(got)
assert frozen['N_per_method']==3 and frozen['expected_request_stages']==15
assert frozen['original560_admission_delta']==0 and frozen['quality_retries']==0
primary=read(T/'actual_results_summary.json')
generated=read(T/'generated_before_execution.json')
executed=read(T/'executed_predictions.json')
qfrozen=read(T/'before_execution_queries_frozen.json')
assert qfrozen['generated_record_sha256']==sha(T/'generated_before_execution.json')
assert generated['freeze_sha256']==executed['freeze_sha256']==sha(P/'precall_freeze.json')
assert generated['database_execution_during_generation'] is False
assert set(generated['results'])==set(executed['results'])==set(cfg['cases'])
primary_pins={str(p):sha(p) for p in [P/'precall_freeze.json',P/'root_configuration.json',T/'generated_before_execution.json',T/'executed_predictions.json',T/'actual_results_summary.json']}
structured=load(P/'runtime/structured_adapter.py','independent_saved_structured')
retrieval=load(P/'runtime/retrieval_adapter.py','independent_saved_retrieval')
sys.path.insert(0,str(P/'scoring'))
sys.modules['scorer']=load(P/'scoring/scorer.py','scorer')
scorer=load(P/'scoring/original_scorer.py','independent_saved_original_scorer')
tasks={t['id']:t for t in read(P/'public_tasks.json')}
assert set(tasks)==set(cfg['cases'])
expected_requests={}
prompt_rebuilds=[]
parse_checks=[]
query_checks=[]
retrieval_exposure=[]
MODEL='anthropic/claude-opus-4.8'
PROVIDER='Anthropic'
for ident,task in tasks.items():
 for method in ['Text2Cypher','Text2SQL']:
  public=dict(task)
  public['graph_schema' if method=='Text2Cypher' else 'sql_schema']=read(P/('graph_schema.json' if method=='Text2Cypher' else 'sql_schema.json'))
  expected_requests[ident+'_'+method]=(structured.messages_for(public,method),4096)
 for method in ['C','D']:
  rd=T/'retrieval'/method/ident
  initial=read(rd/'initial_context.json')
  final=read(rd/'final_context.json')
  passages='\n\n'.join(d['formatted'] for d in final['documents'])
  init_passages='\n\n'.join(d['formatted'] for d in initial['documents'])
  for doc in initial['documents']+final['documents']:
   assert hashlib.sha256(doc['formatted'].encode()).hexdigest()==doc['formatted_sha256']
  contract=retrieval.public_contract(task)
  prefix=canonical({'question':task['question_en'],'contract':contract})
  if method=='D':
   expected_requests[ident+'_D_followup']=([{'role':'system','content':retrieval.QUERY_INSTRUCTION},{'role':'user','content':prefix+'\nSOURCE PASSAGES:\n'+init_passages}],1024)
  expected_requests[ident+'_'+method+'_answer']=([{'role':'system','content':retrieval.ANSWER_INSTRUCTION},{'role':'user','content':prefix+'\nSOURCE PASSAGES:\n'+passages}],8192)
  result=read(rd/'result.json')
  assert result==generated['results'][ident][method]==executed['results'][ident][method]
  assert result['source_index_sha256']==cfg['FTS_input']['sha256']
  assert result['status']=='answer_parse_error' and result['records']==[]
  retrieval_exposure.append({'id':ident,'method':method,'context_stats':final['stats'],
    'initial_documents':len(initial['documents']),'final_documents':len(final['documents']),
    'actual_rounds':len(list(rd.glob('retrieval_round_*.json'))),'query_execution_by_auditor':False})
request_files=sorted((T/'calls').glob('*.request.json'))
response_files=sorted((T/'calls').glob('*.response.json'))
assert len(request_files)==len(response_files)==len(expected_requests)==15
assert not list((T/'calls').glob('*.attempt1.*'))
cost=Decimal(0);pt=ct=tt=0;call_checks=[]
for request_path in request_files:
 req=read(request_path);rid=req['request_id'];payload=req['payload']
 msgs,max_tokens=expected_requests[rid]
 assert payload['messages']==msgs
 assert payload['max_tokens']==max_tokens and payload['model']==MODEL
 assert payload['provider']=={'only':[PROVIDER],'allow_fallbacks':False,'require_parameters':True}
 assert payload['response_format']=={'type':'json_object'} and payload['reasoning']=={'enabled':False} and payload['stream'] is False
 assert req['payload_sha256']==hashlib.sha256(json.dumps(payload,ensure_ascii=False).encode()).hexdigest()
 assert datetime.fromisoformat(frozen['utc'])<datetime.fromisoformat(req['created_utc'])
 rawpath=T/'calls'/(rid+'.attempt0.response.json');raw=read(rawpath);resp=raw['response']
 outpath=T/'calls'/(rid+'.outcome.json');out=read(outpath)
 assert raw['request_id']==rid and raw['attempt']==0 and raw['http_status']==200
 assert resp['model']==MODEL and resp['provider']==PROVIDER and len(resp['choices'])==1
 choice=resp['choices'][0];content=choice['message']['content']
 assert choice['finish_reason']=='stop' and out['ok'] and out['content']==content
 assert out['finish_reason']=='stop' and out['model']==MODEL and out['provider']==PROVIDER
 assert out['usage']==resp['usage'] and out['unknown_cost_attempts']==0
 assert out['attempts']==[{'attempt':0,'http_status':200,'response_path':str(rawpath),'retryable':False}]
 exactraw=json.loads(rawpath.read_text(),parse_float=Decimal);usd=exactraw['response']['usage']['cost']
 assert usd==Decimal(str(out['known_actual_cost_usd']))
 cost+=usd
 u=resp['usage'];assert u['total_tokens']==u['prompt_tokens']+u['completion_tokens']
 pt+=u['prompt_tokens'];ct+=u['completion_tokens'];tt+=u['total_tokens']
 prompt_rebuilds.append({'request_id':rid,'messages_exact':True,'payload_sha256':req['payload_sha256'],'max_tokens':max_tokens})
 call_checks.append({'request_id':rid,'request':pin(request_path),'raw_response':pin(rawpath),'outcome':pin(outpath),
   'attempt':0,'http_status':200,'stop':choice['finish_reason'],'model':resp['model'],'provider':resp['provider'],
   'prompt_tokens':u['prompt_tokens'],'completion_tokens':u['completion_tokens'],'total_tokens':u['total_tokens'],
   'cost_usd_decimal':str(usd),'transport_retry':False})
 if rid.endswith('_answer'):
  try:retrieval.parse_answer(content)
  except (ValueError,TypeError,KeyError) as e:parse_error=type(e).__name__
  else:raise AssertionError('Frozen strict parser unexpectedly accepted prose')
  diagnostic_fence=re.search(r'```json\s*(.*?)\s*```',content,re.S)
  diagnostic_value=json.loads(diagnostic_fence.group(1)) if diagnostic_fence else None
  parse_checks.append({'request_id':rid,'actual_frozen_parser_error':parse_error,'prose_before_fence':content[:content.find('```')].strip()!='',
   'fenced_JSON_present':bool(diagnostic_fence),'unaccepted_inner_abstain':diagnostic_value.get('abstain') if diagnostic_value else None,
   'unaccepted_inner_complete':diagnostic_value.get('complete') if diagnostic_value else None,
   'inner_JSON_inspection_for_self_report_only_not_relaxed_prediction':True,'retained_prediction_records':0})
 elif rid.endswith('_D_followup'):
  obj=json.loads(content)
  assert set(obj)=={'query'} and type(obj['query']) is str and obj['query'].strip()
  rd=T/'retrieval'/'D'/rid.removesuffix('_D_followup')
  second=read(rd/'retrieval_round_2.json')
  parse_checks.append({'request_id':rid,'strict_followup_query_envelope_valid':True,'query':obj['query'],
    'second_retrieval_saved':bool(second),'second_retrieval_newly_executed_by_auditor':False})
 else:
  obj=json.loads(content)
  assert set(obj)=={'query','abstain'} and type(obj['query']) is str and obj['abstain'] is False
  ident,method=rid.rsplit('_',1)
  gen=generated['results'][ident][method];exe=executed['results'][ident][method]
  assert gen==read(T/'predictions'/method/(ident+'.json'))
  assert gen['generated_query']==exe['generated_query']==obj['query']
  qsha=hashlib.sha256(obj['query'].encode()).hexdigest()
  assert qsha==gen['query_sha256']==exe['query_sha256']==qfrozen['queries'][ident][method]
  assert gen['status']=='QUERY_READY' and gen['abstain'] is False and gen['execution'] is None
  assert gen['prompt_sha256']==hashlib.sha256(canonical(msgs).encode()).hexdigest()
  if method=='Text2Cypher':
   assert exe['execution']=={'status':'ERROR','complete':False,'rows':[],'error_class':'ModuleNotFoundError'}
   assert exe['status']=='EXECUTION_ERROR' and exe['abstain'] is True
   assert not (T/'native_stage_events'/(ident+'.json')).exists()
  else:
   assert exe['status']=='OK' and exe['execution']['complete'] is True and len(exe['records'])==10
   assert exe['execution']['immutable_read_only'] is True
   receipt=gen['physical_SQL_interface_before_model_call']
   assert receipt['status']=='PASS_FULL_PHYSICAL_SQL_INTERFACE_BEFORE_GENERATION'
   assert receipt['database_sha256']==cfg['SQL_input']['sha256']
   assert 'rel_RESOLUTION_BELONGS_TO' in obj['query'] and re.search(r'\bJOIN\s+Meeting\s+\w+', obj['query'])
  query_checks.append({'id':ident,'method':method,'query':obj['query'],'query_sha256':qsha,
    'unchanged_raw_to_generation_to_execution_to_freeze':True,'model_reported_abstain':obj['abstain'],
    'primary_wrapper_abstain':exe['abstain'],'primary_execution_status':exe['execution']['status'],
    'primary_error_class':exe['execution'].get('error_class'),'source_DB_reexecution_by_auditor':False})
assert cost==Decimal('1.463315')
assert Decimal(str(primary['usage']['known_actual_cost_usd']))==cost
assert primary['usage']==read(T/'usage.json')==generated['usage']
assert primary['usage']['received_response_calls']==15 and primary['usage']['unknown_cost_attempts']==0

primary_scores=[];diagnostic_scores=[]
diag=read(D/'actual_environment_only_diagnostic_scores.json')
plan=read(D/'pre_execution_diagnostic_plan.json')
assert plan['new_model_calls']==0 and diag['model_calls']==0 and diag['query_bytes_changed'] is False
wrapper=O/'root_RAN1_common3176_saved_query_environment_diagnostic.py'
assert sha(wrapper)==plan['wrapper_sha256']
tree=ast.parse(wrapper.read_text())
# Static provenance: the diagnostic calls the frozen runner; it does not copy or rewrite query text.
assert any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name)
           and n.func.value.id=='runner' and n.func.attr=='execute_cypher' for n in ast.walk(tree))
for p,h in diag['original_primary_pins_unchanged'].items():assert sha(p)==h
for ident,case in cfg['cases'].items():
 definition=read(case['definition']['path'])
 refs=[json.loads(s) for s in Path(case['actual_reference_rows']['path']).read_text().splitlines() if s]
 projected=[{f['name']:r[f['name']] for f in definition['required_fields']} for r in refs]
 groups=scorer.make_order_groups(definition,refs,projected) if definition['collection']['kind']=='top_k_boundary_ties' else None
 for method in ['Text2Cypher','Text2SQL','C','D']:
  pred=executed['results'][ident][method]
  valid=pred['status'] in {'OK','ok','partial'} and not pred.get('abstain',False)
  rows=pred.get('records',[]) if valid else []
  score=scorer.score(definition,projected,rows,diagnostic=True,order_groups=groups)
  saved=next(r for r in primary['results'] if r['id']==ident and r['method']==method)
  assert score==saved['score'] and saved['valid_answer']==valid and saved['failure_remains_in_denominator'] is True
  assert score['f1']==0 and score['exact'] is False
  primary_scores.append({'id':ident,'method':method,'status':pred['status'],'retained_records':len(rows),'recomputed_score':score})
 outcome=read(D/(ident+'.execution.json'))
 stage=read(D/(ident+'.stages.json'))
 assert outcome['rollback_completed'] is True
 assert [e['stage'] for e in stage['events']]==['owned_stopped_before_start','owned_running_after_start','owned_stopped_after_execution']
 assert stage['result_status']==outcome['status']
 row=next(r for r in diag['results'] if r['id']==ident)
 assert row['unchanged_query_sha256']==generated['results'][ident]['Text2Cypher']['query_sha256']
 ds=scorer.score(definition,projected,outcome['rows'] if outcome['complete'] else [],diagnostic=True,order_groups=groups)
 assert ds==row['score']
 if ident.endswith('-11'):assert outcome['status']=='ERROR' and outcome['error_class']=='CypherSyntaxError' and ds['f1']==0
 else:assert outcome['status']=='OK' and outcome['inventory_before']=={'nodes':165418,'relationships':848228} and ds['exact'] is True
 diagnostic_scores.append({'id':ident,'query_sha256':row['unchanged_query_sha256'],'execution':pin(D/(ident+'.execution.json')),
   'stages':pin(D/(ident+'.stages.json')),'root_execution_attribution':True,'new_native_executions_by_this_auditor':0,
   'recomputed_score':ds,'error_class':outcome.get('error_class')})
assert len(primary_scores)==12 and len(diagnostic_scores)==3
assert sum(d['recomputed_score']['f1'] for d in diagnostic_scores)/3==diag['Text2Cypher_diagnostic_macro']['f1']
assert primary_pins=={p:sha(p) for p in primary_pins}
all_trial_pins=[pin(p) for p in sorted(T.rglob('*')) if p.is_file()]
save('actual_saved_outputs_prompts_cost_and_primary_scores_independent_audit.json',{
 'status':'PASS_OFFLINE_INDEPENDENT_SAVED_FIRST15_AND_ENVIRONMENT_DIAGNOSTIC_AUDIT',
 'cohort':'RAN1_common3176_three_question_source_variant','separate_from_original560':True,'original560_admissions':0,
 'freeze':pin(P/'precall_freeze.json'),'all161_frozen_files_exact':True,'verified_pre_call_pins':verified,
 'primary_input_pins_unchanged':primary_pins,'request_stages':15,'attempts':15,'HTTP200':15,'stop':15,
 'quality_retries':0,'transport_retries':0,'known_actual_cost_usd_exact_decimal':str(cost),'unknown_cost_attempts':0,
 'provider_usage_tokens':{'prompt_tokens':pt,'completion_tokens':ct,'total_tokens':tt},
 'budget_usd':8,'budget_is_approximate_guard_not_actual_charge_or_live_balance':True,
 'actual_call_checks':call_checks,'exact_prompt_rebuilds':prompt_rebuilds,'strict_parser_checks':parse_checks,
 'frozen_query_lineage':query_checks,'saved_retrieval_context_checks':retrieval_exposure,
 'recomputed_primary_scores':primary_scores,
 'primary_macro':primary['macro'],'primary_all_four_F1_zero_preserved':True,
 'failure_attribution':{
  'three_primary_Cypher':'Operational environment failure: python -I hides installed user-site neo4j; ModuleNotFoundError before any native stage event. This is not model abstention or evidence that the three generated queries all fail.',
  'three_SQL':'Saved read-only SQL executions complete10 rows each; generated SQL joins rel_RESOLUTION_BELONGS_TO directly to Meeting although graph-directed metadata defines it to AgendaItem and MADE_AT to Meeting. Physical SQL DDL was checked before requests. Zero record overlap is reproduced offline. No rewritten SQL is executed here; schema correctness does not establish equal interface semantic exposure.',
  'six_retrieval':'Prose plus fenced JSON violates the supplied strict JSON-only format even though provider finish_reason=stop and request response_format=json_object. All six fixed parsers reject; inner fenced abstain flags are inspection-only and do not become predictions. Model abstain false is distinct from parser failure and wrapper operational abstain.',
  'denominator':'All12 method-items remain, N3 per method, including3 operational errors and6 parse failures.'},
 'separate_environment_only_diagnostic':{
  'status':'ROOT_ATTRIBUTED_INFRASTRUCTURE_DIAGNOSTIC_NOT_PRIMARY_REPLACEMENT_OR_NEW_SCIENTIFIC_COHORT',
  'plan':pin(D/'pre_execution_diagnostic_plan.json'),'wrapper':pin(wrapper),
  'actual_summary':pin(D/'actual_environment_only_diagnostic_scores.json'),'recomputed_scores':diagnostic_scores,
  'Text2Cypher_macro':diag['Text2Cypher_diagnostic_macro'],
  'interpretation':'Same frozen function/query/input/reference/scorer, changed dependency visibility only. SRS and PUCCH exact1; DMRS actual CypherSyntaxError0. SQL/C/D primary results are not changed. No performance pooling or quality regeneration.'},
 'limitations':['No provider endpoint called by this auditor; costs are saved provider-reported charges, not independently provider-billed balance.',
                'No source SQLite connection, FTS search, Cypher, container or native execution by this auditor. Root execution provenance and saved outputs are read/recomputed only.',
                'Source semantic seven-unit judgments are separately pinned; this audit does not promote original questions or remove pending gates.',
                'Whole shared graph facts are not equal context/exposure, complete retrieval or causal method comparison.',
                'Exact prompts checked from frozen adapters and saved contexts; full source retrieval/window selection was not rerun.'],
 'trial_file_inventory':all_trial_pins,'script':pin(Path(__file__)),
 'mutations':{'paid_calls':0,'network_calls':0,'SQL_connections':0,'native_calls':0,'runtime_changes':0,'source_changes':0,'central':0,'public':0},
 'human_expert_reviews':0})
print(json.dumps({'status':'PASS','receipt':pin(OUT/'actual_saved_outputs_prompts_cost_and_primary_scores_independent_audit.json'),'cost':str(cost),'prompts':15,'primary_items':12,'diag_exact':2}))

