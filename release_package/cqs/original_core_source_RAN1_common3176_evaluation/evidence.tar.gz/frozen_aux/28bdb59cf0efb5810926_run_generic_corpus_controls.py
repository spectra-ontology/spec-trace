#!/usr/bin/env python3
"""Exercise generic identity, direction, formatting and lossless chunk bounds."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sqlite3
import subprocess
import sys

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('generic_corpus_control_target', HERE / 'build_generic_graph_corpus.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def main():
    lexer = Path(sys.argv[1]).resolve()
    output = HERE / 'actual_generic_controls'
    assert not output.exists()
    output.mkdir()
    checks = []
    def check(name, condition):
        assert condition, name
        checks.append({'control': name, 'pass': True})
    for length in (1, 3999, 4000, 4001, 7800, 7801, 12003):
        text = ('가"\\\n🌏ab' * (length // 7 + 1))[:length]
        # Construct by code-point count, not byte count or grapheme count.
        text = (text + 'x' * length)[:length]
        spans = list(module.chunks(text))
        recovered = spans[0][3] + ''.join(span[3][module.OVERLAP:] for span in spans[1:])
        check('unicode_lossless_chunk_length_' + str(length), recovered == text and
              spans[0][1] == 0 and spans[-1][2] == length and
              all(len(payload) <= module.CHARS for _, _, _, payload in spans))
    record = {'iri': 'https://w3id.org/spectra/inst/TEST/Entity/alpha', 'labels': ['Entity'],
              'properties': {'short': 'x' * 254, 'long': 'y' * 255, 'arbitraryKey': 7,
                             'array': ['first', 'second'], 'false': False}}
    ep = module.endpoint(record)
    check('endpoint_generic_scalar_budget_and_no_key_whitelist',
          ep['identity_context'] == {'short': 'x' * 254, 'arbitraryKey': 7, 'false': False})
    check('own_properties_never_filtered_by_endpoint_budget',
          json.loads(module.serialize_node(record, [], {}))['properties'] == record['properties'])
    long_value = ('한글 "quoted" \\ slash\n' * 600)
    strings = lambda value: json.dumps(value, ensure_ascii=False)
    ttl = output / 'generic_boundary_fixture.ttl'
    ttl.write_text('@prefix spectra: <https://w3id.org/spectra/ontology/> .\n'
                   '@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\n'
                   '<https://w3id.org/spectra/inst/TEST/Entity/beta> rdf:type spectra:Entity ; spectra:title "Target identity" .\n'
                   '<https://w3id.org/spectra/inst/TEST/Entity/alpha> rdf:type spectra:Entity, spectra:Alias ; '
                   'spectra:arbitraryKey "opaque" ; spectra:content ' + strings(long_value) + ' ; '
                   'spectra:enabled false ; spectra:ratio 1.25 ; spectra:items "two", "one" ; '
                   'spectra:linksTo <https://w3id.org/spectra/inst/TEST/Entity/beta>, <https://w3id.org/spectra/inst/TEST/Entity/alpha> .\n', encoding='utf-8')
    data = output / 'fixture_corpus'
    command = [sys.executable, '-B', str(HERE/'build_generic_graph_corpus.py'), 'build', '--ttl', str(ttl),
               '--ttl-sha256', module.sha(ttl), '--lexer', str(lexer), '--output', str(data)]
    build = subprocess.run(command, capture_output=True, text=True)
    (output/'fixture_build.stdout').write_text(build.stdout)
    (output/'fixture_build.stderr').write_text(build.stderr)
    check('full_fixture_build', build.returncode == 0)
    command[3] = 'verify'
    replay = subprocess.run(command, capture_output=True, text=True)
    (output/'fixture_verify.stdout').write_text(replay.stdout)
    (output/'fixture_verify.stderr').write_text(replay.stderr)
    check('full_fixture_all_fact_reverse_reconstruction', replay.returncode == 0)
    proof = json.loads((data/'all_fact_reconstruction_receipt.json').read_text())
    check('fixture_multilabel_long_prose_array_false_float_self_edge_and_direction',
          proof['nodes_reconstructed'] == 2 and proof['edges_reconstructed'] == 2 and proof['chunks_reconstructed'] > 2)
    connection = sqlite3.connect((data/'test.sqlite3').resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
    count = connection.execute("SELECT count(*) FROM search WHERE search MATCH 'arbitraryKey'").fetchone()[0]
    check('FTS_indexes_arbitrary_nonselected_property', count > 0)
    connection.close()
    receipt = {'status': 'PASS', 'controls': checks, 'controls_n': len(checks),
               'fixture_sha256': module.sha(ttl), 'builder_sha256': module.sha(HERE/'build_generic_graph_corpus.py'),
               'API_native_public_operational_mutations': 0}
    module.write_new(output/'receipt.json', receipt)
    print(module.canonical(receipt))


if __name__ == '__main__':
    main()
