#!/usr/bin/env python3
"""Run an output-only corpus worker under explicit host and process limits."""
from pathlib import Path
import hashlib,json,os,re,resource,subprocess,sys,time
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'loop116_RAN1_ten_report_generic_text_whole_snapshot_output_only/RAN1_source_record_text.ttl'
LEXER=Path('/home/sihyeon/workspace/spectra-public/spec-trace/release_package/pipeline/load_released_kg.py')
GiB=1024**3
mode=sys.argv[1];assert mode in {'build','verify'}
receipt=HERE/('guarded_'+mode+'_receipt.json');assert not receipt.exists()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def linux_available():
 return int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
def windows_available():
 r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command','(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'],capture_output=True,text=True,timeout=20)
 assert r.returncode==0,r.stderr
 s=r.stdout.strip();assert re.fullmatch(r'\d+',s),repr(s)
 return int(s)*1024
initial={'Linux_available_bytes':linux_available(),'Windows_available_bytes':windows_available()}
assert min(initial.values())>=26*GiB,initial
cpu=min(os.sched_getaffinity(0))
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(8*GiB,8*GiB))
 os.sched_setaffinity(0,{cpu})
command=[sys.executable,'-B','-I',str(HERE/'build_generic_graph_corpus.py'),mode,'--ttl',str(SOURCE),'--ttl-sha256',sha(SOURCE),'--lexer',str(LEXER),'--output',str(HERE/'actual_corpus')]
env=dict(os.environ);env.update({'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','NUMEXPR_NUM_THREADS':'1'})
began=time.monotonic();samples=[];reason=None
with (HERE/(mode+'.stdout')).open('x') as so,(HERE/(mode+'.stderr')).open('x') as se:
 child=subprocess.Popen(command,stdout=so,stderr=se,env=env,preexec_fn=limits)
 print(json.dumps({'status':'STARTED','mode':mode,'worker_pid':child.pid,'initial_memory':initial,'AS_cap_bytes':8*GiB,'CPU_affinity':[cpu]}),flush=True)
 last_windows=time.monotonic();win=initial['Windows_available_bytes']
 while child.poll() is None:
  linux=linux_available()
  if time.monotonic()-last_windows>=10:
   try:win=windows_available()
   except Exception as exc:reason='Windows memory recheck failed: '+repr(exc);child.terminate();break
   last_windows=time.monotonic()
  samples.append({'elapsed_seconds':round(time.monotonic()-began,3),'Linux_available_bytes':linux,'Windows_available_bytes':win})
  if min(linux,win)<16*GiB:
   reason='Host16GiB reserve watchdog triggered';child.terminate();break
  time.sleep(2)
 try:code=child.wait(timeout=20)
 except subprocess.TimeoutExpired:child.kill();code=child.wait()
r={'status':'PASS' if code==0 and reason is None else 'FAIL_PRESERVED','mode':mode,'command':command,'returncode':code,'guard_failure_reason':reason,'initial_memory':initial,'prestart_minimum_available_bytes':26*GiB,'watchdog_minimum_available_bytes':16*GiB,'AS_cap_bytes':8*GiB,'CPU_affinity':[cpu],'memory_samples':samples,'elapsed_seconds':time.monotonic()-began,'root_native_isolation':'Root reported ownednative stopped and no simultaneous native scheduled before worker startup.','new_corpus_output_only':True,'model_API_native_calls':0,'public_changes':0}
receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'returncode':code,'guard_failure_reason':reason,'receipt_sha256':sha(receipt)}),flush=True)
assert r['status']=='PASS'
