#!/usr/bin/env python3
"""Challenge lossless repeated-subject merges without task or answer inputs."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('generic_builder',HERE/'build_generic_graph_corpus.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
lexer=m.load_lexer(Path(sys.argv[1]));out=HERE/'actual_repeated_subject_controls_v2';out.mkdir(exist_ok=False)
head='@prefix spectra: <https://w3id.org/spectra#> .\n@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\n'
a='<https://w3id.org/spectra/inst/TEST/Entity/a>';b='<https://w3id.org/spectra/inst/TEST/Entity/b>'
base=a+' rdf:type spectra:Entity ; spectra:title "first" ; spectra:enabled true .\n'+b+' rdf:type spectra:Entity ; spectra:title "second" .\n'
fixtures=[
 ('disjoint_source_string',base+a+' spectra:sourceRecordWindowText "arbitrary source prose" .\n',False),
 ('equal_string_repeat',base+a+' spectra:title "first" .\n',False),
 ('label_union',base+a+' rdf:type spectra:Alias .\n',False),
 ('edge_union_and_duplicate_edge',base+a+' spectra:linksTo '+b+' .\n'+a+' spectra:linksTo '+b+' .\n',False),
 ('before_type_property_first',a+' spectra:extra "first subject fragment" .\n'+base,False),
 ('same_statement_equal_property',base+a+' spectra:title "first" ; spectra:title "first" .\n',False),
 ('equal_multiple_literal_repeat',base+a+' spectra:items "a", "b" .\n'+a+' spectra:items "b", "a" .\n',False),
 ('conflicting_string_rejected',base+a+' spectra:title "different" .\n',True),
 ('bool_integer_conflict_rejected',base+a+' spectra:enabled 1 .\n',True),
 ('string_integer_conflict_rejected',base+a+' spectra:title 7 .\n',True),
 ('multiple_literal_change_rejected',base+a+' spectra:items "a", "b" .\n'+a+' spectra:items "a", "c" .\n',True),
 ('same_statement_conflict_rejected',base+a+' spectra:extra "a" ; spectra:extra "b" .\n',True),
 ('unbound_edge_endpoint_rejected',base+a+' spectra:linksTo <https://w3id.org/spectra/inst/TEST/Entity/missing> .\n',True),
]
checks=[]
for name,text,error in fixtures:
 p=out/(name+'.ttl');p.write_text(head+text)
 read_error=None
 try:
  nodes,edges=m.read_graph(p,lexer)
 except Exception as exc:
  read_error=exc
 if error:
  assert read_error is not None,name+': conflict unexpectedly accepted'
  checks.append({'check':name,'pass':True,'expected_rejection':True,'exception_type':type(read_error).__name__,'message':str(read_error)})
 else:
  assert read_error is None,name+': '+str(read_error)
  parsed_nodes,parsed_edges,stats=lexer.parse_ttl(p)
  actual={}
  for iri,row in nodes.items():
   match=lexer.INST_RE.fullmatch(iri);key=(match.group('cls'),match.group('nid'))
   actual[key]={'labels':set(row['labels']),'props':row['properties']}
  assert m.canonical({str(k):{'labels':sorted(v['labels']),'props':v['props']} for k,v in actual.items()})==m.canonical({str(k):{'labels':sorted(v['labels']),'props':v['props']} for k,v in parsed_nodes.items()})
  keys={iri:(lexer.INST_RE.fullmatch(iri).group('cls'),lexer.INST_RE.fullmatch(iri).group('nid')) for iri in nodes}
  assert {(keys[s],r,keys[t]) for s,r,t in edges}==parsed_edges
  checks.append({'check':name,'pass':True,'nodes':len(nodes),'edges':len(edges),'all_facts_public_parser_equal':True})
result={'status':'PASS','controls':checks,'controls_n':len(checks),'builder_sha256':m.sha(HERE/'build_generic_graph_corpus.py'),'no_query_or_answer_inputs':True,'previous_v1_control_harness_preserved':'v1 used an in-try success assertion; v2 places expected-failure assertion outside the exception capture so false acceptance cannot pass. Actual prior exceptions were real but v2 is the authoritative control replay.'}
m.write_new(out/'receipt.json',result);print(m.canonical(result))
