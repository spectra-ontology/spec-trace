"""Independent source-semantic reviews; ZIP/XML and saved-result reads only.

No native/container, SQL, API, registry or public writes. All new files stay here.
"""
import collections
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import zipfile
from xml.etree import ElementTree as ET

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
AUDIT = HERE.parent
ROOT = Path('/home/sihyeon/workspace/spectra')
O = ROOT/'logs/pending-tasks/spectracq-core-contract-2026-10-13/empirical/overnight_reaudit/root_evidence/two_agent_unresolved_loop'
U = O/'RAN1_RAN3_RAN4'
D = U/'loop122_three_question_common3176_definitions_and_primary_reviews_NOT_ADMITTED'
E = U/'loop114_RAN1_ten_report_generic_source_text_and_DMRS_tie_proposal_NOT_ADMITTED/evidence'
AUTHOR = U/'loop85_RAN1_technical_topics_original_authority_and_dependencies'
L119 = U/'loop119_three_keyword_CQs_original_authority_and_no_added_new_change_gate/three_original_authorities_and_semantic_judgments.json'
P = Path('/home/sihyeon/workspace/spectra-public/spec-trace/release_package')
C = P/'cqs/original_core_repair'
N = O/'root_RAN1_three_source_variants_common3176_native_v1'
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
M = '{http://schemas.openxmlformats.org/officeDocument/2006/math}'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def pin(path):
    path=Path(path)
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':sha(data)}

def save(name,value):
    path=HERE/name
    assert not path.exists(), 'Private output already exists; use a new directory/version'
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    return pin(path)

def literal(element):
    return ''.join(x.text or '' for x in element.iter() if x.tag in (W+'t',M+'t'))

def unpack_rows(path):
    return [json.loads(x) for x in gzip.decompress(path.read_bytes()).decode().splitlines()]

def tokens(rows):
    return collections.Counter(json.dumps(x,ensure_ascii=False,sort_keys=True) for x in rows)

manifest=read(D/'manifest.json')
before={str(p):pin(p) for p in [D/'manifest.json',L119,C/'criteria.json',C/'original_scorer.py',C/'scorer.py',C/'typed_values.py',P/'cqs/spectra_cq_v2.0/questions.json']}
for ent in manifest['cases']:
    for key in ('definition','primary_review'):
        item=ent[key]
        p=ROOT.parent/item['path']
        assert pin(p)['sha256']==item['sha256'] and p.stat().st_size==item['bytes']
for item in manifest['source_evidence']:
    p=ROOT.parent/item['path']
    assert pin(p)['sha256']==item['sha256'] and p.stat().st_size==item['bytes']
criteria=read(C/'criteria.json')
units=criteria['semantic_units']
assert len(units)==7
criteria_sha=pin(C/'criteria.json')['sha256']
assert criteria_sha=='bfefc447de02b451da33e0c85afb2708cf6ca7a201fedf07ec4d5b984d492fa4'
spec=importlib.util.spec_from_file_location('private_schema',C/'review_schema.py')
schema=importlib.util.module_from_spec(spec)
spec.loader.exec_module(schema)
public_questions={x['id']:x for x in read(P/'cqs/spectra_cq_v2.0/questions.json')['cqs']}

# Source authority excerpts are literal, line-numbered copies; contrary defaults are retained.
authority=[]
for filename,expected,ranges in [
 ('design_HEAD.md','f414f22f296888e870ffc71d60ad86c484f8dfd3bfb4b58db17a97bd5a45a9e5',[(133,155),(159,187),(968,1004),(1746,1771)]),
 ('validation_HEAD.md','b6be960f3c5bebd439161059ed4e61940b5d656fc54d87bcebbb87870bd3fcbd',[(100,116)])]:
    path=AUTHOR/filename
    assert pin(path)['sha256']==expected
    lines=path.read_text().splitlines()
    authority.append({'file':pin(path),'excerpts':[{'first_line':lo,'last_line':hi,'literal_lines':lines[lo-1:hi]}for lo,hi in ranges]})
authority_pin=save('actual_original_authority_excerpts.json',{'status':'EXACT_LINE_EXCERPTS_WITH_CONTRARY_DEFAULTS_PRESERVED','sources':authority,'loop119':pin(L119)})

# Four technically broad or nested cases are freshly reopened from three physical archives.
em=read(E/'manifest.json')
geometry={x['resolutionId']:x for x in unpack_rows(E/em['geometry'])}
patch={x['resolutionId']:x['sourceRecordWindowText']for x in unpack_rows(E/em['property_patch'])}
assert len(geometry)==len(patch)==3176
chosen=['AGR-123-7-011','AGR-123-8.7.2-006','AGR-117-8.1-044','AGR-119-9.3.3-011']
source_by_meeting={x['meeting']:x for x in em['source_documents']}
bodies={};opened=[];replayed=[]
for meeting in sorted({geometry[q]['meeting']for q in chosen}):
    src=source_by_meeting[meeting]
    path=ROOT/src['original_archive']['path']
    assert pin(path)['sha256']==src['original_archive']['sha256']
    with zipfile.ZipFile(path)as z:
        info=z.getinfo(src['original_archive']['member'])
        docx=z.read(info)
    assert sha(docx)==src['original_DOCX_sha256']
    with zipfile.ZipFile(io.BytesIO(docx))as z:
        xml=z.read('word/document.xml');styles=z.read('word/styles.xml')
    assert sha(xml)==src['document_XML_sha256'] and sha(styles)==src['styles_XML_sha256']
    bodies[meeting]=list(ET.fromstring(xml).find(W+'body'))
    opened.append({'meeting':meeting,'archive':pin(path),'member':info.filename,'member_bytes':info.file_size,'member_CRC32':f'{info.CRC:08x}','member_sha256':sha(docx),'document_xml_sha256':sha(xml),'styles_xml_sha256':sha(styles),'ZIP_read_CRC_validated':True})
for qid in chosen:
    g=geometry[qid];body=bodies[g['meeting']];start,end=g['source_record_raw_body_child_range']
    txt='\n'.join(literal(e)for e in body[start:end])
    assert txt==patch[qid] and sha(txt.encode())==g['source_record_literal_sha256']
    assert literal(body[start]).strip().lower().startswith('agreement')
    replayed.append({'resolutionId':qid,'geometry':g,'literal_text':txt,'literal_sha256':sha(txt.encode()),'raw_own_body_XML_sha256':sha(b''.join(ET.tostring(e)for e in body[start:end])),'preceding_two_blocks':[literal(e)for e in body[max(0,start-2):start]],'following_two_blocks':[literal(e)for e in body[end:end+2]],'fresh_direct_XML_read':True})
fresh_pin=save('actual_four_counterreading_own_windows_from_three_original_ZIPs.json',{'status':'PASS_FOUR_EXACT_OWN_WINDOW_LITERAL_REPLAYS','opened_sources':opened,'windows':replayed,'limits':['Only four counterreading windows were freshly replayed here; broader source/formatting evidence is explicitly reused and pinned.','Literal own-record retrieval includes endorsed background clauses; no newly-changed-topic interpretation is asserted.','Nested Agreement in endorsed LS remains part of its existing stable outer identity; no new IDs created.'],'native_calls':0,'SQL_calls':0,'API_calls':0})

# Root-owned actual native results are inspected, not rerun or relabelled as ours.
native_manifest=read(N/'actual_native_manifest.json')
assert pin(N/'actual_native_manifest.json')['sha256']=='8f59a7fc59217821136061066e4025f4bf45254bca3bbad41d4b72fc220fe1bf'
capture_path=Path(native_manifest['capture']['path'])
assert pin(capture_path)['sha256']==native_manifest['capture']['sha256']
capture=read(capture_path)
assert native_manifest['new_model_calls']==native_manifest['question_admissions']==0
assert native_manifest['owned_container_stopped'] is True
assert native_manifest['parse_inventory']['nodes']==native_manifest['measured_counts']['total_nodes']==165418
assert native_manifest['parse_inventory']['relationships']==sum(native_manifest['measured_counts']['rel_counts'].values())==848228
assert native_manifest['parse_inventory']['relations']==native_manifest['measured_counts']['rel_counts']
assert native_manifest['parse_inventory']['labels']==native_manifest['measured_counts']['label_counts']
sql_pool={x['id']:x for x in read(D/'actual_whole_SQL_pool_changes_and_unchanged_two_selected_prefixes.json')['comparisons']}
dmrs=read(U/'loop114_RAN1_ten_report_generic_source_text_and_DMRS_tie_proposal_NOT_ADMITTED/actual_full_graph_coalesce_selection_proof_NOT_NATIVE_GOLD.json')
native_checks=[]
for key,cap in capture.items():
    assert cap['EXPLAIN_query_type']==cap['actual_query_type']=='r'
    assert not cap['contains_updates'] and cap['complete'] and not cap['truncated'] and cap['transaction_rolled_back']
    assert cap['row_n']==len(cap['rows'])
for qid in ['RAN1_P2_CQ5-3','RAN1_P2_CQ5-13','RAN1_P2_CQ5-11']:
    selected=capture[qid+'/selected'];whole=capture[qid+'/whole_matching_pool']
    sql=dmrs['complete_conditional_query_rows']if qid.endswith('-11')else sql_pool[qid]['complete_new_conditional_pool_NOT_NATIVE']
    if qid.endswith('-11'):
        assert tokens([[r[0],r[1]]for r in whole['rows']])==tokens([[r['meetingNumber'],r['resolutionId']]for r in sql])
        own_text_rows=0
        for row in whole['rows']:
            if row[1] in patch:
                assert row[2]==patch[row[1]]
                own_text_rows+=1
        projected=None
    else:
        projected=[[r['meetingNumber'],r['resolutionId'],r['content']]for r in sql]
        assert tokens(whole['rows'])==tokens(projected)
    assert len(selected['rows'])==10
    d=read(D/(qid+'_common3176_definition.json'))
    if qid.endswith('-11'):
        full=capture[qid+'/scorer_full_pool']
        assert full['literal_query']==d['reference_query']
        assert tokens([[r[0],r[1],r[3]]for r in full['rows']])==tokens([[r['meetingNumber'],r['resolutionId'],r['meetingNumberInt']]for r in sql])
        ids=[r[1]for r in selected['rows']]
        above=set(dmrs['required_above_boundary_IDs']);boundary=set(dmrs['boundary_candidate_IDs'])
        assert len(ids)==len(set(ids))==10 and above<=set(ids) and len(set(ids)&boundary)==2 and set(ids)<=above|boundary
    else:
        assert selected['literal_query']==d['reference_query']
        assert selected['rows']==projected[:10]
    native_checks.append({'id':qid,'selected_rows':10,'full_pool_rows':len(sql),'whole_saved_SQL_comparison':('Complete meeting/ID/rank multiset plus '+str(own_text_rows)+' source-enriched row texts; older fallback text not independently recomputed here'if qid.endswith('-11')else'Complete meeting/ID/content multiset'),'exact_definition_reference_query_observed':True,'comparison_executed_here':'Saved JSON only, no SQL/native queries'})
native_pin=save('actual_saved_root_native_capture_independent_comparison.json',{'status':'PASS_SAVED_ROOT_NATIVE_CAPTURE_VS_PRIOR_FULL_SQL_POOLS','root_manifest':pin(N/'actual_native_manifest.json'),'capture':pin(capture_path),'checks':native_checks,'attribution':'Root executed native; child rehashed and compared saved results only. DMRS prior SQL witness has membership/rank and an enrichment flag, not complete content; all112 membership/rank matches and every new-property text matches the source patch, while older fallback text is not independently recomputed here. Semantic authority is assessed separately.','native_calls_by_this_audit':0,'SQL_calls_by_this_audit':0,'API_calls':0})

review_pins=[]
for case in manifest['cases']:
    qid=case['id'];d=read(D/(qid+'_common3176_definition.json'));q=d['question_en'];is_dmrs=qid.endswith('-11')
    assert public_questions[qid]['question_en']==q
    file=P/'cqs/spectra_cq_v2.0/cypher'/(qid+'.cypher')
    authored='\n'.join(x for x in file.read_text().splitlines()if x and not x.startswith('//')).strip()
    assert authored==d['original_query']
    digest=sha(json.dumps(d,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
    assert digest==case['repair_sha256']
    topic=('DMRS','pattern')if is_dmrs else (('SRS','configuration')if qid.endswith('-3')else('PUCCH','resource'))
    term1,term2=topic
    assert f"CONTAINS '{term1}'"in authored and f"CONTAINS '{term2}'"in authored
    assert d['required_fields']==[{'name':'resolutionId','type':'string','nullable':False,'source_column_or_expression':'a.resolutionId'}]
    sem=[]
    def unit(i,quote,finding,clauses,counter):
        sem.append({'unit':units[i],'status':'pass','original_quote':quote,'finding':finding,'query_clauses':clauses,'counterinterpretation_and_limit':counter})
    unit(0,'List the agreements',
      'The requested object is the Agreement record. The stable resolutionId identifies which agreements are listed; no prose quotation, equation, meeting-label field or newly-changed technical proposition is expressly required. I accept identity completeness as mandatory while retaining meeting/content as explanatory source context. This is specific to this entity-list wording and does not authorize ID-only scoring for explanation or decision-content questions.',
      ['required_fields: resolutionId:string, nonnull','RETURN m.meetingNumber, a.resolutionId, source text retained for provenance'],
      'Natural lists may benefit from titles or full text. The original RETURN includes content and design section8 supplies rich content for answer generation. Those facts are preserved but do not alone make every displayed field mandatory under the existing question-first criteria.')
    unit(1,'agreements',
      'The original Phase2 record model and unchanged Agreement MADE_AT Meeting population define recorded agreements. The separate input retains all original nodes, contents and edges and adds the same generic own-record text property to3176 records from ten report bodies, with unchanged older-content fallback. It is a source-enriched variant, not proof that the original frozen content was faithful. Own endorsed text/attached TPs may contain unchanged background; foreign following contributions must be excluded by own-record boundaries.',
      ['MATCH (a:Agreement)-[:MADE_AT]->(m:Meeting)','coalesce(a.sourceRecordWindowText, a.content)'],
      'No claim of all ten reports being physically final at capture, actual normative incorporation, complete technical-topic classification, or new original560 admission. Existing source geometry/formatting and pool witnesses are reused; only four counterreading windows were freshly reopened by this audit.')
    unit(2,('DMRS patterns'if is_dmrs else('SRS configuration'if qid.endswith('-3')else'PUCCH resources')),
      f'I accept the preserved operational keyword-search reading: both literal strings {term1!r} and {term2!r} occur in the same own Agreement record text. This is supported independently by design section8 content-search CONTAINS example, the implemented CQ5 keyword-trend validation category and its explicit remapping from generic designCQ6, as well as the exact original authored query. There is no authored requirement that both terms describe a newly changed technical feature. The freshly reopened adopted TP/endorsed LS countercases show why this must not be described as semantic newly-changed-topic retrieval.',
      [f"coalesce(a.sourceRecordWindowText, a.content) CONTAINS '{term1}'",f"coalesce(a.sourceRecordWindowText, a.content) CONTAINS '{term2}'",'AND between literal predicates; exact case retained'],
      'The English on-topic wording alone could support broader semantic relevance or a stricter new-decision reading; literal conjunction is accepted only with preserved implemented source context. I do not claim these readings are universally equivalent or exclude a record merely because its adopted TP contains background text.')
    if is_dmrs:
        countfinding='Agreement identities are the scored unit. The full112 matching join rows contain111 identities, with one historical alias duplicate entirely below the reachable top10 boundary. No row is removed or alias normalized. The prospective generic kernel rejects duplicate requested-field tokens touching any reachable rank including all cutoff ties, and permits lower-only duplicates that cannot enter any valid answer. Its independent1458 admission/2801 score/1555 equivalence controls pass; the old frozen scorer is unchanged.'
        countclauses=['full matching join rows retained112; distinct resolutionId111','prospective validate_top_k_reachable_record_uniqueness; no ID-specific exception','old duplicate AGR-100-7.2.4.1-005 preserved below cutoff117']
        countcounter='This is not general graph deduplication or permission to take two copies of an ID. A duplicate touching the cutoff or any higher rank is a hard error; a future cohort with different requested fields must use the complete declared token.'
    else:
        countfinding='The answer is a set of Agreement identities, not a count of MADE_AT paths or term occurrences. Existing multi-meeting/alias joins remain in the full pool, while the selected latest10 contains10 unique IDs under the preserved meetingDESC/IDASC selection. Full-pool changes from869 to3176 enrichment are explicitly retained: '+('340→360 rows and336→356 distinct IDs'if qid.endswith('-3')else'571→577 rows and565→571 distinct IDs')+'. Unchanged selected10 is a measured consequence, not the rule used to select the scope.'
        countclauses=['collection.kind=set; resolutionId record token','unchanged MADE_AT joins','selected10 has10 distinct IDs; full matching pool retained']
        countcounter='Do not treat all join-row multiplicities as distinct agreements or conclude whole-pool equivalence from prefix equality. The complete new pools differ and remain part of the evidence.'
    unit(3,'agreements',countfinding,countclauses,countcounter)
    unit(4,'List',
      'I accept a finite latest10 evaluation extent from this exact pre-existing implemented question/query pair, which explicitly supplies LIMIT10. I do not derive10 from a fabricated general CQ5 default. The earlier designCQ6 default is all/meetingASC and is real contrary context; that design also says limit is adjustable and the implemented validation categories are explicitly expanded/restructured. Here the exact authored operational test fixes the adjusted extent before this review or model outcome. '+('The reference captures the full matching population only so the scorer can represent every legal boundary subset; the answer cardinality remains10.'if is_dmrs else'The reference preserves LIMIT10 exactly.'),
      ['original authored LIMIT 10','cardinality_policy.value=10','full pool retained independently of selected prefix'],
      'If evaluation were defined by standalone English without its fixed implemented task context,10 would not follow from the English. This judgment does not silently import generic CQ1/2 list defaults into technical-trend CQ5 or change extent after seeing a model response.')
    unit(5,'List',
      ('The exact original query ranks only meetingNumberInt DESC and has no resolutionId tie breaker. There are8 strictly higher eligible identities and3 candidates tied at meeting117, of which any2 are valid. The definition preserves that rank selection and declares no serialization order because the English asks for a list without an explicit order. Adding an arbitrary ID tie breaker would change permissible answers. All three valid boundary pairs pass in either display direction.'if is_dmrs else'The exact original query uses meetingNumberInt DESC then resolutionId ASC to select the latest10 deterministically. The definition preserves both keys and LIMIT10. Those keys govern answer membership, while output serialization is a set because no ordering is expressly requested by the English. Generic designCQ6 ASC is preserved as contrary default context; no new query order was invented to reproduce an old prefix.'),
      (['ORDER BY m.meetingNumberInt DESC; no ID tie breaker','top_k_boundary_ties any_subset_at_boundary; require_rank_order=false','full pool112; above8; boundary3 choose2']if is_dmrs else['ORDER BY m.meetingNumberInt DESC, a.resolutionId LIMIT10','collection.kind=set; membership selection kept separate from serialization']),
      'Selection rank and output display are distinct. Set display does not authorize dropping higher-ranked records or changing tie membership. The source-context priority over a configurable generic default is explicit, not claimed to eliminate the textual contrary evidence.')
    unit(6,q,
      'No focal company, release, supplied document identifier, novelty decision or newly-changed gate is required. The prospective separate cohort must expose the same whole3176 graph/corpus policy to all methods and validate actual physical SQL table names before paid calls. Root-owned native manifest8f59... is now available and independently compared from saved JSON here; this review did not run native/SQL. Source-semantic acceptance does not itself freeze a protocol, validate scorer installation, supply runtime retrieval inputs or admit a question.',
      ['original question_en and original_query exact public bytes preserved','new source query explicitly query_and_scorer','no API/model output consulted to choose definition'],
      'This review is nonblind to original public metadata and retained reference/source/prefix evidence and to the primary review; it is an independently authored secondary reasoning record, not a blind or human/expert evaluation. No new cohort model outputs were read. Pending operational gates remain explicit.')
    review={'id':qid,'status':'pass','reviewer_kind':'Independent child AI /root/verify_public467_readonly; secondary source-context semantic review; nonblind; expert0',
      'repair_sha256':digest,'definition_file_sha256':pin(D/(qid+'_common3176_definition.json'))['sha256'],'criteria_sha256':criteria_sha,
      'original_question_sha256':sha(q.encode()),'original_query_sha256':sha(authored.encode()),
      'scope_of_pass':'Semantic contract for separate common3176 source variant only. Not original frozen560 admission, not a model outcome, not a child-executed native PASS.',
      'native_gate_observation':'Initially pending during drafting; root actual native manifest8f59... subsequently supplied, rehashed and saved-output compared. Native execution attributed to root only.',
      'semantic_evidence':sem,'source_evidence':[authority_pin,fresh_pin,native_pin,pin(L119),pin(E/'manifest.json'),pin(D/'manifest.json')],
      'independent_scorer_audit':pin(AUDIT/'actual_independent_generic_scorer_and_DMRS_boundary_audit.json'),
      'counterinterpretations_retained':['Literal conjunction is operational source context, not universal semantic-topic equivalence.','Generic design trend defaults all/ASC differ from exact implemented task DESC/LIMIT10.','Content/meeting fields are explanatory, identity completeness mandatory under entity-list question-first review.','Source-enriched separate graph and original frozen source are not conflated.'],
      'remaining_operational_gates':['Root adoption/freezing of exact prospective scorer and three source definitions','Common graph/corpus actual adapters and prompts; physical SQL-schema pre-call gate','Fresh paid model first attempts, if authorized, recorded separately from original560'],
      'API_calls':0,'native_calls':0,'SQL_calls':0,'public_changes':0,'central_changes':0,'original560_admissions':0,'expert_validation_n':0}
    schema.check_pass(review,q,units,criteria_sha=criteria_sha,identity_key='repair_sha256',identity_sha=digest)
    review_pins.append(save(qid+'_common3176_independent_secondary_seven_unit_review.json',review))

after={p:pin(p)for p in before}
assert before==after
receipt={'status':'PASS_THREE_INDEPENDENT_SECONDARY_SEMANTIC_REVIEWS_AND_SCHEMA_CHECKS_NOT_ADMITTED','reviews':review_pins,'authority_excerpts':authority_pin,'fresh_original_ZIP_counterreading':fresh_pin,'saved_root_native_comparison':native_pin,'scorer_audit':pin(AUDIT/'actual_independent_generic_scorer_and_DMRS_boundary_audit.json'),'definition_manifest':pin(D/'manifest.json'),'original_files_before':before,'original_files_after':after,'original_files_unchanged':True,'exposure':'Nonblind to primary/reference/source evidence and original public row metadata; no new model output inspected.','actual_child_executions':['Pure JSON/hash/XML ZIP reads','Structural seven-unit schema validation','Saved native-versus-SQL JSON multiset comparison; no database query'],'script':pin(__file__),'API_calls':0,'native_calls':0,'SQL_calls':0,'public_changes':0,'central_changes':0,'original560_admissions':0}
out=save('actual_independent_secondary_three_question_review_receipt.json',receipt)
print(json.dumps({'status':receipt['status'],'receipt':out,'reviews':review_pins},ensure_ascii=False))
