#!/usr/bin/env python3
"""Compare every corpus node fact and directed edge digest with whole SQLite.

This consumes no tasks, selected IDs, queries, raw-cover witnesses or answers.
It is a read-only comparison; the source SQL clone and FTS are never changed.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import resource
import sqlite3
import time

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'loop116_RAN1_ten_report_generic_text_whole_snapshot_output_only/RAN1_source_record_text.sqlite'
FTS = HERE / 'actual_corpus/ran1.sqlite3'


def load(path):
    spec = importlib.util.spec_from_file_location('whole_graph_corpus_comparison', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def ro(path):
    db = sqlite3.connect(path.resolve().as_uri() + '?mode=ro&immutable=1', uri=True)
    db.execute('PRAGMA query_only=ON')
    db.execute('PRAGMA cache_size=-32768')
    db.execute('PRAGMA temp_store=FILE')
    return db


def main():
    resource.setrlimit(resource.RLIMIT_AS, (8 * 1024**3, 8 * 1024**3))
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    began = time.monotonic()
    module = load(HERE / 'build_generic_graph_corpus.py')
    reconstruction = json.loads((HERE / 'actual_corpus/all_fact_reconstruction_receipt.json').read_text())
    build = json.loads((HERE / 'actual_corpus/build_receipt.json').read_text())
    assert reconstruction['status'] == 'PASS'
    assert module.sha(FTS) == reconstruction['immutable_database_sha256'] == build['database']['sha256']
    initial_source_sha = module.sha(SOURCE)
    source, corpus = ro(SOURCE), ro(FTS)
    id_to_iri = {}
    property_count = added = nodes = 0
    for nid, iri, labels, properties in source.execute('SELECT node_id,source_iri,labels_json,properties_json FROM _node_record'):
        assert nid not in id_to_iri
        id_to_iri[nid] = iri
        actual = corpus.execute('SELECT labels,properties FROM graph_nodes WHERE iri=?', (iri,)).fetchone()
        assert actual is not None, ('Missing corpus node', iri)
        expected_labels, expected_props = sorted(json.loads(labels)), json.loads(properties)
        assert module.canonical(json.loads(actual[0])) == module.canonical(expected_labels), ('Node labels', iri)
        assert module.canonical(json.loads(actual[1])) == module.canonical(expected_props), ('Node properties', iri)
        property_count += len(expected_props)
        added += 'sourceRecordWindowText' in expected_props
        nodes += 1
    assert nodes == corpus.execute('SELECT count(*) FROM graph_nodes').fetchone()[0] == 165418
    triples = []
    for src, rel, dst in source.execute('SELECT src_id,rel_type,dst_id FROM edge'):
        triples.append((id_to_iri[src], rel, id_to_iri[dst]))
    assert len(triples) == len(set(triples)) == 848228
    edge_digest = module.digest(sorted(triples))
    assert edge_digest == build['inventory']['directed_edges_sha256']
    assert added == 3176
    source.close()
    corpus.close()
    assert module.sha(SOURCE) == initial_source_sha
    assert module.sha(FTS) == build['database']['sha256']
    receipt = {
        'status': 'PASS', 'whole_SQLite_sha256': initial_source_sha,
        'whole_FTS_sha256': build['database']['sha256'],
        'all_node_labels_and_native_typed_properties_compared': nodes,
        'all_property_values_compared': property_count,
        'all_directed_edges_independently_compared': len(triples),
        'directed_edges_sha256': edge_digest,
        'generic_sourceRecordWindowText_properties_equal': added,
        'node_IRI_basis': '_node_record.source_iri, not auxiliary node_identity.iri',
        'public_lexer_and_all_chunk_reconstruction_receipt_sha256': module.sha(HERE / 'actual_corpus/all_fact_reconstruction_receipt.json'),
        'comparison_is_not_retrieval_or_answer_completeness': True,
        'task_query_answer_selection_inputs': [],
        'source_inputs_unchanged': True, 'model_API_native_calls': 0,
        'AS_cap_bytes': 8 * 1024**3, 'CPU_count': 1,
        'elapsed_seconds': time.monotonic() - began,
        'peak_RSS_KiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    }
    module.write_new(HERE / 'actual_complete_SQLite_corpus_fact_equivalence.json', receipt)
    print(module.canonical(receipt))


if __name__ == '__main__':
    main()
