#!/usr/bin/env python3
"""Read-only audit of final prospective inputs; never freezes or executes them."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(4 * 1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    assert not args.out.exists(), 'Prior receipts are immutable'
    p = args.runtime.resolve(strict=True)
    config_path = p / 'root_configuration.json'
    before_config = digest(config_path)
    cfg = read(config_path)
    checked = {}
    blockers = []
    assertions = []

    def check_pin(item, context):
        path = Path(item['path']).resolve(strict=True)
        actual = checked.get(str(path))
        if actual is None:
            actual = {'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}
            checked[str(path)] = actual
        assert actual['sha256'] == item['sha256'], (context, str(path), actual['sha256'], item['sha256'])
        if 'bytes' in item:
            assert actual['bytes'] == item['bytes'], (context, 'byte count')
        return path

    def pins_in(value, context):
        if isinstance(value, dict):
            if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
                check_pin(value, context)
            for key, item in value.items():
                pins_in(item, context + '/' + str(key))
        elif isinstance(value, list):
            for i, item in enumerate(value):
                pins_in(item, context + '/' + str(i))

    pins_in(cfg, 'configuration')
    public = {item['id']: item for item in read(p / 'public_tasks.json')}
    expected_ids = {'RAN1_P2_CQ5-3', 'RAN1_P2_CQ5-13', 'RAN1_P2_CQ5-11'}
    assert set(public) == set(cfg['cases']) == expected_ids
    assert cfg['cohort'] == 'RAN1_common3176_three_question_source_variant'
    assert cfg['original560_admission_delta'] == 0 and cfg['ready_for_root_review'] is True
    assert cfg['budget_is_approximate_guard_not_actual_charge'] is True
    assert 'admitted' in cfg['cost_unknown_policy'] and 'twelve' in cfg['cost_unknown_policy']
    required_gates = {'whole_native_reference_capture', 'whole_independent_SQL_agreement',
                      'independent_second_seven_unit_semantics', 'generic_and_boundary_scoring_controls',
                      'whole_source_and_FTS_equivalence'}
    assert set(cfg['gate_receipts']) == required_gates
    for kind, item in cfg['gate_receipts'].items():
        receipt = read(item['path'])
        assert item['assertions']
        for assertion in item['assertions']:
            value = receipt
            for key in assertion['key_path']:
                value = value[key]
            assert value == assertion['equals'], (kind, assertion)
        assertions.append({'gate': kind, 'explicit_assertions_checked': len(item['assertions'])})

    official_path = Path(cfg['definition_digest_implementation']['path'])
    sys.path.insert(0, str(official_path.parent))
    official = load_module(official_path, 'independent_final_definition_digest')
    sys.path.insert(0, str(p / 'scoring'))
    sys.modules['scorer'] = load_module(p / 'scoring/scorer.py', 'scorer')
    scorer = load_module(p / 'scoring/original_scorer.py', 'independent_final_original_scorer')
    prep = read(p / 'prospective_preparation.json')
    for key in ('TTL_input', 'SQL_input', 'FTS_input'):
        assert cfg[key] == prep[key]
    mock = read(p / 'actual_pre_call_mock_controls/receipt.json')
    assert mock['status'] == 'PASS'
    assert len(mock['SQL_schema_negative_cases']) == 4
    assert all(item['rejected'] and item['mock_call_count'] == 0 for item in mock['SQL_schema_negative_cases'])
    assert len(mock['actual_physical_schema_positive_prompts']) == 3
    assert all(item['actual_DDL_is_exact_final_prompt_schema'] for item in mock['actual_physical_schema_positive_prompts'])
    assert len(mock['container_stage_cases']) == 11
    assert any(item['case'] == 'memory_swap' and item['rejected'] for item in mock['container_stage_cases'])
    assert mock['paid_model_calls'] == mock['docker_or_native_calls'] == 0

    native = read(cfg['native_manifest']['path'])
    nc = cfg['native_container']
    assert native['source']['sha256'] == cfg['TTL_input']['sha256'] == nc['source_sha256']
    assert native['db']['sha256'] == cfg['SQL_input']['sha256']
    assert native['target']['container'] == nc['name']
    assert native['target']['bolt'] == nc['bolt'] == 'bolt://127.0.0.1:' + str(nc['port'])
    assert native['run_uuid'] == nc['run_uuid'] and native['image_id'] == nc['image_id']
    assert native['owned_container_stopped'] is True
    assert native['measured_counts']['total_nodes'] == 165418
    assert sum(native['measured_counts']['rel_counts'].values()) == 848228
    agreement = read(p / 'actual_root_saved_native_SQL_and_reference_projection_checks.json')
    pins_in(agreement, 'saved_native_SQL_agreement')
    captured = read(agreement['native_capture']['path'])
    sql = read(agreement['immutable_SQL_capture']['path'])
    assert set(captured) == set(sql['queries']) == set(sql['rows']) and len(captured) == 7
    key_checks = []
    for key, actual in captured.items():
        assert actual['complete'] is True and actual['truncated'] is False
        assert actual['transaction_rolled_back'] is True and actual['contains_updates'] is False
        assert actual['EXPLAIN_query_type'] == actual['actual_query_type'] == 'r'
        assert actual['literal_query'] == sql['queries'][key]
        assert actual['row_n'] == len(actual['rows']) == len(sql['rows'][key])
        equal = Counter(json.dumps(row, sort_keys=True, ensure_ascii=False, separators=(',', ':')) for row in actual['rows']) == Counter(json.dumps(row, sort_keys=True, ensure_ascii=False, separators=(',', ':')) for row in sql['rows'][key])
        if key != 'RAN1_P2_CQ5-11/selected':
            assert equal, key
        key_checks.append({'key': key, 'rows': len(actual['rows']), 'whole_multiset_equal': equal,
                           'DMRS_selected_is_independently_boundary_scored': key == 'RAN1_P2_CQ5-11/selected'})

    definition_checks = []
    for ident, item in cfg['cases'].items():
        d = read(item['definition']['path'])
        task = public[ident]
        assert set(d) == set(official.DEFINITION_KEYS)
        assert official.digest({key: d[key] for key in official.DEFINITION_KEYS}) == task['repair_sha256']
        assert d['question_en'] == task['question_en'] and d['id'] == task['id']
        assert d['original_question_preserved'] is True
        assert task['collection'] == d['collection'] and task['cardinality_policy'] == d['cardinality_policy']
        for field in task['required_fields']:
            source = next(f for f in d['required_fields'] if f['name'] == field['name'])
            assert all(source[k] == v for k, v in field.items())
        assert not {'original_query', 'reference_query', 'gold', 'expected_records', 'actual_reference_rows'} & set(task)
        terms = re.findall(r"CONTAINS '([^']+)'", d['original_query'])
        policy = task['selection_policy']
        observed_terms = policy.get('literal_terms')
        terms_explicit = observed_terms == terms and policy.get('case_sensitive') is True
        if not terms_explicit:
            blockers.append({'class': 'missing_explicit_shared_literal_predicate_parameters', 'id': ident,
                             'expected_literal_terms_from_unchanged_authored_query': terms,
                             'observed_literal_terms': observed_terms,
                             'reason': 'Exact singular authored substring predicates are not uniquely specified by plural natural-English resources/patterns. Resolve prospectively for all methods, or explicitly withdraw the literal-policy claim.'})
        refs = [json.loads(line) for line in Path(item['actual_reference_rows']['path']).read_text().splitlines() if line]
        assert item['actual_reference_rows']['provenance'] == 'actual_owned_native_capture'
        lineage = read(p / 'native_reference' / (ident + '.lineage.json'))
        assert lineage['input_capture_sha256'] == agreement['native_capture']['sha256']
        capture_item = captured[lineage['input_capture_key']]
        assert hashlib.sha256(capture_item['literal_query'].encode()).hexdigest() == lineage['input_query_sha256']
        projected = [{lineage['column_aliases'][column]: value for column, value in zip(capture_item['columns'], row)} for row in capture_item['rows']]
        assert refs == projected and len(refs) == lineage['rows']
        assert lineage['values_edited'] is False and lineage['filters_or_deduplication_applied'] is False
        selected = captured[ident + '/selected']
        alias = {'m.meetingNumber': 'meetingNumber', 'a.resolutionId': 'resolutionId', 'content': 'content'}
        selected_records = [{alias[column]: value for column, value in zip(selected['columns'], row)} for row in selected['rows']]
        projected_refs = [{field['name']: row[field['name']] for field in d['required_fields']} for row in refs]
        groups = scorer.make_order_groups(d, refs, projected_refs) if d['collection']['kind'] == 'top_k_boundary_ties' else None
        score = scorer.score(d, projected_refs, selected_records, diagnostic=True, order_groups=groups)
        assert score['exact'] is True and score['f1'] == 1.0
        definition_checks.append({'id': ident, 'repair_sha256': task['repair_sha256'], 'reference_rows': len(refs),
                                  'source_native_selected_score': score, 'literal_terms_explicitly_shared': terms_explicit,
                                  'reference_lineage_recomputed_from_saved_native_capture': True})

    code_paths = [p / 'run_separate_common3176_experiment.py', p / 'public_tasks.json', p / 'graph_schema.json', p / 'sql_schema.json',
                  p / 'prospective_preparation.json', p / 'actual_pre_call_mock_controls/receipt.json']
    code_paths.extend(sorted((p / 'runtime').glob('*.py')))
    code_before = [{'path': str(f), 'sha256': digest(f), 'bytes': f.stat().st_size} for f in code_paths]
    # No API, network, SQLite connection, shell/container command, or freeze function is invoked.
    assert digest(config_path) == before_config, 'Configuration changed during audit'
    assert all(digest(item['path']) == item['sha256'] for item in code_before)
    result = {
        'status': 'BLOCKED_PRECALL_METADATA_CLARIFICATION' if blockers else 'PASS_INDEPENDENT_PRECALL_READ_AND_MOCK_AUDIT',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'configuration': {'path': str(config_path), 'sha256': before_config, 'bytes': config_path.stat().st_size},
        'all_configuration_pin_objects_verified': len(checked),
        'configuration_pins': sorted(checked.values(), key=lambda x: x['path']),
        'code_and_public_inputs': code_before,
        'gate_assertions': assertions, 'native_SQL_saved_capture_checks': key_checks,
        'definitions_and_reference_lineage': definition_checks, 'blocking_items': blockers,
        'budget': {'usd': cfg['budget_usd'], 'approximate_guard_not_charge_cap': True,
                   'unknown_cost_policy': cfg['cost_unknown_policy']},
        'fixed_cohort': {'questions': 3, 'methods': ['Text2Cypher', 'Text2SQL', 'C', 'D'], 'method_items': 12,
                         'success_flow_request_stages': 15, 'early_failure_or_budget_halt_can_reduce_sends': True,
                         'all_failures_retained_in_fixed_denominator': True},
        'strict_parse_limits': {'whole_JSON_no_fence_extraction': True, 'structured_query_envelope_exact_keys': True,
                                'retrieval_extra_envelope_keys_allowed': True, 'unrequested_record_fields_ignored_by_scorer': True,
                                'JSON_duplicate_key_rejection_is_not_implemented': True},
        'provenance_limits': ['Actual native and whole-source/physical-DDL execution receipts are attributed to ROOT; this audit rehashed them and independently recomputed saved JSON projections only.',
                              'prospective_preparation.json runtime_adaptations describes the preserved agent preparation; ROOT client and lifecycle amendments are separate pinned diffs and current runtime bytes.',
                              'The source-context task interpretation is conditional and does not assert newly introduced technical changes or admission to the original560.',
                              'Source whole-facts equivalence does not imply equal context exposure or a causal method effect.'],
        'API_calls': 0, 'native_calls': 0, 'SQL_connections_or_source_queries': 0,
        'freeze_or_runtime_execution': 0, 'public_changes': 0, 'central_changes': 0,
        'script_sha256': digest(__file__)
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'pins': len(checked), 'blocking_items': len(blockers),
                      'receipt': str(args.out), 'sha256': digest(args.out)}))


if __name__ == '__main__':
    main()
