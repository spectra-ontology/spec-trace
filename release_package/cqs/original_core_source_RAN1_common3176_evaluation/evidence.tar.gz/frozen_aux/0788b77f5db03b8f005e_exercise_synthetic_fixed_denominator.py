"""Use runner.score on private synthetic references/failures, never model data."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
P=Path('/home/sihyeon/workspace/spectra/logs/pending-tasks/spectracq-core-contract-2026-10-13/empirical/overnight_reaudit/root_evidence/two_agent_unresolved_loop/root_RAN1_common3176_prepared_evaluation_v1')
def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x')as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('private_synthetic_denominator_runner',P/'run_separate_common3176_experiment.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
# Replace only the in-memory fixture's freeze I/O, not runtime files or source data.
r.verify_freeze=lambda *_a:None
trial=HERE/'SYNTHETIC_ONLY_DENOMINATOR_FIXTURE'
assert not trial.exists()
trial.mkdir()
cfg={'trial_directory':str(trial),'cases':{},'cohort':'SYNTHETIC_PRIVATE_TEST_NOT_AN_EXPERIMENT'}
outputs={}
tasks=json.loads((P/'public_tasks.json').read_text())
for t in tasks:
    ident=t['id'];d={k:t[k]for k in ['id','question_en','required_fields','collection','cardinality_policy']}
    path=trial/(ident+'.definition.json');save(path,d)
    rows=[{'resolutionId':'SYNTHETIC_HIGH_'+str(i),'meetingNumberInt':118}for i in range(8)]+[{'resolutionId':'SYNTHETIC_BOUNDARY_'+str(i),'meetingNumberInt':117}for i in range(3)]
    if d['collection']['kind']=='top_k_boundary_ties':rows += [{'resolutionId':'SYNTHETIC_LOWER_ALIAS','meetingNumberInt':100}]*2
    else:rows=rows[:10]
    ref=trial/(ident+'.jsonl')
    with ref.open('x')as f:
        for row in rows:f.write(json.dumps(row)+'\n')
    cfg['cases'][ident]={'definition':{'path':str(path),'sha256':sha(path)},'actual_reference_rows':{'path':str(ref),'sha256':sha(ref)}}
    outputs[ident]={
       'Text2Cypher':{'status':'EXECUTION_ERROR','records':[],'abstain':True},
       'Text2SQL':{'status':'GENERATION_FORMAT_ERROR','records':[],'abstain':True},
       'C':{'status':'answer_parse_error','records':[]},
       'D':{'status':'followup_parse_error','records':[]},
    }
save(trial/'executed_predictions.json',{'results':outputs,'SYNTHETIC_ONLY':True})
save(trial/'usage.json',{'SYNTHETIC_ONLY':True,'paid_calls':0,'known_actual_cost_usd':0})
r.score(cfg,HERE/'UNUSED_CONFIG_SYNTHETIC')
summary=json.loads((trial/'actual_results_summary.json').read_text())
assert len(summary['results'])==12
assert all(v['N']==3 and v['exact']==0 and v['f1']==0 for v in summary['macro'].values())
assert all(not x['valid_answer']and not x['score']['exact']and x['score']['f1']==0 and x['failure_remains_in_denominator']for x in summary['results'])
save(HERE/'actual_private_synthetic_denominator_receipt.json',{'status':'PASS_ALL12_SYNTHETIC_FAILURES_RETAINED_WITH_N3_PER_METHOD','runner_sha256':sha(P/'run_separate_common3176_experiment.py'),'fixture_output_sha256':sha(trial/'actual_results_summary.json'),'test_scope':'Pure private mock failure-denominator test; synthetic reference IDs/rows, no real model outcomes or evidence scored. Fixture uses runner.score unchanged except in-memory freeze I/O stub.','method_items':12,'N_per_method':3,'macro':summary['macro'],'API_calls':0,'native_calls':0,'source_queries':0,'public_changes':0,'central_changes':0})
print('PASS_PRIVATE_SYNTHETIC_DENOMINATOR')
