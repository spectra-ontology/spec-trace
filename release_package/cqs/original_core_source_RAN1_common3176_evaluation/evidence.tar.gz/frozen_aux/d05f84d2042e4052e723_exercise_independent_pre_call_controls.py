"""Private mock-only prospective runtime audit. No provider/native calls.

sqlite3 is used only for a tiny newly-created empty synthetic DDL fixture.
All outputs are private and synthetic; no scientific result is generated here.
"""
import copy
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sqlite3
import sys
import threading
import types
import urllib.error

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
P=Path('/home/sihyeon/workspace/spectra/logs/pending-tasks/spectracq-core-contract-2026-10-13/empirical/overnight_reaudit/root_evidence/two_agent_unresolved_loop/root_RAN1_common3176_prepared_evaluation_v1')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x')as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def load(path,name):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
files=[P/'run_separate_common3176_experiment.py',*sorted((P/'runtime').glob('*.py')),*sorted((P/'scoring').glob('*'))]
files=[p for p in files if p.is_file()]
before={str(p):sha(p)for p in files}
T=load(P/'runtime/openrouter_client.py','private_mock_transport')
assert sha(P/'runtime/openrouter_client.py')=='602ab2b85cf5a39823c528644dabf8e0aa305cafba28d7efc1a92b1cb2adf141'
S=load(P/'runtime/structured_adapter.py','private_mock_structured')
R=load(P/'runtime/retrieval_adapter.py','private_mock_retrieval')
G=load(P/'runtime/container_stage_guard.py','private_mock_stage')
PHY=load(P/'runtime/physical_schema.py','private_mock_physical')
RUN=load(P/'run_separate_common3176_experiment.py','private_mock_runner')
results=[]
messages=[{'role':'user','content':'SYNTHETIC ONLY'}]
real_urlopen=T.urllib.request.urlopen
real_request=T.urllib.request.Request
T.time.sleep=lambda _:None

class Resp:
    status=200
    def __init__(self,body):self.body=body
    def __enter__(self):return self
    def __exit__(self,*_):pass
    def read(self):return json.dumps(self.body).encode()
def envelope(cost=.01,**change):
    e={'model':T.MODEL,'provider':T.PROVIDER,'usage':{'cost':cost},'choices':[{'finish_reason':'stop','message':{'content':'{"query":"","abstain":true}'}}]}
    e.update(change);return e
def client(name,budget=20):return T.OpenRouterCaller(HERE/'transport'/name,api_key='NOT_A_REAL_SECRET',budget_usd=budget)
def run_transport_case(name,actions,budget=20,again=False):
    seen=[];c=client(name,budget)
    def open_mock(req,timeout):
        seen.append(bytes(req.data));action=actions[len(seen)-1]
        if isinstance(action,Exception):raise action
        return Resp(action)
    T.urllib.request.urlopen=open_mock
    out=c.call('one',messages,max_tokens=8)
    later=c.call('two',messages,max_tokens=8)if again else None
    result={'case':name,'mock_sends':len(seen),'outcome':out,'later':later,'summary':c.summary_unlocked(),'identical_attempt_payloads':len(set(seen))<=1}
    results.append(result);return result

x=run_transport_case('known_success',[envelope()]);assert x['mock_sends']==1 and x['outcome']['ok']and not x['summary']['halted_unknown_cost']
http_known=urllib.error.HTTPError('mock://never-network',503,'synthetic',{},io.BytesIO(json.dumps({'usage':{'cost':.001},'error':'synthetic503'}).encode()))
x=run_transport_case('known_503_one_identical_retry',[http_known,envelope()]);assert x['mock_sends']==2 and x['outcome']['ok']and x['identical_attempt_payloads']and abs(x['summary']['known_actual_cost_usd']-.011)<1e-12
x=run_transport_case('unknown_HTTP200_then_queued_block',[envelope(usage={})],again=True);assert x['mock_sends']==1 and x['outcome']['ok']and x['later']['error']=='unknown_cost_halt'and x['summary']['unknown_cost_attempts']==1
http_unknown=urllib.error.HTTPError('mock://never-network',503,'synthetic',{},io.BytesIO(b'{"error":"synthetic503"}'))
x=run_transport_case('unknown_503_retry_and_later_block',[http_unknown],again=True);assert x['mock_sends']==1 and len(x['outcome']['attempts'])==1 and x['outcome']['error']=='unknown_cost_halt'and x['later']['error']=='unknown_cost_halt'
x=run_transport_case('unknown_transport_retry_and_later_block',[OSError('synthetic disconnected')],again=True);assert x['mock_sends']==1 and x['summary']['unknown_cost_attempts']==1 and x['later']['error']=='unknown_cost_halt'
x=run_transport_case('budget_blocks_before_send',[],budget=.000001);assert x['mock_sends']==0 and x['outcome']['error']=='frozen_budget_guard'
x=run_transport_case('known_provider_mismatch_no_retry',[envelope(model='WRONG')]);assert x['mock_sends']==1 and not x['outcome']['ok']and not x['summary']['halted_unknown_cost']

# Race: four stages can pass the last latch check before an unknown response.
# Three are paused at Request construction, not yet sent. They remain admitted.
entered=threading.Barrier(4);release=threading.Event();unknown_done=threading.Event();sends=[];send_lock=threading.Lock()
c=client('concurrent_admitted_before_halt')
def delayed_request(*args,**kwargs):
    entered.wait(timeout=10)
    if threading.current_thread().name!='unknown_first':release.wait(timeout=10)
    return real_request(*args,**kwargs)
def concurrent_open(req,timeout):
    name=threading.current_thread().name
    with send_lock:sends.append({'thread':name,'halted_at_mock_send':c.halted_unknown_cost})
    return Resp(envelope(usage={})if name=='unknown_first'else envelope())
T.urllib.request.Request=delayed_request;T.urllib.request.urlopen=concurrent_open
outs={}
def worker(name):
    outs[name]=c.call(name,messages,max_tokens=8)
    if name=='unknown_first':unknown_done.set()
threads=[threading.Thread(target=worker,args=(name,),name=name)for name in ['unknown_first','already_admitted_1','already_admitted_2','already_admitted_3']]
for th in threads:th.start()
assert unknown_done.wait(10)and c.halted_unknown_cost
release.set()
for th in threads:th.join(10);assert not th.is_alive()
blocked=c.call('new_queued_after_halt',messages,max_tokens=8)
assert len(sends)==4 and sum(z['halted_at_mock_send']for z in sends)==3 and blocked['error']=='unknown_cost_halt'
results.append({'case':'concurrency_admission_window_limit','mock_sends':sends,'queued_after_halt':blocked,'summary':c.summary_unlocked(),'interpretation':'Up to4 already admitted stages can complete;3 can begin mock transmission after latch because the final check precedes Request/urlopen. New stages after halt are blocked. Not a claim of zero post-observation bytes.'})
T.urllib.request.Request=real_request
T.urllib.request.urlopen=lambda *_a,**_k:(_ for _ in()).throw(AssertionError('Network forbidden outside transport mock'))

class Caller:
    def __init__(self,content=None,finish='stop',bad_followup=False):self.calls=[];self.content=content;self.finish=finish;self.bad_followup=bad_followup
    def call(self,ident,messages,max_tokens):
        self.calls.append({'id':ident,'messages':copy.deepcopy(messages),'max_tokens':max_tokens})
        content=self.content
        if content is None:
            content=('{"query":"SYNTHETIC"}'if ident.endswith('_D_followup')else('{"query":"","abstain":true}'if ident.endswith(('_Text2SQL','_Text2Cypher'))else'{"records":[],"abstain":true,"complete":false}'))
        if self.bad_followup and ident.endswith('_D_followup'):content='```json\n{"query":"SYNTHETIC"}\n```'
        return {'ok':True,'finish_reason':self.finish,'content':content,'usage':{},'provider':'MOCK_ONLY'}

tasks=read(P/'public_tasks.json');graph=read(P/'graph_schema.json')
parse=[]
for label,content,finish,status in [
 ('valid','{"query":"MATCH (n) RETURN n.resolutionId AS resolutionId","abstain":false}','stop','QUERY_READY'),
 ('fenced','```json\n{"query":"","abstain":true}\n```','stop','GENERATION_FORMAT_ERROR'),
 ('prose','Here is JSON: {"query":"","abstain":true}','stop','GENERATION_FORMAT_ERROR'),
 ('extra_key','{"query":"","abstain":true,"x":1}','stop','GENERATION_FORMAT_ERROR'),
 ('wrong_boolean','{"query":"","abstain":0}','stop','GENERATION_FORMAT_ERROR'),
 ('abstain_query_conflict','{"query":"MATCH(n) RETURN n","abstain":true}','stop','GENERATION_FORMAT_ERROR'),
 ('empty_nonabstain','{"query":" ","abstain":false}','stop','GENERATION_FORMAT_ERROR'),
 ('length_even_valid','{"query":"","abstain":true}','length','GENERATION_TRUNCATED')]:
    task=copy.deepcopy(tasks[0]);task['graph_schema']=graph;caller=Caller(content,finish)
    out=S.evaluate(task,'Text2Cypher',caller,HERE/'structured_parse'/label)
    assert len(caller.calls)==1 and out['status']==status
    parse.append({'case':label,'status':out['status'],'mock_calls':1})
retrieval_parse=[]
for label,content,valid in [
 ('valid','{"records":[],"abstain":true,"complete":false}',True),
 ('fenced','```json\n{"records":[],"abstain":true,"complete":false}\n```',False),
 ('prose','Answer: {"records":[],"abstain":true,"complete":false}',False),
 ('NaN','{"records":[{"resolutionId":NaN}],"abstain":false,"complete":true}',False),
 ('conflict','{"records":[{"resolutionId":"x"}],"abstain":true,"complete":true}',False),
 ('missing_complete','{"records":[],"abstain":true}',False),
 ('extra_envelope_key','{"records":[],"abstain":false,"complete":true,"explanation":"ignored"}',True)]:
    try:R.parse_answer(content);accepted=True
    except(ValueError,TypeError):accepted=False
    assert accepted is valid
    retrieval_parse.append({'case':label,'accepted':accepted})

# A tiny empty database tests the actual before-caller DDL path; no corpus rows read.
dbpath=HERE/'synthetic_empty_schema.sqlite'
db=sqlite3.connect(dbpath);db.executescript('CREATE TABLE Agreement(node_id TEXT PRIMARY KEY,resolutionId TEXT); CREATE TABLE rel_MADE_AT(edge_id TEXT,src_id TEXT,dst_id TEXT);');db.close()
dbsha=sha(dbpath);small_schema,physical_positive=PHY.build(dbpath,dbsha)
physical=[]
for label,change in [('exact',lambda d:d),('dropped_table',lambda d:dict(d,tables=d['tables'][:-1])),('wrong_name',lambda d:dict(d,tables=[dict(d['tables'][0],name='invented')]+d['tables'][1:]))]:
    task=copy.deepcopy(tasks[0]);task['sql_schema']=change(copy.deepcopy(small_schema));caller=Caller()
    try:S.evaluate(task,'Text2SQL',caller,HERE/'physical'/label,sql_input={'path':str(dbpath),'sha256':dbsha});err=None
    except ValueError as exc:err=str(exc)
    assert (len(caller.calls)==1 and err is None)if label=='exact'else(len(caller.calls)==0 and err)
    physical.append({'case':label,'mock_calls':len(caller.calls),'error':err})

# Actual adapters, fixed task set, but retrieval and schema I/O are private stubs.
R.prepare_corpus_inventory=lambda *_a,**_k:{'shards':[{'WG':'RAN1','path':str(dbpath),'sha256':dbsha}]}
R.retrieve=lambda *_a,**_k:{'status':'ok','hits':[],'context_candidate_truncated':False}
R.contexts=lambda *_a,**_k:([],{'document_selection_truncated':False,'characters':0,'utf8_bytes':0,'whitespace_terms':0})
allcalls=Caller();cohort=[]
for task in tasks:
    for method in RUN.METHODS:
        if method in RUN.METHODS[:2]:
            t=copy.deepcopy(task);t['graph_schema']=graph;t['sql_schema']=small_schema
            out=S.evaluate(t,method,allcalls,HERE/'fixed15',sql_input={'path':str(dbpath),'sha256':dbsha})
        else:out=R.evaluate(copy.deepcopy(task),method,allcalls,HERE/'fixed15')
        cohort.append({'id':task['id'],'method':method,'status':out['status']})
assert len(cohort)==12 and len(allcalls.calls)==15 and len({x['id']for x in allcalls.calls})==15
bad=Caller(bad_followup=True);failed=R.evaluate(copy.deepcopy(tasks[0]),'D',bad,HERE/'D_early_failure')
assert len(bad.calls)==1 and failed['status']=='followup_parse_error'

# Mock every external action of execute_cypher; load the real lexical/read plan guard.
trace=[];state={'running':False};gib=1024**3
target={'name':'kdd-db-source-ran1-private-mock','port':57999,'run_uuid':'MOCK','source_sha256':'a'*64,'image_id':'sha256:'+'b'*64,'bolt':'bolt://never-used'}
info={'Name':'/'+target['name'],'Image':target['image_id'],'Config':{'Labels':{'spectra.frozen.owner':'contract_repair_v1','spectra.frozen.run_uuid':'MOCK','spectra.frozen.source_sha256':'a'*64}},'HostConfig':{'Memory':2*gib,'MemorySwap':2*gib,'NanoCpus':10**9,'PortBindings':{'7687/tcp':[{'HostIp':'127.0.0.1','HostPort':'57999'}]}},'State':{'Running':False}}
def command(*args):
    trace.append(list(args))
    if args[:2]==('docker','ps'):return ''
    if args[:2]==('docker','inspect'):
        i=copy.deepcopy(info);i['State']['Running']=state['running'];return json.dumps([i])
    if args[:2]==('docker','start'):state['running']=True;return target['name']
    if args[:2]==('docker','stop'):state['running']=False;return target['name']
    raise AssertionError(args)
class Summary:
    query_type='r';plan={};counters=types.SimpleNamespace(contains_updates=False,contains_system_updates=False)
class Cursor:
    def __init__(self,q):self.q=q
    def single(self):return {'n':165418 if '(n)'in self.q else 848228}
    def consume(self):trace.append(['consume',self.q]);return Summary()
    def keys(self):return ['resolutionId']
    def __iter__(self):return iter([types.SimpleNamespace(data=lambda:{'resolutionId':'SYNTHETIC'})])
class Tx:
    def run(self,q):trace.append(['tx.run',q]);return Cursor(q)
    def rollback(self):trace.append(['rollback'])
class Session:
    def __enter__(self):return self
    def __exit__(self,*_):pass
    def begin_transaction(self,timeout):trace.append(['begin_transaction',timeout]);return Tx()
class Driver:
    def verify_connectivity(self):trace.append(['connectivity'])
    def session(self,**kwargs):return Session()
    def close(self):trace.append(['driver.close'])
sys.modules['neo4j']=types.SimpleNamespace(GraphDatabase=types.SimpleNamespace(driver=lambda *_a,**_k:Driver()),READ_ACCESS='READ')
RUN.command=command;RUN.host_available=lambda:{'Linux_available_bytes':40*gib,'Windows_available_bytes':40*gib}
guard=Path('/home/sihyeon/workspace/spectra-public/spec-trace/release_package/cqs/contract_repair_v1/replay_generated_read_queries.py')
cfg={'read_query_guard':{'path':str(guard),'sha256':sha(guard)},'native_container':target,'TTL_input':{'sha256':'a'*64},'native_lock_path':str(HERE/'mock_native.lock')}
query='  MATCH (a:Agreement) RETURN a.resolutionId AS resolutionId  '
out=RUN.execute_cypher(query,cfg,HERE/'native_mock/events.json')
assert out['complete']and out['rollback_completed']and not state['running']
assert ['tx.run',query]in trace and ['tx.run','EXPLAIN '+query]in trace
assert trace.index(['docker','start',target['name']])>trace.index(['docker','inspect',target['name']])
assert trace.index(['rollback'])<next(i for i,t in enumerate(trace)if t[:2]==['docker','stop'])
native_mock={'status':out['status'],'trace':trace,'original_query_bytes_preserved':True,'actual_container_calls':0}

after={str(p):sha(p)for p in files};assert before==after
save(HERE/'actual_independent_pre_call_mock_audit.json',{'status':'PASS_PRIVATE_MOCK_TRANSPORT_SCHEMA_PARSE_FIXED_COHORT_AND_NATIVE_STAGE_ORDER','runtime_pins_before':before,'runtime_pins_after':after,'runtime_files_unchanged':True,'transport_controls':results,'structured_parse_controls':parse,'retrieval_parse_controls':retrieval_parse,'synthetic_physical_DDL':physical,'positive_physical_fixture_receipt':physical_positive,'fixed_cohort12':cohort,'all_success_branch_request_stage_IDs':[x['id']for x in allcalls.calls],'all_success_branch_stages':15,'D_early_failure_preserved':{'status':failed['status'],'mock_calls':len(bad.calls),'answer_call_skipped':True,'method_item_still_in_fixed12':True},'native_execution_fully_mocked':native_mock,'limits':['No provider/native/real source SQL execution occurred. Only empty synthetic DDL metadata fixture used.','15 is the planned stage maximum on all-success control flow; D followup failure or budget/unknown gate can reduce sends while keeping12method items.','Strict parsing means whole response JSON/no fence/prose extraction; retrieval envelope extra keys are tolerated, record field typing belongs to scorer. It is not a unique-JSON-key parser.','Cost reservation is approximate, not provider billing cap. Up to4 already admitted request stages may send/finish after the first unknown-cost observation.','Final root configuration/gate closure and freeze pins must be audited separately before actual API authorization.'],'API_calls':0,'native_calls':0,'real_source_SQL_calls':0,'private_synthetic_SQL_fixture_only':True,'public_changes':0,'central_changes':0,'script_sha256':sha(__file__)})
print(json.dumps({'status':'PASS_PRIVATE_MOCK_RUNTIME_AUDIT','transport_controls':len(results),'structured_parse_controls':len(parse),'retrieval_parse_controls':len(retrieval_parse),'cohort_items':12,'all_success_stages':15,'receipt_sha256':sha(HERE/'actual_independent_pre_call_mock_audit.json')}))
