#!/usr/bin/env python3
"""Reject internally repinned corpus corruptions against the original fixture."""
from pathlib import Path
import importlib.util
import json
import shutil
import sqlite3
import subprocess
import sys

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('generic_corpus_negative_target', HERE/'build_generic_graph_corpus.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def main():
    lexer = Path(sys.argv[1]).resolve()
    fixture = HERE/'actual_generic_controls/generic_boundary_fixture.ttl'
    source = HERE/'actual_generic_controls/fixture_corpus'
    output = HERE/'actual_negative_fact_controls'
    assert not output.exists()
    output.mkdir()
    results=[]
    for mode in ('changed_property', 'missing_chunk', 'changed_direction', 'wrong_offset'):
        stage=output/mode
        shutil.copytree(source,stage)
        (stage/'all_fact_reconstruction_receipt.json').unlink()
        db=stage/'test.sqlite3'
        con=sqlite3.connect(db)
        if mode=='changed_property':
            iri,properties=con.execute('SELECT iri,properties FROM graph_nodes ORDER BY iri LIMIT 1').fetchone()
            props=json.loads(properties);props['arbitraryKey']='different'
            con.execute('UPDATE graph_nodes SET properties=? WHERE iri=?',(module.canonical(props),iri))
        elif mode=='missing_chunk':
            con.execute('DELETE FROM docs WHERE id=(SELECT min(id)+1 FROM docs)')
        elif mode=='changed_direction':
            # Rewrite a complete small node's own text and every local pin;
            # the error must be detected by the graph meaning checks.
            iri,labels,properties,_,_,_=con.execute('SELECT * FROM graph_nodes ORDER BY iri LIMIT 1').fetchone()
            rows=con.execute('SELECT metadata,text FROM docs ORDER BY id').fetchall()
            payloads=[(json.loads(meta),text) for meta,text in rows if json.loads(meta)['node_iri']==iri]
            payloads.sort(key=lambda item:item[0]['chunk_ordinal'])
            text=payloads[0][1]+''.join(value[module.OVERLAP:] for _,value in payloads[1:])
            facts=[json.loads(line) for line in text.splitlines()]
            target=next(fact for fact in facts[1:] if fact['source']['iri']!=fact['target']['iri'])
            target['source'],target['target']=target['target'],target['source']
            text='\n'.join(module.canonical(fact) for fact in facts)+'\n'
            identity=module.hashlib.sha256(iri.encode()).hexdigest()
            con.execute('DELETE FROM docs WHERE point_id>=? AND point_id<?',(identity+':',identity+';'))
            parts=list(module.chunks(text))
            for ordinal,start,end,payload in parts:
                meta={'node_iri':iri,'chunk_ordinal':ordinal,'node_text_start_character_0_based':start,'node_text_end_character_0_based_exclusive':end}
                con.execute('INSERT INTO docs(collection,point_id,chunk_id,metadata,text) VALUES(?,?,?,?,?)',
                            ('test_whole_graph_nodes',identity+':'+f'{ordinal:08d}',iri+'#'+f'{ordinal:08d}',module.canonical(meta),payload))
            con.execute('UPDATE graph_nodes SET whole_text_characters=?,whole_text_sha256=?,chunk_count=? WHERE iri=?',
                        (len(text),module.hashlib.sha256(text.encode()).hexdigest(),len(parts),iri))
        else:
            rowid,metadata=con.execute('SELECT id,metadata FROM docs ORDER BY id LIMIT 1').fetchone()
            meta=json.loads(metadata);meta['node_text_start_character_0_based']=1
            con.execute('UPDATE docs SET metadata=? WHERE id=?',(module.canonical(meta),rowid))
        con.execute("INSERT INTO search(search) VALUES('rebuild')")
        con.commit();con.close()
        receipt=json.loads((stage/'build_receipt.json').read_text())
        receipt['database']['sha256']=module.sha(db)
        (stage/'build_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False))
        cmd=[sys.executable,'-B',str(HERE/'build_generic_graph_corpus.py'),'verify','--ttl',str(fixture),
             '--ttl-sha256',module.sha(fixture),'--lexer',str(lexer),'--output',str(stage)]
        run=subprocess.run(cmd,capture_output=True,text=True)
        (stage/'actual_verification.stderr').write_text(run.stderr)
        assert run.returncode!=0,mode+' incorrectly accepted'
        results.append({'corruption':mode,'internally_updated_DB_SHA_to_avoid_trivial_file_pin_rejection':True,
                        'rejected':True,'returncode':run.returncode,'error_tail':run.stderr.splitlines()[-1]})
    receipt={'status':'PASS','negative_controls':results,'all_rejected':True,
             'changed_direction_control_repinned_full_text_and_chunks':True,'API_native_public_calls':0}
    module.write_new(output/'receipt.json',receipt)
    print(module.canonical(receipt))


if __name__=='__main__':
    main()
