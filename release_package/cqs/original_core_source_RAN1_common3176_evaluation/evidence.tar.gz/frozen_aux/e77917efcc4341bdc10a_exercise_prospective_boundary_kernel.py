#!/usr/bin/env python3
"""Exercise a private, uninstalled duplicate-safe top-k infrastructure proposal."""
from pathlib import Path
import copy,hashlib,importlib.util,itertools,json,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PUBLIC=Path('/home/sihyeon/workspace/spectra-public/spec-trace/release_package/cqs/original_core_repair')
sys.path.insert(0,str(PUBLIC))
import original_scorer as original
spec=importlib.util.spec_from_file_location('private_prospective_boundary_scorer',HERE/'prospective_original_scorer.py')
new=importlib.util.module_from_spec(spec);spec.loader.exec_module(new)
previous=HERE.parent/'loop114_RAN1_ten_report_generic_source_text_and_DMRS_tie_proposal_NOT_ADMITTED'
c=json.loads((previous/'actual_existing_kernel_tie_controls_AND_full_pool_failure_NOT_GATE.json').read_text())
contract=c['contract_proposal']
proof=json.loads((previous/'actual_full_graph_coalesce_selection_proof_NOT_NATIVE_GOLD.json').read_text())
native=proof['complete_conditional_query_rows'];projected=[{'resolutionId':r['resolutionId']} for r in native]
checks=[]

def event(name,fn,expect_error=False):
    try:
        result=fn();ok=not expect_error
        checks.append({'check':name,'pass':ok,'actual_result':result,'expected_error':expect_error})
    except Exception as exc:
        ok=expect_error
        checks.append({'check':name,'pass':ok,'exception_type':type(exc).__name__,'exception_message':str(exc),'expected_error':expect_error})
    assert ok,name

event('old_kernel_full112_population_duplicate_failure_preserved',lambda:original.make_order_groups(contract,native,projected),True)
groups=new.make_order_groups(contract,native,projected)
event('new_kernel_full112_population_preserved_no_dedup',lambda:new.validate_top_k_reachable_record_uniqueness(contract,groups))
assert [r for g in groups for r in g]==projected and len(projected)==112
for control in c['controls']:
    pred=control['predicted_records'];expected=control['expected_exact']
    def run(p=pred,e=expected):
        result=new.score(contract,projected,p,diagnostic=True,order_groups=groups)
        assert result['exact'] is e
        return result
    event('full112_'+control['check'],run)

base={'required_fields':[{'name':'id','type':'string','nullable':False}],
      'collection':{'kind':'top_k_boundary_ties','value':3,'source_order_keys':[{'source_column':'rank','direction':'desc'}],
                    'tie_policy':'any_subset_at_boundary','within_tie_order':'any','require_rank_order':False},
      'cardinality_policy':{'mode':'top_k','value':3,'tie_policy':'any_subset_at_boundary'}}
base_native=[{'rank':5,'id':'H1'},{'rank':5,'id':'H2'},{'rank':4,'id':'B1'}, {'rank':4,'id':'B2'},{'rank':4,'id':'B3'},
             {'rank':3,'id':'L1'},{'rank':3,'id':'L1'},{'rank':2,'id':'L2'},{'rank':1,'id':'L2'}]
base_projected=[{'id':r['id']} for r in base_native]
base_groups=new.make_order_groups(base,base_native,base_projected)
for choice in ['B1','B2','B3']:
    for reverse in [False,True]:
        pred=[{'id':'H1'},{'id':'H2'},{'id':choice}]
        if reverse: pred.reverse()
        def run(p=pred):
            r=new.score(base,base_projected,p,diagnostic=True,order_groups=base_groups);assert r['exact'];return r
        event('synthetic_any_boundary_'+choice+'_reverse'+str(reverse),run)
for name,pred in [
 ('lower_duplicate_is_not_eligible',[{'id':'H1'},{'id':'H2'},{'id':'L1'}]),
 ('omit_higher_take_two_boundary',[{'id':'H1'},{'id':'B1'},{'id':'B2'}]),
 ('duplicate_predicted_high',[{'id':'H1'},{'id':'H1'},{'id':'B1'}]),
 ('all_boundary_omit_mandatory',[{'id':'B1'},{'id':'B2'},{'id':'B3'}]),
 ('predicted_null',[{'id':'H1'},{'id':'H2'},{'id':None}]),
 ('predicted_wrong_type',[{'id':'H1'},{'id':'H2'},{'id':False}]),
 ('unknown_ID',[{'id':'H1'},{'id':'H2'},{'id':'UNK'}]),
 ('too_few',[{'id':'H1'},{'id':'H2'}]),
 ('too_many',[{'id':'H1'},{'id':'H2'},{'id':'B1'},{'id':'B2'}])]:
    def run(p=pred):
        r=new.score(base,base_projected,p,diagnostic=True,order_groups=base_groups);assert not r['exact'];return r
    event('synthetic_reject_'+name,run)
for name,change in [
 ('duplicate_above',lambda x:x.__setitem__(1,dict(rank=5,id='H1'))),
 ('duplicate_boundary',lambda x:x.__setitem__(3,dict(rank=4,id='B1'))),
 ('duplicate_eligible_again_lower',lambda x:x.__setitem__(8,dict(rank=1,id='B1'))),
 ('duplicate_high_again_lower',lambda x:x.__setitem__(8,dict(rank=1,id='H1'))),
 ('unsorted_capture',lambda x:x.reverse()),
 ('invalid_gold_type_lower',lambda x:x.__setitem__(8,dict(rank=1,id=None))),
 ('missing_native_sort_key',lambda x:x.__setitem__(8,dict(id='L2')))]:
    ns=copy.deepcopy(base_native);change(ns);ps=[{'id':r['id']} for r in ns]
    event('synthetic_reject_'+name,lambda n=ns,p=ps:new.make_order_groups(base,n,p),True)
# No outside-boundary exemption when k reaches the duplicate group.
large=copy.deepcopy(base);large['collection']['value']=6;large['cardinality_policy']['value']=6
event('duplicate_at_new_cutoff_rejected',lambda:new.make_order_groups(large,base_native,base_projected),True)
# When k exceeds the pool, every record is eligible; no duplicate exemption.
large['collection']['value']=99;large['cardinality_policy']['value']=99
event('duplicate_when_all_rows_required_rejected',lambda:new.make_order_groups(large,base_native,base_projected),True)
# Native ordered multiset semantics have NOT been relaxed.
ordered=copy.deepcopy(base);ordered['collection']={'kind':'native_ordered_ties','source_order_keys':[{'source_column':'rank','direction':'desc'}],'tie_policy':'any_order_within_equal_keys'}
event('ordered_multiset_cross_rank_ambiguity_still_rejected',lambda:new.make_order_groups(ordered,base_native,base_projected),True)
# Generic two-source-column sorting remains intact with a boundary tie.
multi=copy.deepcopy(base);multi['collection']['source_order_keys']=[{'source_column':'rank','direction':'asc'},{'source_column':'secondary','direction':'desc'}]
ns=[{'id':'H1','rank':1,'secondary':9},{'id':'H2','rank':1,'secondary':8},
    {'id':'B1','rank':2,'secondary':5},{'id':'B2','rank':2,'secondary':5},
    {'id':'L1','rank':3,'secondary':7},{'id':'L1','rank':4,'secondary':7}]
ps=[{'id':r['id']} for r in ns];gs=new.make_order_groups(multi,ns,ps)
for b in ['B1','B2']:
    def run(b=b):
        r=new.score(multi,ps,[{'id':'H2'},{'id':b},{'id':'H1'}],diagnostic=True,order_groups=gs);assert r['exact'];return r
    event('multi_column_ascending_descending_boundary_'+b,run)
result={'status':'PASS','kind':'PROSPECTIVE_GENERIC_KERNEL_CONTROLS_NOT_INSTALLED_NOT_NATIVE_GATE',
        'full_source_conditional_population_rows':len(native),'full_population_records_retained':len(projected),
        'actual_source_population_duplicates_solely_below_boundary':new.validate_top_k_reachable_record_uniqueness(contract,groups),
        'controls':checks,'controls_passed':sum(r['pass'] for r in checks),
        'source_pool_proof_sha256':hashlib.sha256((previous/'actual_full_graph_coalesce_selection_proof_NOT_NATIVE_GOLD.json').read_bytes()).hexdigest(),
        'proposal_sha256':hashlib.sha256((HERE/'prospective_original_scorer.py').read_bytes()).hexdigest(),
        'limits':'Pure generic infrastructure proposal. Full native capture, exact question-specific contract, independent semantic review and production adoption remain separate root gates.',
        'native_calls':0,'API_calls':0,'public_changes':0,'central_changes':0}
(HERE/'actual_full_population_and_adversarial_controls.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','controls':len(checks),'full_population_rows':len(native),'deduplicated_rows':0}))
