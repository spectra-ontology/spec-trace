#!/usr/bin/env python3
"""Execute unchanged saved queries in the installed dependency environment.

The primary failed -I invocation and scores remain immutable. No model call,
query change, input change, or reference change is permitted in this diagnostic.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import sys

LOOP = Path(__file__).resolve().parent
EVALUATION = LOOP / 'root_RAN1_common3176_prepared_evaluation_v1'
OUTPUT = LOOP / 'root_RAN1_common3176_saved_query_environment_diagnostic_v1'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    assert not OUTPUT.exists()
    OUTPUT.mkdir()
    import neo4j
    runner = load(EVALUATION / 'run_separate_common3176_experiment.py', 'root_unchanged_frozen_RAN1_runner')
    cfg_path = EVALUATION / 'root_configuration.json'
    cfg = runner.config(cfg_path)
    runner.verify_freeze(cfg, cfg_path)
    trial = EVALUATION / 'actual_call_trial_v1'
    primary = trial / 'actual_results_summary.json'
    generated_path = trial / 'generated_before_execution.json'
    executed_path = trial / 'executed_predictions.json'
    before = {str(path): sha(path) for path in (primary, generated_path, executed_path, EVALUATION / 'precall_freeze.json')}
    save(OUTPUT / 'pre_execution_diagnostic_plan.json', {
        'status': 'INFRASTRUCTURE_ONLY_SAVED_QUERY_DIAGNOSTIC_NOT_PRIMARY_REPLACEMENT',
        'utc': datetime.now(timezone.utc).isoformat(), 'original_primary_pins': before,
        'change': 'Invoke the identical frozen execute_cypher function without Python -I, permitting the existing installed Neo4j driver.',
        'unchanged': ['all source/code/config freeze pins', 'model responses', 'generated query bytes', 'scoring definitions', 'native reference rows'],
        'python': sys.executable, 'python_version': sys.version,
        'neo4j_version': neo4j.__version__, 'neo4j_module': str(Path(neo4j.__file__).resolve()),
        'neo4j_module_sha256': sha(Path(neo4j.__file__)), 'wrapper_sha256': sha(Path(__file__)),
        'new_model_calls': 0, 'original560_admissions': 0,
    })
    generated = read(generated_path)['results']
    executed = read(executed_path)['results']
    sys.path.insert(0, str(EVALUATION / 'scoring'))
    scorer = load(EVALUATION / 'scoring/original_scorer.py', 'root_unchanged_RAN1_score')
    rows = []
    for ident, case in cfg['cases'].items():
        record = generated[ident]['Text2Cypher']
        assert record['status'] == 'QUERY_READY'
        assert executed[ident]['Text2Cypher']['execution']['error_class'] == 'ModuleNotFoundError'
        query = record['generated_query']
        assert hashlib.sha256(query.encode()).hexdigest() == record['query_sha256']
        outcome = runner.execute_cypher(query, cfg, OUTPUT / (ident + '.stages.json'))
        save(OUTPUT / (ident + '.execution.json'), outcome)
        definition = read(Path(case['definition']['path']))
        native = [json.loads(line) for line in Path(case['actual_reference_rows']['path']).read_text().splitlines() if line]
        projected = [{field['name']: row[field['name']] for field in definition['required_fields']} for row in native]
        groups = scorer.make_order_groups(definition, native, projected) if definition['collection']['kind'] == 'top_k_boundary_ties' else None
        score = scorer.score(definition, projected, outcome['rows'] if outcome['complete'] else [], diagnostic=True, order_groups=groups)
        row = {'id': ident, 'method': 'Text2Cypher', 'unchanged_query_sha256': record['query_sha256'],
               'execution_status': outcome['status'], 'complete': outcome['complete'], 'score': score}
        rows.append(row)
        print(json.dumps(row), flush=True)
    runner.verify_freeze(cfg, cfg_path)
    assert before == {path: sha(Path(path)) for path in before}
    save(OUTPUT / 'actual_environment_only_diagnostic_scores.json', {
        'status': 'ACTUAL_ENVIRONMENT_ONLY_SAVED_QUERY_DIAGNOSTIC_NOT_PRIMARY_REPLACEMENT',
        'utc': datetime.now(timezone.utc).isoformat(), 'results': rows,
        'Text2Cypher_diagnostic_macro': {'N': 3, 'f1': sum(row['score']['f1'] for row in rows) / 3,
                                       'exact': sum(row['score']['exact'] for row in rows)},
        'original_primary_pins_unchanged': before, 'all161_pre_call_freeze_pins_unchanged': True,
        'model_calls': 0, 'query_bytes_changed': False, 'original560_admissions': 0,
    })


if __name__ == '__main__':
    main()
