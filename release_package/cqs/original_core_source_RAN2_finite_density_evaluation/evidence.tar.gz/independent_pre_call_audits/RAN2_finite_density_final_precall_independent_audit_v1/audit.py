#!/usr/bin/env python3
"""Independent small-artifact and memory-only pre-call checks; no DB/API calls."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime, timezone
import ast, contextlib, copy, hashlib, importlib.util, io, json, sys
sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = Path('/home/sihyeon/workspace/spectra')
O = ROOT/'logs/pending-tasks/spectracq-core-contract-2026-10-13/empirical/overnight_reaudit/root_evidence/two_agent_unresolved_loop'
E = O/'root_RAN2_finite_density_prepared_evaluation_v1'
EXPECTED_CFG = '3b6bee2be34ae3a2b8752b945ffff92df56571a07ec5bdde18169af3e6f50d18'
DENIED = []
def audit_hook(event, args):
    if event.startswith(('socket.', 'subprocess.')) or event == 'sqlite3.connect' or event == 'os.system':
        DENIED.append(event)
        raise RuntimeError('Independent audit prohibits network, subprocess, SQLite, and native execution')
sys.addaudithook(audit_hook)
def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name, value):
    with (OUT/name).open('x') as f: f.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
def module(p, name):
    spec=importlib.util.spec_from_file_location(name,p); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def collect_pins(x):
    found=[]
    if isinstance(x,dict):
        if isinstance(x.get('path'),str) and isinstance(x.get('sha256'),str): found.append(x)
        for v in x.values(): found.extend(collect_pins(v))
    elif isinstance(x,list):
        for v in x: found.extend(collect_pins(v))
    return found
def main():
    assert not (OUT/'receipt.json').exists()
    cfg_path=E/'root_configuration_final.json'; assert sha(cfg_path)==EXPECTED_CFG
    cfg=read(cfg_path); initial_trial=Path(cfg['trial_directory']).exists()
    initial_freeze=(Path(cfg['trial_directory']).parent/'precall_freeze.json').exists()
    assert not initial_trial and not initial_freeze, 'Expected uncalled, unfrozen prospective cohort'
    checked={}; large=[]
    for pin in collect_pins(cfg):
        p=Path(pin['path']);assert p.is_file()
        if p.stat().st_size>10_000_000:
            large.append({'path':str(p),'bytes':p.stat().st_size,'expected_sha256':pin['sha256'],
                          'fresh_large_file_hash_or_DB_read_not_performed':True})
            continue
        actual=sha(p);assert actual==pin['sha256'],str(p)
        checked[str(p)]={'sha256':actual,'bytes':p.stat().st_size}
    assertions=[]
    for name,pin in cfg['gate_receipts'].items():
        body=read(pin['path'])
        for a in pin['assertions']:
            v=body
            for k in a['key_path']:v=v[k]
            assert type(v) is type(a['equals']) and v==a['equals'],(name,a,v)
            assertions.append({'gate':name,'key_path':a['key_path'],'actual':v})
    s=module(E/'runtime/structured_adapter.py','independent_density_structured')
    r=module(E/'runtime/retrieval_adapter.py','independent_density_retrieval')
    public=read(E/'public_tasks.json');assert len(public)==1
    task=public[0];definition=read(cfg['cases'][task['id']]['definition']['path'])
    assert task['question_en']==definition['question_en']
    assert hashlib.sha256(task['question_en'].encode()).hexdigest()=='17e2bd7058d434f51fcef2f6ae700f31b79ff4a792968de93d82e51f3c02f9de'
    assert task['required_fields']==[{k:f[k] for k in ('name','type','nullable')}for f in definition['required_fields']]
    assert task['collection']=={'kind':'set'} and task['cardinality_policy']=={'mode':'exact','value':5}
    source_def=read(definition['prospective_source_definition']['path'])
    assert definition['original_query']==source_def['original_query'] and definition['original_query_unchanged'] is True
    for key in ('TTL_input','SQL_input','FTS_input'):
        assert read(E/'prospective_preparation.json')[key]==cfg[key]
    assert r.CORPUS_DIR/('ran2.sqlite3')==Path(cfg['FTS_input']['path'])
    assert r.PROTOCOL['source_cutoff_relation_to_frozen_graph']=='EXACT_SAME_SEPARATE_ENRICHED_GRAPH_SOURCE'
    assert r.public_contract(task)['selection_policy']==task['selection_policy']
    fake_calls=[]
    class Caller:
        def call(self, ident, messages, max_tokens):
            fake_calls.append({'id':ident,'messages':messages,'max_tokens':max_tokens})
            content='{"query":"synthetic followup"}' if ident.endswith('_D_followup') else '{"records":[],"abstain":true,"complete":true}'
            return {'ok':True,'finish_reason':'stop','content':content,'usage':{'cost':0},'provider':'MOCK','request_path':None,'response_path':None}
    structured_prompts=[]
    for method,schema in [('Text2Cypher','graph_schema'),('Text2SQL','sql_schema')]:
        t=copy.deepcopy(task);t[schema]=read(E/(schema+'.json'))
        messages=s.messages_for(t,method)
        body=json.loads(messages[1]['content'])
        assert body['question']==task['question_en'] and body['selection_policy']==task['selection_policy']
        assert set(body)=={'question','output_format','selection_policy','schema'}
        s.reject_private(body)
        structured_prompts.append({'id':task['id']+'_'+method,'messages':messages,'max_tokens':s.MAX_GENERATION_TOKENS})
    # Module-memory fixtures replace only data access. No SQL/FTS source is opened.
    r.prepare_corpus_inventory=lambda unused:{'shards':[{'WG':'RAN2','path':'SYNTHETIC_NOT_OPENED','sha256':'MOCK_SOURCE'}]}
    r.retrieve=lambda *a,**kw:{'status':'OK','context_candidate_truncated':False,'hits':[]}
    stats={'document_selection_truncated':False}
    r.contexts=lambda *a,**kw:([{'formatted':'SYNTHETIC_NONANSWER_PASSAGE','collection':'MOCK','point_id':'MOCK','chunk_id':'MOCK','source_text_truncated':False,'source_header_truncated':False}],stats)
    for method in ('C','D'):
        result=r.evaluate(copy.deepcopy(task),method,Caller(),OUT/'memory_only_prompt_mock')
        assert result['status']=='abstained' and result['records']==[]
    assert len(fake_calls)==3 and len(structured_prompts)+len(fake_calls)==5
    for c in fake_calls:
        body=json.loads(c['messages'][1]['content'].split('\nSOURCE PASSAGES:\n')[0])
        assert body['question']==task['question_en'] and body['contract']==r.public_contract(task)
        s.reject_private(body)
    all_prompts=structured_prompts+fake_calls
    prompt_pins=[]
    worst=[]
    for c in all_prompts:
        messages=copy.deepcopy(c['messages'])
        if c in fake_calls:
            prefix=messages[1]['content'].split('\nSOURCE PASSAGES:\n')[0]
            messages[1]['content']=prefix+'\nSOURCE PASSAGES:\n'+'x'*(48000+22)
        characters=sum(len(m['content'])for m in messages)
        estimate=2*(characters/3*0.000005+c['max_tokens']*0.000025)
        worst.append({'id':c['id'],'maximum_message_characters':characters,'max_tokens':c['max_tokens'],'both_attempts_approximate_reservation_usd':estimate})
        prompt_pins.append({'id':c['id'],'sha256':hashlib.sha256(s.canonical(c['messages']).encode()).hexdigest(),'max_tokens':c['max_tokens']})
    assert sum(x['both_attempts_approximate_reservation_usd']for x in worst)<cfg['budget_usd']
    write('actual_memory_only_common_five_stage_prompt_and_budget_controls.json',{'status':'PASS','stages':prompt_pins,'common_selection_policy_equal':True,'private_evidence_fields_excluded':True,'SQL_physical_catalog_not_reexecuted':True,'worst_bounded_context_budget_calculation':worst,'estimated_two_attempt_sum_usd':sum(x['both_attempts_approximate_reservation_usd']for x in worst),'not_a_provider_billing_cap':True,'calls':0})
    # Execute exactly the author's pure scorer controls with only its output path redirected.
    code=ast.parse((E/'run_four_field_scoring_controls.py').read_text())
    for node in ast.walk(code):
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='out'for t in node.targets):
            assert ast.unparse(node.value)=="HERE / 'actual_four_field_scoring_controls.json'"
            node.value=ast.parse("OUT / 'actual_independent_replayed_30_scoring_controls.json'",mode='eval').body
    ns={'__file__':str(E/'run_four_field_scoring_controls.py'),'__name__':'independent_scoring_replay','OUT':OUT}
    stream=io.StringIO()
    with contextlib.redirect_stdout(stream):
        exec(compile(ast.fix_missing_locations(code),str(E/'run_four_field_scoring_controls.py'),'exec'),ns)
        ns['main']()
    replay=read(OUT/'actual_independent_replayed_30_scoring_controls.json');saved=read(E/'actual_four_field_scoring_controls.json')
    assert replay==saved and len(replay['controls'])==30
    parse_cases=[]
    for name,text in [('prose','Answer: {"records":[],"abstain":true,"complete":true}'),('fence','```json\n{"records":[],"abstain":true,"complete":true}\n```'),('nonfinite','{"records":[{"density":NaN}],"abstain":false,"complete":true}'),('boolean_string','{"records":[],"abstain":"true","complete":true}')]:
        try:r.parse_answer(text)
        except (ValueError,TypeError):parse_cases.append({'case':name,'rejected':True})
        else:raise AssertionError(name)
    # State the existing parser's actual edge behavior, without inventing stricter historical validation.
    duplicate='{"records":[{"density":0,"density":1}],"abstain":false,"complete":true}'
    duplicate_last_wins=r.parse_answer(duplicate)['records'][0]['density']==1
    assert DENIED==[]
    for p in E.rglob('*.py'):ast.parse(p.read_text())
    assert sha(cfg_path)==EXPECTED_CFG
    receipt={'status':'PASS_INDEPENDENT_PROSPECTIVE_PRECALL_REVIEW_NO_BLOCKERS','review_role':'Independent nonblind AI read-only runtime audit; expert/human validation n=0',
        'utc':datetime.now(timezone.utc).isoformat(),'root_configuration':{'path':str(cfg_path),'sha256':EXPECTED_CFG},
        'small_configuration_pins_checked':len(checked),'checked_pins':checked,'large_source_assets_not_rehashed_or_opened_as_DB':large,
        'gate_classes':len(cfg['gate_receipts']),'strict_typed_assertions_checked':len(assertions),'actual_gate_assertions':assertions,
        'runtime_and_scoring_pins':{str(p.relative_to(E)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(E.rglob('*.py'))if '__pycache__'not in p.parts},
        'replayed_scorer_controls':30,'scoring_control_results_identical':True,'strict_retrieval_parser_negative_controls':parse_cases,
        'memory_only_public_prompt_stages':5,'initial_trial_exists':initial_trial,'initial_precall_freeze_exists':initial_freeze,
        'findings':[
          'Same declared additive current64 finite-dependency snapshot is pinned for native, SQL, and generically reconstructed FTS. Shared facts do not establish equal bounded exposure.',
          'The four nonnull named fields retain integer count roles and exact finite numeric density. Exact selected-five set; strict fifth/sixth gap established by saved native/independent records.',
          'Scoring reparses valid retrieval answer source JSON with Decimal, preserving raw numeral precision before typed record comparison. Thirty pure controls independently replayed identically.',
          'Physical SQL schema validation precedes its caller. Owned native lifecycle uses explicit expected stopped/running state, immutable image/source/run identity, 26GiB host floor, exact2GiB RAM/swap and1CPU, read-plan checks, full consume, rollback, finally owned stop.',
          'First trial and freeze refuse reuse. Four method items remain in the denominator; expected five request stages includes one D followup. Transport retry only, identical payload, no quality retry or model-output-based repair.',
          'Unknown-cost latch blocks new work and unsent retries; up to four requests already in flight may complete. Approximate reservation is not a provider billing cap or live credit observation.',
          'Python /usr/bin/python3 -B is required; -I can hide the verified user-site neo4j package. The saved same-interpreter import preflight succeeds without a database call.'
        ],
        'limits':[
          'No fresh raw source reparse, large-file hash, native, SQL, FTS, physical DDL execution, or provider call by this audit. Root actual saved proofs are pinned, not represented as independent reexecution.',
          'Unrelated old source property/hierarchy/reference differences remain; this is finite metric dependency fidelity, not complete source graph certification or original560 admission.',
          'Existing JSON parser rejects prose/fences/nonfinite literals but accepts duplicate object keys with Python last-key-wins and extra answer envelope keys. This is recorded actual behavior, not a claim of duplicate-key strictness.',
          'Raw provider cost precision must be recomputed from saved JSON as Decimal in the post-call audit; client running cost/reservation fields use binary floats.'
        ],'duplicate_object_key_last_wins_observed':duplicate_last_wins,'blocking_findings':[],
        'new_API_calls':0,'native_or_Docker_calls':0,'SQL_or_FTS_queries':0,'central_or_public_or_source_runtime_changes':0,'original560_admission_delta':0,
        'prohibited_execution_attempts':DENIED,'audit_code_sha256':sha(__file__)}
    write('receipt.json',receipt)
    print(json.dumps({'status':receipt['status'],'receipt_sha256':sha(OUT/'receipt.json'),'small_pins':len(checked),'gate_assertions':len(assertions),'scorer_controls':30,'maximum_approximate_two_attempt_reservation_usd':sum(x['both_attempts_approximate_reservation_usd']for x in worst)}))
if __name__=='__main__':main()
