#!/usr/bin/env python3
"""Memory-only ownership/lifecycle tests of the separate root execution watchdog."""
from pathlib import Path
from types import SimpleNamespace
import contextlib, copy, hashlib, importlib.util, inspect, io, json, subprocess, sys
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
ROOT=Path('/home/sihyeon/workspace/spectra')
O=ROOT/'logs/pending-tasks/spectracq-core-contract-2026-10-13/empirical/overnight_reaudit/root_evidence/two_agent_unresolved_loop'
E=O/'root_RAN2_finite_density_prepared_evaluation_v1'
SCRIPT=E/'run_guarded_generated_execution.py'
EXPECTED='ce9aabce98a0d372d959078bba015b690d438b632fd58f991e5d8156713cb322'
GIB=1024**3
DENIED=[]
def hook(event,args):
    if event.startswith(('socket.','subprocess.')) or event in ('sqlite3.connect','os.system'):
        DENIED.append(event);raise AssertionError('Forbidden actual execution '+event)
sys.addaudithook(hook)
def module(p,n):
    s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
    with p.open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
def base_fixture(cfg):
    t=cfg['native_container']
    return {'Name':'/'+t['name'],'Image':t['image_id'],
      'Config':{'Labels':{'spectra.frozen.owner':'contract_repair_v1','spectra.frozen.run_uuid':t['run_uuid'],'spectra.frozen.source_sha256':t['source_sha256']}},
      'HostConfig':{'Memory':2*GIB,'MemorySwap':2*GIB,'NanoCpus':10**9,'PortBindings':{'7687/tcp':[{'HostIp':'127.0.0.1','HostPort':str(t['port'])}]}},'State':{'Running':False}}
def main():
    assert sha(SCRIPT)==EXPECTED
    cfg=json.loads((E/'root_configuration_final.json').read_text())
    stage=module(E/'runtime/container_stage_guard.py','watchdog_audit_stage')
    mutations={
      'owner':lambda c,r:r['Config']['Labels'].__setitem__('spectra.frozen.owner','foreign'),
      'UUID':lambda c,r:r['Config']['Labels'].__setitem__('spectra.frozen.run_uuid','foreign'),
      'inspect_source':lambda c,r:r['Config']['Labels'].__setitem__('spectra.frozen.source_sha256','foreign'),
      'configured_source':lambda c,r:c['native_container'].__setitem__('source_sha256','foreign'),
      'container_name':lambda c,r:c['native_container'].__setitem__('name','foreign-container'),
      'image':lambda c,r:r.__setitem__('Image','foreign'),
      'memory':lambda c,r:r['HostConfig'].__setitem__('Memory',0),
      'memory_swap':lambda c,r:r['HostConfig'].__setitem__('MemorySwap',-1),
      'CPU':lambda c,r:r['HostConfig'].__setitem__('NanoCpus',0),
      'loopback_port':lambda c,r:r['HostConfig']['PortBindings']['7687/tcp'][0].__setitem__('HostIp','0.0.0.0'),
      'paused':lambda c,r:r['State'].__setitem__('Paused',True)}
    ownership=[]
    for name,mutate in mutations.items():
        w=module(SCRIPT,'watchdog_ownership_'+name);c=copy.deepcopy(cfg);raw=base_fixture(c);raw['State']['Running']=True
        mutate(c,raw);commands=[]
        def command(*args):
            commands.append(list(args))
            if args[:2]==('docker','inspect'):return json.dumps([raw])
            raise AssertionError('Refused ownership may never stop a container')
        w.command=command;w.module=lambda *args:stage
        error=None
        try:w.cleanup_owned(c)
        except (AssertionError,ValueError)as exc:error=type(exc).__name__
        assert error and not any(x[1]=='stop'for x in commands)
        ownership.append({'case':name,'rejected':True,'mock_stop_commands':0,'error_class':error})
    cases=[]
    for name in ('normal_complete','linux_low_reserve','windows_low_reserve','SIGTERM_wait_timeout_then_kill','prestart_low_memory','prestart_wrong_owner','cleanup_foreign_owner'):
        case=OUT/name;case.mkdir();trial=case/'trial';trial.mkdir();write(trial/'generated_before_execution.json',{})
        c=copy.deepcopy(cfg);c['trial_directory']=str(trial);p=case/'root_config.json';write(p,c)
        raw=base_fixture(c);events=[];clock=[0.0];read_count=[0];win_count=[0]
        child_state={'running':True,'polls':0,'terminated':False,'killed':False}
        w=module(SCRIPT,'watchdog_scenario_'+name);w.HERE=case
        fake_runner=SimpleNamespace(config=lambda path:c,verify_freeze=lambda *args:{'MOCK_ONLY':True})
        w.module=lambda path,label:stage if Path(path).name=='container_stage_guard.py'else fake_runner
        def command(*args):
            events.append(list(args))
            if args[:2]==('docker','inspect'):return json.dumps([raw])
            if args[:2]==('docker','ps'):return ''
            if args[:2]==('docker','stop'):
                raw['State']['Running']=False;return c['native_container']['name']
            raise AssertionError(args)
        w.command=command
        def linux():
            read_count[0]+=1
            if name=='prestart_low_memory':return 25*GIB
            return (15 if read_count[0]>1 and name in ('linux_low_reserve','SIGTERM_wait_timeout_then_kill','cleanup_foreign_owner')else 28)*GIB
        def windows():
            win_count[0]+=1
            return (15 if name=='windows_low_reserve' and win_count[0]>1 else 28)*GIB
        w.linux_available=linux;w.windows_available=windows
        w.time=SimpleNamespace(monotonic=lambda:clock[0],sleep=lambda sec:clock.__setitem__(0,clock[0]+sec))
        if name=='prestart_wrong_owner':raw['Config']['Labels']['spectra.frozen.owner']='foreign'
        class Child:
            pid=12345
            def __init__(self,*args,**kw):
                events.append(['MOCK_POPEN',*args[0]]);raw['State']['Running']=True
                if name=='cleanup_foreign_owner':raw['Config']['Labels']['spectra.frozen.owner']='foreign'
            def poll(self):
                child_state['polls']+=1
                if name=='normal_complete'and child_state['polls']>=2:
                    child_state['running']=False;raw['State']['Running']=False
                if name=='windows_low_reserve':clock[0]+=10
                return None if child_state['running']else (-9 if child_state['killed']else -15 if child_state['terminated']else 0)
            def terminate(self):
                events.append(['MOCK_TERMINATE']);child_state['terminated']=True
                if name!='SIGTERM_wait_timeout_then_kill':child_state['running']=False
            def kill(self):events.append(['MOCK_KILL']);child_state['killed']=True;child_state['running']=False
            def wait(self,timeout=None):
                if child_state['running']:raise subprocess.TimeoutExpired('MOCK_CHILD',timeout)
                return -9 if child_state['killed']else -15 if child_state['terminated']else 0
        w.subprocess=SimpleNamespace(Popen=Child,TimeoutExpired=subprocess.TimeoutExpired)
        error=None
        with contextlib.redirect_stdout(io.StringIO()):
            try:w.run(p)
            except AssertionError as exc:error=str(exc)
        result=json.loads((trial/'actual_continuous_generated_execution_guard.json').read_text())
        if name=='normal_complete':assert result['status']=='PASS'and error is None
        else:assert result['status']=='FAIL_PRESERVED'and error is not None
        if name.startswith('prestart_'):assert not result['native_child_started']and not any(e[0]=='MOCK_POPEN'for e in events)
        elif name=='cleanup_foreign_owner':
            assert result['owned_cleanup']['status']=='OWNERSHIP_OR_CLEANUP_FAILURE_PRESERVED'
            assert not any(e[:2]==['docker','stop']for e in events)
        else:assert result['owned_cleanup']['owned_container_stopped']is True and raw['State']['Running']is False
        if name=='SIGTERM_wait_timeout_then_kill':assert child_state['killed']and result['returncode']==-9
        cases.append({'case':name,'status':result['status'],'mock_commands':events,'child_state':child_state,'receipt_sha256':sha(trial/'actual_continuous_generated_execution_guard.json')})
    signal_source=inspect.getsource(subprocess.Popen.send_signal)
    assert 'except ProcessLookupError:'in signal_source and 'self.poll()'in signal_source
    assert DENIED==[]and sha(SCRIPT)==EXPECTED
    receipt={'status':'PASS_INDEPENDENT_MEMORY_ONLY_WATCHDOG_REVIEW','wrapper':{'path':str(SCRIPT),'sha256':EXPECTED},
      'ownership_negative_controls':ownership,'lifecycle_controls':cases,
      'actual_subprocess_native_SQL_FTS_API_calls':0,'prohibited_actual_execution_attempts':DENIED,
      'review_role':'Independent nonblind AI; human/expert validation n=0',
      'findings':['Original runner, public task, model, scorer, and generated query bytes are not modified by the wrapper. It invokes only the frozen runner execute phase.','Own exact name/UUID/source/image/loopback/RAM/swap/CPU guards apply before start and before fallback cleanup. Foreign ownership prevents stop.','Low Linux reserve, low Windows reserve, failed child termination timeout, and prestart errors all preserve FAIL receipts in mocked scenarios; the terminated child is killed after45s only in the timeout scenario.','Initial poll-to-terminate ProcessLookupError concern was withdrawn after directly inspecting the actual Python3.10 Popen.send_signal implementation: it repolls and suppresses ProcessLookupError. No impossible mock was treated as a real blocker.'],
      'limitations':['Memory checks are sampled, not a hard real-time guarantee. Linux2s/Windows10s are nominal intervals; synchronous Windows query can block up to20s plus scheduler/command delays.','The module itself does not load/verify its own SHA; ROOT must add the wrapper and audit pin to the final configuration before freeze.','No actual child process, Docker/native lifecycle, memory pressure, source/SQL/FTS, or model API executed by this audit. Root operational execution remains pending.','As with any Python cleanup path, a second asynchronous interruption during finally or an unrecoverable OS failure can interrupt cleanup; this test does not establish guaranteed cleanup under arbitrary system failure.'],
      'blocking_findings':[],'audit_code_sha256':sha(__file__)}
    write(OUT/'receipt.json',receipt)
    print(json.dumps({'status':receipt['status'],'receipt_sha256':sha(OUT/'receipt.json'),'ownership_negative_controls':len(ownership),'lifecycle_controls':len(cases),'actual_execution_calls':0}))
if __name__=='__main__':main()
