#!/usr/bin/env python3
"""Independent read-only replay of saved first-five RAN2 density evidence.

No API, subprocess, native, SQLite/FTS execution. Pure prompt/parse/score only.
The three large source files are not reopened or newly certified by this audit.
"""
from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / 'CLAUDE.md').exists())
O = HERE.parents[2]
E = O / 'root_RAN2_finite_density_prepared_evaluation_v1'
T = E / 'first_trial_20261019'
IDENT = 'RAN2_P3_CQ5-3'
METHODS = ('Text2Cypher', 'Text2SQL', 'C', 'D')
STAGES = ('Text2Cypher', 'Text2SQL', 'C_answer', 'D_followup', 'D_answer')
opened_forbidden_events = []

def isolation(event, args):
    if event in {'subprocess.Popen', 'os.system', 'sqlite3.connect'} or event.startswith('socket.'):
        opened_forbidden_events.append(event)
        raise RuntimeError('Independent audit forbids ' + event)

sys.addaudithook(isolation)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path, exact=False):
    return json.loads(Path(path).read_text(), **({'parse_float': Decimal} if exact else {}))

def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)

def pin(path):
    p = Path(path)
    return {'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': sha(p)}

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m

def check(value, message):
    assert value, message

cfg_path = E / 'root_configuration_ready_with_watchdog.json'
freeze_path = E / 'precall_freeze.json'
check(sha(cfg_path) == '86a402f871f0cd1f9ec87c7920587fc48a0adea500a1effbfa3da04043be786e', 'exact ready config')
check(sha(freeze_path) == 'aa817d9a6e2dec4074830f78c17d15bdefdf17746783182ecdc356f969add437', 'exact frozen inputs')
cfg, freeze = read(cfg_path), read(freeze_path)
check(freeze['root_configuration_sha256'] == sha(cfg_path), 'freeze/config link')
check(freeze['status'] == 'FROZEN_BEFORE_ALL_NEW_PAID_CALLS', 'freeze status')
check(freeze['expected_request_stages'] == 5 and freeze['quality_retries'] == 0, 'first5 fixed')
check(freeze['N_per_method'] == 1 and freeze['methods'] == list(METHODS), 'denominators frozen')
large_paths = {str(Path(cfg[k]['path']).resolve()): cfg[k]['sha256'] for k in ('TTL_input', 'SQL_input', 'FTS_input')}
small_pins, large_not_reopened = [], []
for item in freeze['pinned_files']:
    p = Path(item['path']).resolve()
    if str(p) in large_paths:
        check(item['sha256'] == large_paths[str(p)], 'large source metadata link')
        large_not_reopened.append(dict(item, audit_action='metadata comparison only; not opened or rehashed'))
    else:
        check(p.stat().st_size == item['bytes'] and sha(p) == item['sha256'], 'frozen small bytes: ' + str(p))
        small_pins.append(item)
check(len(large_not_reopened) == 3 and len(small_pins) == 45, 'closed48 frozen inventory')

structured = load(E / 'runtime/structured_adapter.py', 'independent_saved_R2_structured')
retrieval = load(E / 'runtime/retrieval_adapter.py', 'independent_saved_R2_retrieval')
sys.path.insert(0, str(E / 'scoring'))
scorer = load(E / 'scoring/original_scorer.py', 'independent_saved_R2_scorer')
task = read(E / 'public_tasks.json')[0]
check(task['id'] == IDENT and len(read(E / 'public_tasks.json')) == 1, 'one original question')
question_sha = hashlib.sha256(task['question_en'].encode()).hexdigest()
check(question_sha == '17e2bd7058d434f51fcef2f6ae700f31b79ff4a792968de93d82e51f3c02f9de', 'unchanged EN')
check(task['repair_sha256'] == 'bc739310bc8d3b131717dd95a7c873156822bc670009c83366e0aed88a69bc5c', 'exact repair')
structured.reject_private(task)

requests, outcomes, responses, call_rows = {}, {}, {}, []
calls = T / 'calls'
check(len(list(calls.glob('*.request.json'))) == 5, 'exact5 saved requests')
check(len(list(calls.glob('*.response.json'))) == 5, 'exact5 saved responses')
check(len(list(calls.glob('*.outcome.json'))) == 5, 'exact5 saved outcomes')
check(not list(calls.glob('*.attempt[1-9]*')), 'no saved additional attempts')
cost = Decimal(0)
tokens = {'prompt_tokens': 0, 'completion_tokens': 0, 'total_tokens': 0}
for stage in STAGES:
    name = IDENT + '_' + stage
    reqp, respp, outp = (calls / (name + suffix) for suffix in ('.request.json', '.attempt0.response.json', '.outcome.json'))
    req, raw, out = read(reqp), read(respp, exact=True), read(outp)
    requests[stage], responses[stage], outcomes[stage] = req, raw, out
    payload = req['payload']
    check(req['request_id'] == raw['request_id'] == name, 'request identity')
    check(req['payload_sha256'] == hashlib.sha256(json.dumps(payload, ensure_ascii=False).encode()).hexdigest(), 'exact serialized request hash')
    check(req['authorization_header_omitted'] is True, 'no saved credential')
    check(payload['model'] == 'anthropic/claude-opus-4.8' and payload['provider'] == {'only': ['Anthropic'], 'allow_fallbacks': False, 'require_parameters': True}, 'fixed provider/model')
    check(payload['response_format'] == {'type': 'json_object'} and payload['reasoning'] == {'enabled': False} and payload['stream'] is False, 'fixed protocol envelope')
    check(payload['max_tokens'] == (4096 if stage in METHODS[:2] else 1024 if stage == 'D_followup' else 8192), 'fixed stage token cap')
    check(freeze['utc'] < req['created_utc'] < raw['received_utc'], 'freeze precedes first request and response')
    check(raw['attempt'] == 0 and raw['http_status'] == 200, 'first response HTTP200')
    response = raw['response']
    check(response['model'] == payload['model'] and response['provider'] == 'Anthropic', 'actual model/provider')
    check(len(response['choices']) == 1, 'one actual choice')
    choice = response['choices'][0]
    check(choice['finish_reason'] == 'stop' and choice['native_finish_reason'] == 'end_turn', 'actual normal stop')
    check(choice['message']['refusal'] is None and choice['message']['reasoning'] is None, 'no refusal/hidden reasoning')
    check(out['ok'] is True and out['error'] is None and out['content'] == choice['message']['content'], 'outcome equals exact raw response')
    check(out['attempts'] == [{'attempt': 0, 'http_status': 200, 'response_path': str(respp), 'retryable': False}], 'one attempt; no quality or transport retry')
    check(out['request_path'] == str(reqp) and out['response_path'] == str(respp), 'exact saved paths')
    check(out['unknown_cost_attempts'] == 0, 'known cost')
    usage = response['usage']
    check(type(usage['cost']) is Decimal and usage['cost'].is_finite() and usage['cost'] >= 0, 'finite raw Decimal cost')
    check(usage['cost'] == usage['cost_details']['upstream_inference_cost'], 'raw total cost detail')
    check(usage['cost'] == usage['cost_details']['upstream_inference_prompt_cost'] + usage['cost_details']['upstream_inference_completions_cost'], 'raw component sum')
    check(usage['prompt_tokens'] + usage['completion_tokens'] == usage['total_tokens'], 'tokens sum')
    check(usage['completion_tokens_details']['reasoning_tokens'] == usage['prompt_tokens_details']['cached_tokens'] == 0, 'actual reasoning/cache0')
    cost += usage['cost']
    for key in tokens:
        tokens[key] += usage[key]
    call_rows.append({'stage': stage, 'request': pin(reqp), 'response': pin(respp), 'outcome': pin(outp), 'attempt': 0,
                     'http_status': 200, 'finish_reason': 'stop', 'native_finish_reason': 'end_turn',
                     'cost_usd_decimal': str(usage['cost']), **{k: usage[k] for k in tokens},
                     'request_messages_sha256': hashlib.sha256(canonical(payload['messages']).encode()).hexdigest()})
check(cost == Decimal('0.497470'), 'exact first5 Decimal total')
root_cost = read(T / 'actual_root_decimal_cost_receipt.json')
check(Decimal(root_cost['new_cost_usd_decimal']) == cost and root_cost['new_received_model_calls'] == 5, 'root cost independent agreement')
check(root_cost['live_credit_balance_observed'] is False, 'historical estimate not live balance')
usage_saved = read(T / 'usage.json')
check(usage_saved['received_response_calls'] == 5 and usage_saved['unknown_cost_attempts'] == 0 and usage_saved['halted_unknown_cost'] is False, 'received denominator/unknown0')
check(abs(Decimal(str(usage_saved['known_actual_cost_usd'])) - cost) < Decimal('0.000000000001'), 'float reporting artifact only')

generated = read(T / 'generated_before_execution.json')
executed = read(T / 'executed_predictions.json')
frozen_queries = read(T / 'before_execution_queries_frozen.json')
summary = read(T / 'actual_results_summary.json')
check(generated['freeze_sha256'] == sha(freeze_path) and generated['database_execution_during_generation'] is False, 'generation freeze/noDB')
check(frozen_queries['generated_record_sha256'] == sha(T / 'generated_before_execution.json'), 'beforeexecution exact generation record')
check(set(generated['results'][IDENT]) == set(METHODS) == set(executed['results'][IDENT]), 'all4 outcome slots')
prompt_rows = []
for method in METHODS[:2]:
    inp = dict(task)
    inp['graph_schema' if method == 'Text2Cypher' else 'sql_schema'] = read(E / ('graph_schema.json' if method == 'Text2Cypher' else 'sql_schema.json'))
    rebuilt = structured.messages_for(inp, method)
    check(requests[method]['payload']['messages'] == rebuilt, 'byte-equivalent original structured prompt ' + method)
    g, x = generated['results'][IDENT][method], executed['results'][IDENT][method]
    query_obj = json.loads(outcomes[method]['content'])
    check(set(query_obj) == {'query', 'abstain'} and query_obj['abstain'] is False and type(query_obj['query']) is str, 'strict query envelope')
    query_sha = hashlib.sha256(query_obj['query'].encode()).hexdigest()
    check(g['generated_query'] == x['generated_query'] == query_obj['query'], 'execution exact generated query')
    check(g['query_sha256'] == x['query_sha256'] == frozen_queries['queries'][IDENT][method] == query_sha, 'frozen query hash chain')
    check(g['status'] == 'QUERY_READY' and x['status'] == x['execution']['status'] == 'OK', 'actual successful execution')
    check(g['abstain'] is False and x['abstain'] is False, 'empty output is not abstention')
    check(g['prompt_sha256'] == hashlib.sha256(canonical(rebuilt).encode()).hexdigest(), 'prompt hash exact')
    check(x['private_evidence_read_by_generator'] is False and x['adapter_sha256'] == sha(E / 'runtime/structured_adapter.py'), 'frozen gold-free adapter')
    check(x['records'] == x['execution']['rows'] and x['execution']['complete'] is True and x['execution']['truncated'] is False, 'all retained execution rows')
    prompt_rows.append({'stage': method, 'reconstruction': 'exact frozen messages_for(task + value-free method schema)',
                        'query_sha256': query_sha, 'prompt_sha256': g['prompt_sha256'], 'execution_rows': len(x['records'])})

public_contract = retrieval.public_contract(task)
base_user = retrieval.canonical({'question': task['question_en'], 'contract': public_contract}) + '\nSOURCE PASSAGES:\n'
contexts = {}
for method in ('C', 'D'):
    for kind in ('initial', 'final'):
        path = T / 'retrieval' / method / IDENT / (kind + '_context.json')
        ctx = read(path)
        docs, stats = ctx['documents'], ctx['stats']
        passage = '\n\n'.join(d['formatted'] for d in docs)
        check(len(docs) == stats['selected_documents'] == 12, 'saved nonempty bounded context')
        check(len(passage) == stats['characters'] <= 48000 and len(passage.encode()) == stats['utf8_bytes'], 'exact passage lengths')
        check(all(len(d['formatted']) <= 4000 and hashlib.sha256(d['formatted'].encode()).hexdigest() == d['formatted_sha256'] for d in docs), 'perdocument byte hash/cap')
        check(stats['requested_population_completeness_verified'] is False, 'no completeness claim')
        contexts[method, kind] = (ctx, passage)
    stage = method + '_answer'
    ctx, passage = contexts[method, 'final']
    rebuilt = [{'role': 'system', 'content': retrieval.ANSWER_INSTRUCTION}, {'role': 'user', 'content': base_user + passage}]
    check(requests[stage]['payload']['messages'] == rebuilt, 'retrieval exact prompt ' + method)
    result = read(T / 'retrieval' / method / IDENT / 'result.json')
    check(result == generated['results'][IDENT][method] == executed['results'][IDENT][method], 'unmodified retrieval outcome')
    check(result['context_stats'] == ctx['stats'] and result['source_index_sha256'] == cfg['FTS_input']['sha256'], 'retrieval same frozen source metadata')
    check(result['public_task_sha256'] == retrieval.digest(task) and result['question_sha256'] == question_sha and result['protocol_sha256'] == retrieval.digest(retrieval.PROTOCOL), 'public task/protocol identity')
    if method == 'C':
        try:
            retrieval.parse_answer(outcomes[stage]['content'])
        except json.JSONDecodeError as exc:
            check(exc.pos == 0, 'prose prefix violates strictJSON from first byte')
        else:
            raise AssertionError('C must remain strict parse failure')
        check(result['status'] == 'answer_parse_error' and 'abstain' not in result and result['records'] == [], 'C parse error not parsed abstention')
    else:
        parsed = retrieval.parse_answer(outcomes[stage]['content'])
        check(parsed == {'records': [], 'abstain': True, 'complete': False}, 'D actual parsed abstention')
        check(result['status'] == 'abstained' and result['abstain'] is True and result['records'] == [], 'D outcome abstention')
    prompt_rows.append({'stage': stage, 'reconstruction': 'exact instruction + public contract + saved bounded source passages',
                        'context_stats': ctx['stats'], 'source_completeness_claimed': False})
check(contexts['C', 'initial'][0] == contexts['C', 'final'][0] == contexts['D', 'initial'][0], 'common initial retrieval')
helper_rebuilt = [{'role': 'system', 'content': retrieval.QUERY_INSTRUCTION}, {'role': 'user', 'content': base_user + contexts['D', 'initial'][1]}]
check(requests['D_followup']['payload']['messages'] == helper_rebuilt, 'D exact followup prompt')
helper_obj = json.loads(outcomes['D_followup']['content'])
check(set(helper_obj) == {'query'} and type(helper_obj['query']) is str and helper_obj['query'].strip(), 'one short followup query')
check(helper_obj['query'] == read(T / 'retrieval/D' / IDENT / 'retrieval_round_2.json')['query'], 'exact followup query used')
prompt_rows.append({'stage': 'D_followup', 'reconstruction': 'exact instruction + public contract + common initial passages', 'query_sha256': hashlib.sha256(helper_obj['query'].encode()).hexdigest()})

definition = read(cfg['cases'][IDENT]['definition']['path'])
gold_path = Path(cfg['cases'][IDENT]['actual_reference_rows']['path'])
check(sha(gold_path) == cfg['cases'][IDENT]['actual_reference_rows']['sha256'], 'actual native reference pin')
gold_native = [json.loads(line) for line in gold_path.read_text().splitlines() if line]
gold = [{field['name']: row[field['name']] if field['name'] in row else row[field['source_column_or_expression']] for field in definition['required_fields']} for row in gold_native]
check(len(gold) == 5 and definition['collection']['kind'] == 'set' and definition['cardinality_policy'] == {'mode': 'exact', 'value': 5}, 'exact5 four-field set')
check([f['name'] for f in definition['required_fields']] == ['specNumber', 'crCnt', 'secCnt', 'density'], 'mandatory full-record projection')
recomputed = []
for method in METHODS:
    outcome = executed['results'][IDENT][method]
    valid = outcome['status'] in {'OK', 'ok', 'partial'} and not outcome.get('abstain', False)
    pred = outcome['records'] if valid else []
    value = scorer.score(definition, gold, pred, diagnostic=True, order_groups=None)
    row = next(r for r in summary['results'] if r['method'] == method)
    check(row['score'] == value and row['valid_answer'] is valid and row['failure_remains_in_denominator'] is True, 'independent score/status exact agreement ' + method)
    check(value['f1'] == 0 and value['exact'] is False and value['matched_records'] == 0, 'all4 factual first scores0')
    check(summary['macro'][method] == {'N': 1, 'f1': 0.0, 'exact': 0}, 'N1 retained method denominator')
    recomputed.append({'method': method, 'status': outcome['status'], 'valid_answer': valid, 'parsed_abstention': outcome.get('abstain') if method != 'C' else None, 'score': value})
check(summary['N_per_method'] == 1 and summary['expected_total_method_items'] == 4 and summary['original560_admission_delta'] == summary['human_expert_validation_n'] == 0, 'separate cohort only')
check(len(executed['results'][IDENT]['Text2Cypher']['records']) == 5 and executed['results'][IDENT]['Text2SQL']['records'] == [], 'A5 B0')

native = executed['results'][IDENT]['Text2Cypher']['execution']
check(native['rollback_completed'] is True and native['inventory_before'] == {'nodes': 156296, 'relationships': 939168}, 'saved full inventory and rollback')
events = read(T / 'native_stage_events' / (IDENT + '.json'))
check(events['result_status'] == 'OK' and [e['stage'] for e in events['events']] == ['owned_stopped_before_start', 'owned_running_after_start', 'owned_stopped_after_execution'], 'stored stop/start/stop lifecycle')
check(min(events['events'][0]['available'].values()) >= 26 * 1024**3, 'saved prestart26GiB')
sql_result = executed['results'][IDENT]['Text2SQL']['execution']
check(sql_result['immutable_read_only'] is True and sql_result['error_class'] is None and sql_result['file_identity_after']['bytes'] == 515121152, 'saved SQL immutable readonly success')
physical = executed['results'][IDENT]['Text2SQL']['physical_SQL_interface_before_model_call']
check(physical == freeze['physical_SQL_interface_gate'] and physical['table_n'] == 78 and physical['relationship_table_n'] == 47, 'physical DDL pre-generation gate unchanged')
schema = read(E / 'sql_schema.json')
physical_names = {t['name'] for t in schema['tables']}
query = executed['results'][IDENT]['Text2SQL']['generated_query']
rel_names = set(re.findall(r'\brel_[A-Za-z0-9_]+\b', query))
check(rel_names <= physical_names, 'B physical relationship identifiers match supplied table names')
guard = read(T / 'actual_continuous_generated_execution_guard.json')
check(guard['status'] == 'PASS' and guard['returncode'] == 0 and guard['failure'] is None and guard['native_child_started'] is True, 'actual continuous guard PASS')
check(guard['root_configuration_sha256'] == sha(cfg_path) and guard['wrapper_sha256'] == sha(E / 'run_guarded_generated_execution.py'), 'actual guarded config/wrapper exact')
check(guard['owned_cleanup']['owned_container_stopped'] is True and guard['owned_cleanup']['UUID_source_image_loopback_memory_swap_CPU_and_state_verified'] is True, 'guard stopped with identity verification')
check(guard['new_API_calls'] == guard['quality_rerolls'] == 0, 'execution no new paid calls/rerolls')
samples = guard['memory_samples']
check(samples and all(min(s['Linux_available_bytes'], s['Windows_available_bytes']) >= 16 * 1024**3 for s in samples), 'all saved memory samples16GiB')
check(min(guard['initial_memory'].values()) >= 26 * 1024**3, 'guard prestart26GiB')
check(not opened_forbidden_events, 'no prohibited operations attempted')

trial_pins = [pin(p) for p in sorted(T.rglob('*')) if p.is_file()]
result = {
    'status': 'PASS_INDEPENDENT_SAVED_FIRST5_PROMPT_PARSE_SCORE_COST_AND_GUARD_AUDIT',
    'utc': datetime.now(timezone.utc).isoformat(),
    'audit_role': 'independent nonblind AI review; human experts 0',
    'question_id': IDENT,
    'cohort': cfg['cohort'],
    'original560_admission_delta': 0,
    'scientific_results_changed': False,
    'source_proof_is_distinct_from_saved_evaluation_audit': True,
    'own_script': pin(__file__),
    'root_configuration': pin(cfg_path),
    'precall_freeze': pin(freeze_path),
    'frozen_small_files_directly_rehashed': small_pins,
    'frozen_large_sources_not_reopened': large_not_reopened,
    'first_stage_requests_and_responses': call_rows,
    'calls_received': 5,
    'all_attempt0_HTTP200_stop': True,
    'quality_rerolls': 0,
    'transport_retries_observed': 0,
    'unknown_cost_calls': 0,
    'new_cost_usd_exact_decimal': format(cost, '.6f'),
    'provider_usage_tokens_total': tokens,
    'raw_Decimal_cost_overrides_float_display_roundoff': True,
    'live_credit_balance_observed': False,
    'exact_prompt_reconstructions': prompt_rows,
    'common_selection_policy_unchanged': task['selection_policy'],
    'private_evidence_prompt_policy': 'All five payloads reconstructed from frozen public question/typed output/selection plus value-free method schema or saved bounded source passages. No reference query, gold, native rows, reviews or gate receipts supplied by adapters.',
    'gold_native_reference': pin(gold_path),
    'all_four_recomputed_scores_exactly_match_saved_summary': recomputed,
    'N_per_method': 1,
    'method_items': 4,
    'C_failure': {'status': 'answer_parse_error', 'reason': 'Raw response begins with explanatory prose then JSON. Entire raw string fails strict json.loads at byte/character0. No fence stripping or trailing-object rescue.', 'parsed_abstention': None, 'summary_abstention_false_is_default_for_missing_flag': True, 'complete_supported_answer_claimed': False},
    'D_failure': {'status': 'abstained', 'actual_raw_JSON': {'records': [], 'abstain': True, 'complete': False}},
    'structured_execution': {'A_complete_rows': 5, 'B_complete_rows': 0, 'A_all_four_field_matches': 0, 'B_empty_is_not_abstention': True, 'B_physical_SQL_namespace_defect_observed': False, 'B_relationship_tables_referenced': sorted(rel_names)},
    'guard_saved_proof': {'receipt': pin(T / 'actual_continuous_generated_execution_guard.json'), 'stage_events': pin(T / 'native_stage_events' / (IDENT + '.json')), 'saved_inventory_before': native['inventory_before'], 'rollback_completed': True, 'owned_stopped': True, 'memory_samples': len(samples), 'minimum_Linux_sample_bytes': min(s['Linux_available_bytes'] for s in samples), 'minimum_Windows_sample_bytes': min(s['Windows_available_bytes'] for s in samples), 'nominal_Linux_seconds': 2, 'nominal_Windows_seconds': 10},
    'limits': [
        'No model/API/native/container/SQLite/FTS calls or scientific-output mutations. Frozen source TTL/SQL/FTS large files not reopened or independently rehashed in this saved-output audit.',
        'Source fidelity and semantic source authority were prior gates; this audit independently checks their pinned evidence bytes, not fresh whole-source replay.',
        'All five prompts expose the same declared finite selection policy and underlying source, but interface, bounded retrieval, token exposure and cost differ.',
        'Retrieval C/D contexts are nonempty but truncated (12 of160/319 candidate documents); corpus existence does not prove requested population completeness.',
        'Native stored execution is OK/full rows/rollback and lifecycle events plus watchdog stop. Read-only EXPLAIN and full result-summary checks are enforced by frozen runner code, but raw EXPLAIN plan/query_type is not serialized in this cohort; do not claim separately saved raw plan proof.',
        'Watchdog sampling is nominal, not a hard real-time guarantee; synchronous Windows checks can stretch intervals.',
        'B identifiers use physical rel_TYPE names correctly; its zero result does not reproduce the historical R3 SQL namespace-input defect. This audit does not rerun alternative SQL or assign tested causal error attribution.',
        'C prose declares inability and includes a trailing abstention object, but only D is a successfully parsed abstention. Both remain N1 failures.',
        'No pooling with other cohorts, no original483 admission or original560 increment, human-expert validation0, no current-world/causal hotspot inference.'
    ],
    'all_trial_small_files_current_pins': trial_pins,
    'operations': {'new_API_calls': 0, 'native_calls': 0, 'SQL_FTS_queries': 0, 'subprocess_calls_from_audit': 0, 'central_public_mutations': 0, 'prohibited_audit_events_attempted': opened_forbidden_events}
}
out = HERE / 'receipt.json'
with out.open('x') as f:
    json.dump(result, f, ensure_ascii=False, indent=2, allow_nan=False)
    f.write('\n')
print(json.dumps({'status': result['status'], 'receipt': str(out), 'sha256': sha(out), 'cost_usd': result['new_cost_usd_exact_decimal'], 'N_per_method': 1, 'all4F1': 0, 'rehashed_frozen_small_files': len(small_pins)}, ensure_ascii=False))
