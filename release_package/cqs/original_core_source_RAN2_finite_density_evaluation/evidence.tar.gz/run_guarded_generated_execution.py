#!/usr/bin/env python3
"""Execute frozen first predictions with continuous host reserve and owned cleanup."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import signal
import subprocess
import time

HERE = Path(__file__).resolve().parent
GIB = 1024 ** 3


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def command(*args):
    return subprocess.check_output(args, text=True, timeout=30).strip()


def linux_available():
    return int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                    if line.startswith('MemAvailable:'))) * 1024


def windows_available():
    value = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command',
                            '(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'],
                           capture_output=True, text=True, timeout=20)
    assert value.returncode == 0 and re.fullmatch(r'\d+', value.stdout.strip())
    return int(value.stdout.strip()) * 1024


def inspect_owned(cfg, expected_running):
    target = cfg['native_container']
    assert target['name'].startswith('kdd-db-source-ran2-')
    assert target['source_sha256'] == cfg['TTL_input']['sha256']
    guard = module(HERE / 'runtime/container_stage_guard.py', 'density_watchdog_stage_guard')
    raw = json.loads(command('docker', 'inspect', target['name']))[0]
    guard.validate(raw, name=target['name'], port=target['port'], run_uuid=target['run_uuid'],
                   source_sha256=target['source_sha256'], image_id=target['image_id'],
                   expected_running=expected_running)
    return raw


def cleanup_owned(cfg):
    # Validate complete identity even when the child already stopped its container.
    target = cfg['native_container']
    raw = json.loads(command('docker', 'inspect', target['name']))[0]
    running = raw['State']['Running']
    assert type(running) is bool
    inspect_owned(cfg, running)
    if running:
        command('docker', 'stop', '--time', '20', target['name'])
    inspect_owned(cfg, False)
    return {'owned_container_stopped': True, 'fallback_owned_stop_performed': running,
            'UUID_source_image_loopback_memory_swap_CPU_and_state_verified': True}


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def run(config_path):
    assert config_path.resolve().parent == HERE
    runner_path = HERE / 'run_separate_density_experiment.py'
    runner = module(runner_path, 'density_guarded_execution_runner')
    cfg = runner.config(config_path)
    runner.verify_freeze(cfg, config_path)
    trial = Path(cfg['trial_directory'])
    receipt = trial / 'actual_continuous_generated_execution_guard.json'
    assert not receipt.exists() and (trial / 'generated_before_execution.json').exists()
    assert not (trial / 'executed_predictions.json').exists()
    child = None
    started = False
    failure = None
    samples = []
    initial = None
    cleanup = None
    code = None
    began = time.monotonic()
    cmd = ['/usr/bin/python3', '-B', str(runner_path), 'execute', '--root-config', str(config_path)]
    try:
        initial = {'Linux_available_bytes': linux_available(), 'Windows_available_bytes': windows_available()}
        assert min(initial.values()) >= 26 * GIB, initial
        inspect_owned(cfg, False)
        assert not any(name.startswith('kdd-db-') for name in command('docker', 'ps', '--format', '{{.Names}}').splitlines())
        with (trial / 'guarded_execution.stdout').open('x') as stdout, (trial / 'guarded_execution.stderr').open('x') as stderr:
            child = subprocess.Popen(cmd, stdout=stdout, stderr=stderr)
            started = True
            last_windows = time.monotonic()
            windows = initial['Windows_available_bytes']
            print(json.dumps({'status': 'GENERATED_EXECUTION_STARTED', 'pid': child.pid, 'initial_memory': initial}), flush=True)
            while child.poll() is None:
                linux = linux_available()
                if time.monotonic() - last_windows >= 10:
                    windows = windows_available()
                    last_windows = time.monotonic()
                samples.append({'elapsed_seconds': round(time.monotonic() - began, 3),
                                'Linux_available_bytes': linux, 'Windows_available_bytes': windows})
                assert min(linux, windows) >= 16 * GIB, 'Continuous dual-host reserve violated'
                time.sleep(2)
            code = child.wait()
            assert code == 0, 'Generated execution failed; preserve first output without reroll'
        runner.verify_freeze(cfg, config_path)
    except BaseException as exc:
        failure = {'error_type': type(exc).__name__, 'message': str(exc)[:2000]}
    finally:
        if child is not None and child.poll() is None:
            child.terminate()
            try:
                code = child.wait(timeout=45)
            except subprocess.TimeoutExpired:
                child.kill()
                code = child.wait()
        if started:
            try:
                cleanup = cleanup_owned(cfg)
            except BaseException as exc:
                failure = failure or {'error_type': type(exc).__name__, 'message': str(exc)[:2000]}
                cleanup = {'status': 'OWNERSHIP_OR_CLEANUP_FAILURE_PRESERVED', 'error_type': type(exc).__name__}
        result = {'status': 'PASS' if failure is None else 'FAIL_PRESERVED', 'command': cmd,
                  'root_configuration_sha256': sha(config_path), 'wrapper_sha256': sha(Path(__file__)),
                  'native_child_started': started, 'returncode': code, 'failure': failure,
                  'prestart_minimum_available_bytes': 26 * GIB, 'watchdog_minimum_available_bytes': 16 * GIB,
                  'Linux_check_seconds': 2, 'Windows_check_seconds': 10, 'initial_memory': initial,
                  'memory_samples': samples, 'owned_cleanup': cleanup,
                  'elapsed_seconds': time.monotonic() - began, 'new_API_calls': 0, 'quality_rerolls': 0}
        save(receipt, result)
        print(json.dumps({'status': result['status'], 'receipt_sha256': sha(receipt), 'cleanup': cleanup}), flush=True)
    assert failure is None, failure


def interrupted(signum, frame):
    raise SystemExit('Execution watchdog interrupted by signal ' + str(signum))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root-config', type=Path, required=True)
    args = parser.parse_args()
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    run(args.root_config)
