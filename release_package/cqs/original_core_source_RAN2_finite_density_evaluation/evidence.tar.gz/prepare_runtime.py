#!/usr/bin/env python3
"""Prepare a new, separate finite-dependency density cohort without paid calls."""
from pathlib import Path
import ast, copy, difflib, hashlib, importlib.util, json, shutil, sqlite3, sys
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p/'CLAUDE.md').exists())
O = HERE.parent
PREVIOUS = O/'root_RAN1_CQ024_capture2_prepared_evaluation_v1'
M = O/'priority71_fast_closure/RAN2_density_finite_dependency_full_clone_preparation_v1'
N = O/'priority71_fast_closure/RAN2_density_finite_identity_dependency_variant_v2'
SECONDARY = O/'root_RAN2_narrow_identity_dependency_review/independent_exact_seven_unit_finite_dependency_source_policy_review.json'
COHORT = 'RAN2_density_finite_dependency_current64_original_query_fourfield_N1'
DEFINITION_SHA = '01243921dd6086b8df22d01ffa9b5cd1fd4ad96bc6663d90253641a165d5df7c'
REPAIR = 'bc739310bc8d3b131717dd95a7c873156822bc670009c83366e0aed88a69bc5c'

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda:f.read(1048576),b''): h.update(x)
    return h.hexdigest()

def read(p): return json.loads(Path(p).read_text())
def pin(p): return {'path':str(p.resolve()),'sha256':sha(p)}
def save(n,v):
    with (HERE/n).open('x') as f: f.write(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def module(p,n):
    s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def main():
    assert sys.executable=='/usr/bin/python3'
    source=N/'prospective_finite_dependency_source_variant_definition.json'
    assert sha(source)==DEFINITION_SHA
    assert sha(SECONDARY)=='4f6a02882ce47a788b65e314764b261cb2fecfbbabf21169b91dcf375b35540e'
    d=read(source); material=read(M/'actual_materialization_manifest.json')
    assert d['repair_sha256']==REPAIR and d['original_query_unchanged'] is True
    assert material['status']=='PASS_ISOLATED_WHOLE_BASE_PLUS_FINITE_SOURCE_DEPENDENCY_FACTS'
    assert (material['whole_nodes'],material['whole_edges'])==(156296,939168)
    fields=[{'name':f['name'],'type':'number' if f['type']=='finite number' else f['type'],
             'nullable':not f['nonnull'],'source_column_or_expression':f['name']}for f in d['required_fields']]
    assert [f['name']for f in fields]==['specNumber','crCnt','secCnt','density']
    evaluation=copy.deepcopy(d)
    evaluation.update(required_fields=fields, collection={'kind':'set'},
        cardinality_policy={'mode':'exact','value':5}, validation_status='separate_source_diagnostic',
        prospective_source_definition=pin(source), original560_admission_delta=0,
        repair_identity_note='repair_sha256 identifies the original question/scorer proposal; the separate data policy and evaluation protocol are independently pinned and are not covered by that older identifier.')
    save('evaluation_contract.json',evaluation)
    (HERE/'runtime').mkdir();(HERE/'scoring').mkdir();changes=[]
    for p in sorted((PREVIOUS/'runtime').glob('*.py')):
        s=p.read_text()
        if p.name=='retrieval_adapter.py':
            old="CORPUS_DIR = Path("+repr(str((O/'priority71_fast_closure/CQ024_original_frozen_plus_generic_capture2_v1/actual_corpus').resolve()))+")"
            assert s.count(old)==1;s=s.replace(old,'CORPUS_DIR = Path('+repr(str((M/'actual_corpus').resolve()))+')')
            assert s.count("working_groups or ('RAN1',)")==1;s=s.replace("working_groups or ('RAN1',)","working_groups or ('RAN2',)")
        dest=HERE/'runtime'/p.name;dest.write_text(s);ast.parse(s)
        changes.append({'name':p.name,'old_sha256':sha(p),'prepared_sha256':sha(dest),'byte_equal':p.read_bytes()==dest.read_bytes()})
        if s!=p.read_text():(HERE/(p.name+'.adaptation.diff')).write_text(''.join(difflib.unified_diff(p.read_text().splitlines(True),s.splitlines(True))))
    for p in sorted((PREVIOUS/'scoring').iterdir()):
        if p.is_file():shutil.copyfile(p,HERE/'scoring'/p.name)
    shutil.copyfile(PREVIOUS/'run_pre_call_physical_schema_and_stage_controls.py',HERE/'run_pre_call_physical_schema_and_stage_controls.py')
    assets={'TTL_input':pin(Path(material['source_TTL']['path'])),'SQL_input':pin(Path(material['source_SQL']['path'])),
            'FTS_input':pin(M/'actual_corpus/ran2.sqlite3')}
    for k,mk in [('TTL_input','source_TTL'),('SQL_input','source_SQL')]:assert assets[k]['sha256']==material[mk]['sha256']
    physical=module(HERE/'runtime/physical_schema.py','density_actual_physical_DDL')
    schema,receipt=physical.build(assets['SQL_input']['path'],assets['SQL_input']['sha256'])
    save('sql_schema.json',schema);save('actual_complete_physical_SQL_schema_build.json',receipt)
    c=sqlite3.connect(Path(assets['SQL_input']['path']).as_uri()+'?mode=ro&immutable=1',uri=True);c.execute('PRAGMA query_only=ON')
    labels=[r[0]for r in c.execute('SELECT DISTINCT label FROM node_label ORDER BY label')]
    props={l:{'iri':['STRING']}for l in labels};types={'array':'LIST','boolean':'BOOLEAN','integer':'INTEGER','number':'FLOAT','string':'STRING','object':'MAP','null':'NULL'}
    for l,k,t in c.execute('SELECT DISTINCT l.label,p.key,p.native_type FROM node_label l JOIN node_property p USING(node_id) ORDER BY l.label,p.key,p.native_type'):props[l].setdefault(k,[]).append(types[t])
    rels=[list(r)for r in c.execute('SELECT DISTINCT a.label,e.rel_type,b.label FROM edge e JOIN node_label a ON a.node_id=e.src_id JOIN node_label b ON b.node_id=e.dst_id ORDER BY a.label,e.rel_type,b.label')];c.close()
    save('graph_schema.json',{'labels':labels,'properties_by_label':props,'directed_relationships':rels,
        'auxiliary_identity_codec':'iri is the loader-assigned stable identity. Type unions have no example values or nonnull guarantees.'})
    task={k:copy.deepcopy(evaluation[k])for k in ['id','question_en','collection','cardinality_policy']}
    task.update(wg='RAN2',repair_sha256=REPAIR,required_fields=[{k:f[k]for k in ['name','type','nullable']}for f in fields])
    task['selection_policy']={'kind':'authored_retained_release_CR_path_density',
        'numerator':'Count CR node-to-release-blind Spec hub MODIFIES paths, without DISTINCT. MODIFIES is the recorded requested specification, not approval.',
        'denominator':'Count Section BELONGS_TO_SPEC paths for the highest retained integer Spec release reached through IN_RELEASE_OF for that hub. Preserve inner matches and non-DISTINCT counts.',
        'metric':'round(1.0*crCnt/secCnt,2)', 'selection':'density DESC LIMIT 5',
        'ties':'No extra tie breaker. The frozen reference must demonstrate a strict fifth/sixth gap.',
        'serialization':'Return an unordered set of five complete four-field records. No current-world or causal hotspot claim.'}
    save('public_tasks.json',[task])
    old=(PREVIOUS/'run_separate_CQ024_experiment.py').read_text();s=old
    for a,b in [('RAN1_CQ024_original_fullgraph_generic_capture2_calendar_IDset_N1',COHORT),
                ('CQ024_new','RAN2_density_new'),('CQ024_freeze','RAN2_density_freeze'),
                ("target['name'].startswith('kdd-db-source-ran1-')","target['name'].startswith('kdd-db-source-ran2-')"),
                ('(nodes, edges) == (165418, 848230)','(nodes, edges) == (156296, 939168)'),
                ('Recorded Agreement-to-CR reference and requested Spec target, with a source-derived additive reference repair and calendar-aware selection; not full technical effects, causal approval or normative incorporation.',
                 'Separate current64 metadata and finite latest-Section dependency additions on a fixed original CR/Spec population; the original four-field density query is unchanged. All old facts are retained, including unresolved full-source hierarchy/reference/caption differences. No original560 admission, complete source graph fidelity or causal/current-world hotspot claim.')]:
        assert a in s,a;s=s.replace(a,b)
    start=s.index('        # The exact unchanged prospective definition has no embedded self hash.')
    end=s.index('        records_path = pin(case[\'actual_reference_rows\'])',start)
    replacement="""        # Two independently pinned identities: original question repair and new data policy.
        assert d['repair_sha256'] == public['repair_sha256'] == 'bc739310bc8d3b131717dd95a7c873156822bc670009c83366e0aed88a69bc5c'
        assert hashlib.sha256(d['question_en'].encode()).hexdigest() == '17e2bd7058d434f51fcef2f6ae700f31b79ff4a792968de93d82e51f3c02f9de'
        source_definition = pin(d['prospective_source_definition'])
        assert sha(source_definition) == '01243921dd6086b8df22d01ffa9b5cd1fd4ad96bc6663d90253641a165d5df7c'
        original = read(source_definition)
        assert d['original_query'] == original['original_query'] and d['original_query_unchanged'] is True
        assert [f['name'] for f in d['required_fields']] == ['specNumber','crCnt','secCnt','density']
        assert [f['type'] for f in d['required_fields']] == ['string','integer','integer','number']
        assert all(f['nullable'] is False for f in d['required_fields'])
        assert d['collection'] == {'kind':'set'} and d['cardinality_policy'] == {'mode':'exact','value':5}
        files.append(source_definition)
"""
    s=s[:start]+replacement+s[end:]
    # Raw retrieval answer numerals are scored as Decimal, before binary float
    # rounding. Saved adapter records remain diagnostic; the original answer
    # string and source response are authoritative for numeric scoring here.
    original_prediction="            predicted = outcome.get('records', []) if valid else []\n"
    exact_prediction="""            predicted = outcome.get('records', []) if valid else []
            if valid and method in ('C', 'D'):
                from decimal import Decimal
                answer_calls = [call for call in outcome['calls'] if call['stage'] == 'answer']
                assert len(answer_calls) == 1
                response_path = Path(answer_calls[0]['response_path']).resolve(strict=True)
                assert response_path.is_relative_to((trial / 'calls').resolve())
                saved_response = read(response_path)['response']
                content = saved_response['choices'][0]['message']['content']
                def reject_nonfinite(value):
                    raise ValueError('Nonfinite answer number: ' + value)
                parsed_exact = json.loads(content, parse_float=Decimal, parse_constant=reject_nonfinite)
                assert parsed_exact['abstain'] is False
                assert isinstance(parsed_exact['records'], list)
                predicted = parsed_exact['records']
"""
    assert s.count(original_prediction)==1;s=s.replace(original_prediction,exact_prediction)
    (HERE/'run_separate_density_experiment.py').write_text(s);ast.parse(s)
    (HERE/'runner.adaptation.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True))))
    empty={'path':None,'sha256':None,'assertions':[]}
    config={'cohort':COHORT,'original560_admission_delta':0,'ready_for_root_review':False,'budget_usd':None,
        'execution_interpreter':'/usr/bin/python3','trial_directory':str(HERE/'FIRST_TRIAL_NOT_YET_CREATED'),
        'native_lock_path':str(O.parents[1]/'native_capture.lock'),**assets,
        'cases':{d['id']:{'definition':pin(HERE/'evaluation_contract.json'),'actual_reference_rows':{'path':None,'sha256':None,'provenance':'actual_owned_native_capture'}}},
        'gate_receipts':{k:copy.deepcopy(empty)for k in ['whole_native_reference_capture','whole_independent_SQL_agreement','independent_second_seven_unit_semantics','generic_and_boundary_scoring_controls','whole_source_and_FTS_equivalence']},
        'native_manifest':{'path':None,'sha256':None},'native_container':{'name':None,'port':None,'bolt':None,'run_uuid':None,'source_sha256':assets['TTL_input']['sha256'],'image_id':None},
        'read_query_guard':copy.deepcopy(read(PREVIOUS/'root_configuration_final.json')['read_query_guard']),
        'additional_evidence_files':[pin(N/'manifest.json'),pin(source),pin(N/'primary_exact_seven_unit_finite_dependency_source_policy_review.json'),pin(SECONDARY),pin(M/'actual_materialization_manifest.json'),pin(M/'actual_all79_tables_and_full_graph_fact_equivalence.json')],
        'scoring_files':[pin(p)for p in sorted((HERE/'scoring').iterdir())if p.is_file()]}
    save('root_configuration_TEMPLATE_INCOMPLETE_DO_NOT_EXECUTE.json',config)
    save('prospective_preparation.json',{'status':'PREPARED_NO_CALLS_NOT_FROZEN','cohort':COHORT,'original560_admission_delta':0,**assets,
        'definition':pin(HERE/'evaluation_contract.json'),'source_definition':pin(source),'repair_sha256':REPAIR,
        'primary':pin(N/'primary_exact_seven_unit_finite_dependency_source_policy_review.json'),'secondary':pin(SECONDARY),
        'runtime_adaptations':changes,'expected_N_per_method':1,'expected_request_stages':5,
        'generator_excluded':['gold','reference queries','reference rows','selected IDs','raw source proof','reviews'],
        'scope':'Same declared enriched graph underlies native/SQL/full-fact lexical corpus; bounded interfaces provide different exposure. Fixed retained CR/Spec universe and source policy are explicit. No pooling or original admission.',
        'numeric_scoring_policy':'For valid retrieval outputs, reread the saved raw answer JSON numerals as Decimal. Adapter float records are diagnostic only for numeric scoring. Native/SQL numeric values use their captured finite JSON repr. No tolerance or value coercion.',
        'new_API_calls':0,'native_calls':0,'human_expert_validation_n':0})
    runner=module(HERE/'run_separate_density_experiment.py','RAN2_density_preflight')
    save('actual_same_interpreter_neo4j_import_preflight.json',runner.interpreter_preflight(config))
    for p in HERE.rglob('*.py'):ast.parse(p.read_text())
    print(json.dumps({'status':'PREPARED_NOT_FROZEN','physical_tables':len(schema['tables']),'new_paid_calls':0}))

if __name__=='__main__':main()
