#!/usr/bin/env python3
"""Independent Python aggregation of generic edges; no authored SQL import."""
from pathlib import Path
from collections import Counter,defaultdict
from decimal import Decimal
import hashlib,json,sqlite3
HERE=Path(__file__).resolve().parent
O=HERE.parent
M=O/'priority71_fast_closure/RAN2_density_finite_dependency_full_clone_preparation_v1'
NATIVE=O/'root_RAN2_finite_density_native_v3'
DB=M/'RAN2-finite-dependency.sqlite'
EXPECTED='79202afbe731ad04a1e77ac141bd13c2c4af35ef774e48a05b7ae1d3946c24fc'
FIELDS=['specNumber','crCnt','secCnt','density']

def sha(p):
    h=hashlib.sha256()
    with p.open('rb')as f:
        for x in iter(lambda:f.read(1048576),b''):h.update(x)
    return h.hexdigest()

def main():
    out=HERE/'actual_independent_generic_edge_density_recount.json';assert not out.exists()
    assert sha(DB)==EXPECTED
    c=sqlite3.connect(DB.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
    c.execute('PRAGMA query_only=ON');c.execute('PRAGMA cache_size=-32768');c.execute('PRAGMA mmap_size=0')
    labels=defaultdict(set)
    for node,label in c.execute('SELECT node_id,label FROM node_label'):labels[label].add(node)
    specs={i:json.loads(p)for i,p in c.execute("SELECT node_id,properties_json FROM _node_record WHERE node_id IN(SELECT node_id FROM node_label WHERE label='Spec')")}
    numerators=Counter();denominators=Counter();release_paths=defaultdict(list)
    for src,rel,dst in c.execute("SELECT src_id,rel_type,dst_id FROM edge WHERE rel_type IN('MODIFIES','IN_RELEASE_OF','BELONGS_TO_SPEC')"):
        if rel=='MODIFIES' and src in labels['CR'] and dst in specs and specs[dst].get('specRelease') is None:
            numerators[dst]+=1
        elif rel=='BELONGS_TO_SPEC' and src in labels['Section'] and dst in specs:
            denominators[dst]+=1
        elif rel=='IN_RELEASE_OF' and src in specs and dst in specs:
            release_paths[dst].append(src)
    choices={};allrows=[];excluded=[]
    for hub,n in numerators.items():
        candidates=release_paths[hub]
        assert candidates
        highest=max(int(specs[i]['specRelease'].replace('Rel-',''))for i in candidates)
        latest=[i for i in candidates if int(specs[i]['specRelease'].replace('Rel-',''))==highest]
        assert len(latest)==1,'Ambiguous retained highest release'
        edition=latest[0];choices[specs[hub]['specNumber']]={'release':specs[edition]['specRelease'],'release_path_count':len(candidates),'latest_section_paths':denominators[edition]}
        denominator=denominators[edition]
        if not denominator:excluded.append(specs[hub]['specNumber']);continue
        # Pure integer arithmetic: positive round-half-up, not SQL or float.
        cents=(200*n+denominator)//(2*denominator)
        density=Decimal(cents)/100
        allrows.append({'specNumber':specs[hub]['specNumber'],'crCnt':n,'secCnt':denominator,'density':density})
    c.close();assert len(specs)==187 and len(labels['CR'])==34622
    assert len(choices)==15 and len(allrows)==14 and excluded==['38.822']
    allrows.sort(key=lambda r:r['density'],reverse=True)
    assert allrows[4]['density']>allrows[5]['density']
    captures=json.loads((NATIVE/'actual_native_four_column_source_capture.json').read_text(),parse_float=Decimal)
    def token(r):return tuple(r[k]for k in FIELDS)
    def native_token(row):return tuple(row)
    for name,actual in [('selected',allrows[:5]),('whole_matching_pool',allrows)]:
        saved=captures[name];assert saved['complete'] and not saved['truncated']
        assert set(map(token,actual))==set(map(native_token,saved['rows']))
        assert len(actual)==len(saved['rows'])
    assert sha(DB)==EXPECTED
    # Receipt stores the captured decimal value as a decimal string, explicitly
    # diagnostic; actual benchmark records stay JSON numbers in native capture.
    rows=[dict(r,density_decimal=str(r['density']))for r in allrows]
    for r in rows:del r['density']
    result={'status':'PASS_INDEPENDENT_GENERIC_EDGE_PYTHON_AGGREGATION_AND_NATIVE_ALL4_FIELDS',
        'SQL_source_sha256':EXPECTED,'implementation':'Generic edge/node labels plus Python counters and exact integer positive rounding; no author SQL, recipe or query execution imported.',
        'whole_pool_rows':14,'selected_rows':5,'all_four_fields_equal_native':True,'strict_fifth_sixth_gap':True,
        'unique_release_choices':choices,'excluded_inner_match_zero_section_hubs':excluded,
        'diagnostic_records_decimal_as_string_only':rows,'code_sha256':sha(Path(__file__)),
        'native_capture_sha256':sha(NATIVE/'actual_native_four_column_source_capture.json'),
        'original560_increment':0,'API_calls':0,'new_native_queries':0}
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'receipt_sha256':sha(out),'fifth':str(allrows[4]['density']),'sixth':str(allrows[5]['density'])}))

if __name__=='__main__':main()
