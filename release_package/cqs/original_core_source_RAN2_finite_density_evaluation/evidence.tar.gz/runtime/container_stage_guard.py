"""Validate actual owned container identity separately from its lifecycle stage.

Unlike the historical running-only guard, this never calls a running-only
validator on a stopped container and never edits an inspection response.
"""


def validate(info, *, name, port, run_uuid, source_sha256, image_id, expected_running):
    if type(expected_running) is not bool:
        raise ValueError('An explicit stopped/running stage is required')
    labels = info['Config'].get('Labels') or {}
    required = {'spectra.frozen.owner': 'contract_repair_v1',
                'spectra.frozen.run_uuid': run_uuid,
                'spectra.frozen.source_sha256': source_sha256}
    if info['Name'] != '/' + name or any(labels.get(key) != value for key, value in required.items()):
        raise ValueError('Owned container identity mismatch')
    if info['Image'] != image_id:
        raise ValueError('Exact image identity mismatch')
    host = info['HostConfig']
    if host.get('Memory') != 2 * 1024**3 or host.get('MemorySwap') != 2 * 1024**3 or host.get('NanoCpus') != 10**9:
        raise ValueError('Pinned 2GiB / 1CPU container budget mismatch')
    if host.get('PortBindings') != {'7687/tcp': [{'HostIp': '127.0.0.1', 'HostPort': str(port)}]}:
        raise ValueError('Only the exact pinned loopback Bolt port is permitted')
    if type(info['State'].get('Running')) is not bool or info['State']['Running'] is not expected_running:
        raise ValueError('Wrong container lifecycle stage')
    if any(info['State'].get(key, False) for key in ('Paused', 'Restarting', 'Dead')):
        raise ValueError('Container is not in an ordinary stable lifecycle stage')
    return {'status': 'PASS', 'validated_stage': 'running' if expected_running else 'stopped',
            'ownership_resource_image_and_loopback_bindings_checked': True,
            'inspection_response_mutated': False}
