"""Prospective, value-free SQLite interface; never changes historical inputs."""
from pathlib import Path
import hashlib
import json
import sqlite3

FORMAT = 'physical_sqlite_ddl'


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def quote(name):
    return '"' + name.replace('"', '""') + '"'


def catalog(db):
    """Only catalog and table metadata are read; no data rows or statistics."""
    tables = []
    for name, ddl in db.execute(
            "SELECT name,sql FROM sqlite_master WHERE type='table' ORDER BY name"):
        if name.startswith('_') or name.startswith('sqlite_'):
            continue
        if not isinstance(ddl, str) or not ddl.upper().startswith('CREATE TABLE '):
            raise ValueError('Unsupported table DDL; a new interface review is needed')
        columns = [list(row) for row in db.execute('PRAGMA table_info(' + quote(name) + ')')]
        foreign_keys = [list(row) for row in db.execute('PRAGMA foreign_key_list(' + quote(name) + ')')]
        tables.append({'name': name, 'ddl': ddl, 'columns': columns,
                       'foreign_keys': foreign_keys})
    return tables


def metadata(path):
    db = sqlite3.connect(Path(path).resolve(strict=True).as_uri() + '?mode=ro&immutable=1', uri=True)
    try:
        db.execute('PRAGMA query_only=ON')
        return catalog(db)
    finally:
        db.close()


def require_shape(schema):
    if not isinstance(schema, dict) or set(schema) != {'format', 'tables', 'encoding'}:
        raise ValueError('Physical SQL schema envelope required; legacy dictionaries rejected')
    if schema['format'] != FORMAT or schema['encoding'] != encoding():
        raise ValueError('Unreviewed SQL interface format or representation codec')
    if not isinstance(schema['tables'], list) or not schema['tables']:
        raise ValueError('Nonempty physical table catalog required')
    names = []
    for entry in schema['tables']:
        if not isinstance(entry, dict) or set(entry) != {'name', 'ddl', 'columns', 'foreign_keys'}:
            raise ValueError('Invalid physical table entry')
        if not isinstance(entry['name'], str) or entry['name'].startswith('_'):
            raise ValueError('Invalid or private table exposed')
        if not isinstance(entry['ddl'], str) or not entry['ddl'].upper().startswith('CREATE TABLE '):
            raise ValueError('Exactly one ordinary table declaration required per entry')
        names.append(entry['name'])
    if names != sorted(set(names)):
        raise ValueError('Sorted, unique physical tables required')


def encoding():
    return {'join_identity': 'node_id',
            'relationship_columns': ['edge_id', 'src_id', 'dst_id'],
            'relationship_table_rule': 'Use the exact table names in the supplied DDL.',
            'absent_property': 'SQL NULL',
            'boolean': 'integer 0 or 1; decode only for a declared boolean answer field',
            'array_or_object': 'canonical JSON text',
            'typed_property_values': 'node_property.native_type and node_property.value_json',
            'private_tables': 'Names beginning with an underscore are inaccessible.'}


def validate(schema, db_path, expected_db_sha256):
    """Fail before a model call if any visible table, name, column or type differs."""
    require_shape(schema)
    if digest(db_path) != expected_db_sha256:
        raise ValueError('Structured input snapshot digest mismatch')
    actual = metadata(db_path)
    if canonical(schema['tables']) != canonical(actual):
        raise ValueError('Prompt schema is not the complete physical database catalog')
    rebuilt = sqlite3.connect(':memory:')
    try:
        for table in schema['tables']:
            # execute(), not executescript(): additional statements are rejected.
            rebuilt.execute(table['ddl'])
        if canonical(catalog(rebuilt)) != canonical(actual):
            raise ValueError('Supplied DDL does not recreate the physical table catalog')
        if any(rebuilt.execute('SELECT count(*) FROM ' + quote(t['name'])).fetchone()[0]
               for t in schema['tables']):
            raise ValueError('Value-free schema reconstruction unexpectedly contains rows')
    finally:
        rebuilt.close()
    if digest(db_path) != expected_db_sha256:
        raise ValueError('Structured input snapshot changed during schema validation')
    return {'status': 'PASS_FULL_PHYSICAL_SQL_INTERFACE_BEFORE_GENERATION',
            'schema_sha256': hashlib.sha256(canonical(schema).encode()).hexdigest(),
            'database_sha256': expected_db_sha256, 'table_n': len(actual),
            'relationship_table_n': sum(t['name'].startswith('rel_') for t in actual),
            'data_rows_read_from_source': 0, 'model_calls': 0,
            'historical_inputs_changed': False}


def build(db_path, expected_db_sha256):
    schema = {'format': FORMAT, 'tables': metadata(db_path), 'encoding': encoding()}
    receipt = validate(schema, db_path, expected_db_sha256)
    return schema, receipt


def call_after_validation(schema, db_path, expected_db_sha256, call):
    """The callable cannot run until the complete input interface passes."""
    receipt = validate(schema, db_path, expected_db_sha256)
    return call(schema), receipt
