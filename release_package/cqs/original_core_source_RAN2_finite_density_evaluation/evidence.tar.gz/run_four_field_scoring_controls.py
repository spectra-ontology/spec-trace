#!/usr/bin/env python3
"""Actual finite negative checks for the prospectively fixed density records."""
from pathlib import Path
from decimal import Decimal
import copy,hashlib,importlib.util,json,sys
HERE=Path(__file__).resolve().parent
O=HERE.parent
NATIVE=O/'root_RAN2_finite_density_native_v3'
sys.path.insert(0,str(HERE/'scoring'))

def module(p,n):
    s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    out=HERE/'actual_four_field_scoring_controls.json';assert not out.exists()
    contract=json.loads((HERE/'evaluation_contract.json').read_text())
    gold_path=NATIVE/'requested_records.jsonl'
    gold=[json.loads(line)for line in gold_path.read_text().splitlines()if line]
    assert len(gold)==5 and all(set(r)=={'specNumber','crCnt','secCnt','density'}for r in gold)
    s=module(HERE/'scoring/original_scorer.py','density_four_field_controls')
    cases=[]
    def check(name,pred,exact,zero=False):
        result=s.score(contract,gold,pred,diagnostic=True)
        assert result['exact'] is exact,(name,result)
        if zero:assert result['f1']==0,(name,result)
        cases.append({'case':name,'expected_exact':exact,'zero_f1_required':zero,'actual':result})
    check('actual_native_reference',gold,True)
    check('set_reordering_preserved',list(reversed(gold)),True)
    equivalent=copy.deepcopy(gold)
    for r in equivalent:r['density']=Decimal(str(r['density']))
    check('exact_decimal_number_equivalence',equivalent,True)
    for field in ['specNumber','crCnt','secCnt','density']:
        x=copy.deepcopy(gold)
        for r in x:del r[field]
        check('missing_required_'+field,x,False,True)
        x=copy.deepcopy(gold)
        for r in x:r[field]=None
        check('nonnull_'+field,x,False,True)
    for field in ['crCnt','secCnt']:
        for value_kind in ['wrong_count','string','boolean','floating_integral']:
            x=copy.deepcopy(gold)
            for r in x:r[field]={'wrong_count':r[field]+1,'string':str(r[field]),'boolean':True,'floating_integral':float(r[field])}[value_kind]
            check(field+'_'+value_kind,x,False,True)
    x=copy.deepcopy(gold)
    for r in x:r['specNumber']='WRONG-'+r['specNumber']
    check('wrong_spec_identity',x,False,True)
    for name,func in [
        ('density_wrong',lambda v:Decimal(str(v))+Decimal('0.01')),
        ('density_high_precision_perturbation',lambda v:Decimal(str(v))+Decimal('0.000000000000000000000001')),
        ('density_string',str),('density_boolean',lambda v:True),
        ('density_nonfinite',lambda v:float('inf'))]:
        x=copy.deepcopy(gold)
        for r in x:r['density']=func(r['density'])
        check(name,x,False,True)
    x=copy.deepcopy(gold)
    for r in x:r['crCnt'],r['secCnt']=r['secCnt'],r['crCnt']
    check('numerator_denominator_roles_swapped',x,False,True)
    check('empty_answer',[],False,True)
    check('missing_selected_record',gold[:-1],False)
    check('duplicate_replaces_record',gold[:-1]+[gold[0]],False)
    extra=copy.deepcopy(gold[0]);extra['specNumber']='EXTRA'
    check('extra_record',gold+[extra],False)
    # A binary-float parse can erase a contradictory raw decimal literal.
    # The new cohort scorer explicitly rereads raw retrieval answer numerals.
    token=str(gold[0]['density'])+'000000000000000000000001'
    assert float(token)==gold[0]['density']
    exact=json.loads('{"density":'+token+'}',parse_float=Decimal)['density']
    assert exact!=Decimal(str(gold[0]['density']))
    runner=(HERE/'run_separate_density_experiment.py').read_text()
    assert 'parsed_exact = json.loads(content, parse_float=Decimal' in runner
    result={'status':'PASS','gold_sha256':sha(gold_path),'contract_sha256':sha(HERE/'evaluation_contract.json'),
        'runner_sha256':sha(HERE/'run_separate_density_experiment.py'),'controls':cases,
        'raw_decimal_precision_counterexample_preserved':True,'binary_float_would_erase_perturbation':True,
        'raw_retrieval_Decimal_scoring_required':True,'source_cutoff_selection_checked_by_native_gate_not_scorer':True,
        'original560_increment':0,'new_API_calls':0}
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':'PASS','controls':len(cases),'receipt_sha256':sha(out)}))

if __name__=='__main__':main()
