#!/usr/bin/env python3
"""ROOT-EXECUTION-ONLY draft: isolated whole original frozen RAN2 plus finite source-dependency additions and the unchanged density query."""
from collections import Counter
import argparse
import math
import signal
from datetime import datetime, timezone
from pathlib import Path
import fcntl
import hashlib
import importlib.util
import json
import os
import resource
import socket
import sqlite3
import subprocess
import time
import uuid

HERE = Path(__file__).resolve().parent
O = HERE.parent.parent
BASE = O.parent.parent
ROOT = next(p for p in HERE.parents if (p / 'CLAUDE.md').exists())
PREP = HERE
FULL = PREP
SQLITE = PREP
PROOF = HERE.parent/'RAN2_density_finite_identity_dependency_variant_v2'
WORK = O / 'root_RAN2_finite_density_native_v3'
LOADER = Path('/home/sihyeon/workspace/spectra-public/spec-trace/release_package/pipeline/load_released_kg.py')
HELPER = BASE.parent / 'pending_recheck/RAN2_pack110_enriched/load_enriched_ttl_neo4j.py'
NAME, PORT = 'kdd-db-source-ran2-density-audit-v3', 57917
GIB = 1024 ** 3


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def pin(path):
    return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}


def save(path, value):
    temp = path.with_suffix(path.suffix + '.pending')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temp.replace(path)


def command(*args):
    return subprocess.check_output(list(args), text=True).strip()


def inspect():
    return json.loads(command('docker', 'inspect', NAME))[0]


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def verify_manifest(folder, digest):
    assert sha(folder / 'manifest.json') == digest
    m = json.loads((folder / 'manifest.json').read_text())
    for name, expected in m['artifacts'].items():
        assert sha(folder / name) == expected, name


def main():
    def terminate_with_finally(signum,frame):
        raise SystemExit(128+signum)
    signal.signal(signal.SIGTERM,terminate_with_finally)
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--materialization-manifest-sha256',required=True)
    args=parser.parse_args()
    assert not WORK.exists(), 'Preserve all prior attempts; never adopt an existing run'
    WORK.mkdir()
    assert sha(PREP/'actual_materialization_manifest.json')==args.materialization_manifest_sha256
    material=json.loads((PREP/'actual_materialization_manifest.json').read_text())
    assert material['status']=='PASS_ISOLATED_WHOLE_BASE_PLUS_FINITE_SOURCE_DEPENDENCY_FACTS'
    assert (material['whole_nodes'],material['whole_edges'])==(156296,939168)
    for name in ['source_TTL','source_SQL','base_TTL','base_SQL','source_packet_manifest','definition','primary_review','secondary_review','full_fact_proof','SQL_reference','requested_records']:
        expected_pin=material[name];assert sha(Path(expected_pin['path']))==expected_pin['sha256'],name
    assert sha(PROOF/'manifest.json')=='1b70409a85d3ce60ea9f0e813756ffde1a49694d7483515c38d0495ef6974aeb'
    assert sha(LOADER)=='9499ac120ea4fcf1c2707f6e3151e399530d9b4f43f5aec9d2d93040792d6e25'
    assert sha(HELPER)=='81713cdbdbd38ffe2a957b7d8f466f63483224c76f091f082abaf98c64c21c9b'
    definition_path=PROOF/'prospective_finite_dependency_source_variant_definition.json'
    assert sha(definition_path)=='01243921dd6086b8df22d01ffa9b5cd1fd4ad96bc6663d90253641a165d5df7c'
    definition=json.loads(definition_path.read_text())
    assert definition['repair_sha256']=='bc739310bc8d3b131717dd95a7c873156822bc670009c83366e0aed88a69bc5c'
    from neo4j import GraphDatabase
    import neo4j
    save(WORK/'actual_real_interpreter_dependency_preflight.json',{'status':'PASS','interpreter':os.sys.executable,'isolated':os.sys.flags.isolated,'neo4j_version':neo4j.__version__,'neo4j_module_sha256':sha(Path(neo4j.__file__)),'driver_import_exercised':True})
    snapshot=PREP/'RAN2-finite-dependency-body.ttl';db=PREP/'RAN2-finite-dependency.sqlite'
    assert sha(snapshot)==material['source_TTL']['sha256']and sha(db)==material['source_SQL']['sha256']
    readonly=sqlite3.connect(db.resolve().as_uri()+'?mode=ro&immutable=1',uri=True);readonly.execute('PRAGMA query_only=ON')
    independent=json.loads((PREP/'actual_new_full_SQL_density_reference.json').read_text())
    q=definition['original_query'];sql=independent['SQL_selected']
    assert q==(PREP/'reference_query.cypher').read_text()and q.endswith(' LIMIT 5')and sql.endswith(' LIMIT 5')
    queries={'selected':q,'whole_matching_pool':q.removesuffix(' LIMIT 5')}
    expected={name:[list(row)for row in readonly.execute(sql if name=='selected'else independent['SQL_full_pool'])]for name in queries};readonly.close()
    fields=['specNumber','crCnt','secCnt','density']
    assert len(expected['selected'])==len({r[0]for r in expected['selected']})==5
    assert len(expected['whole_matching_pool'])==14
    assert expected['selected']==[[r[k]for k in fields]for r in independent['selected_records']]
    assert expected['whole_matching_pool']==[[r[k]for k in fields]for r in independent['complete_pool_rows']]
    assert expected['whole_matching_pool'][4][3]>expected['whole_matching_pool'][5][3]
    def comparable(rows):
        for r in rows:
            assert len(r)==4 and isinstance(r[0],str)and r[0]
            assert type(r[1])is int and type(r[2])is int and r[1]>0 and r[2]>0
            assert type(r[3])in(int,float)and math.isfinite(r[3])
        return sorted(json.dumps(r,ensure_ascii=False,separators=(',',':'))for r in rows)
    for values in expected.values():comparable(values)
    save(WORK/'actual_immutable_SQL_four_column_reference.json',{'queries':queries,'SQL_selected':sql,'SQL_full':independent['SQL_full_pool'],'rows':expected,'definition':pin(definition_path),'meaning':'Separate fixed-population current64 metadata plus finite Section-identity/BELONGS additions. Every old fact remains; no full current-source graph fidelity or original560 admission.','collection':'set of four-field records; density-DESC membership remains required; tied row serialization is not required.'})
    with (BASE / 'native_capture.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        windows = int(command('powershell.exe', '-NoProfile', '-Command', '(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory')) * 1024
        available = next(int(x.split()[1]) * 1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
        guard = {'linux_available_bytes': available, 'windows_available_bytes': windows,
                 'minimum_available_bytes': 26 * GIB, 'parser_budget_bytes': 8 * GIB,
                 'container_budget_bytes': 2 * GIB, 'reserve_bytes': 16 * GIB}
        save(WORK / 'actual_host_resource_guard.json', guard)
        assert min(windows, available) >= 26 * GIB, 'Preserved 26GiB host resource guard'
        active = command('docker', 'ps', '--format', '{{.Names}}').splitlines()
        assert not any(n.startswith('kdd-db-') for n in active), 'Another audit database is active'
        assert NAME not in command('docker', 'ps', '-a', '--format', '{{.Names}}').splitlines()
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', PORT))
        image_id = json.loads(command('docker', 'image', 'inspect', 'neo4j:5.26.0'))[0]['Id']
        run_id = str(uuid.uuid4())
        bolt = f'bolt://127.0.0.1:{PORT}'
        manifest = {'status': 'starting', 'created_utc': datetime.now(timezone.utc).isoformat(),
                    'run_uuid': run_id, 'snapshot_kind': 'Separate whole frozen RAN2 plus107 metadata MODIFIES and8 Section nodes/24 Section edges; every old fact retained; current64 source policy explicit; original560 admissions0',
                    'source': pin(snapshot), 'db': pin(db), 'loader': pin(LOADER), 'helper': pin(HELPER),
                    'wrapper': pin(Path(__file__)), 'image_id': image_id, 'host_guard': guard,
                    'target': {'container': NAME, 'bolt': bolt, 'cpu': 1, 'memory_bytes': 2 * GIB, 'loopback_only': True},
                    'question_admissions': 0, 'new_model_calls': 0, 'expert_validation_n': 0}
        target_manifest = WORK / 'actual_native_manifest.json'
        save(target_manifest, manifest)
        helper = module(HELPER, 'root_RAN2_preserved_container_guard')
        started, created = time.monotonic(), False
        def guard_owned():
            info=inspect()
            helper.guard_container(info,NAME,PORT,run_id,manifest['source']['sha256'])
            assert info['HostConfig'].get('MemorySwap')==2*GIB,'MemorySwap differs from fixed2GiB'
            assert info.get('Image')==image_id,'Owned image differs from pinned image digest'
            assert all(info['State'].get(k)is False for k in ['Paused','Restarting','Dead']),'Unsafe paused/restarting/dead container state'
        try:
            data = WORK / 'data'
            data.mkdir()
            command('docker', 'run', '--detach', '--pull=never', '--name', NAME, '--cpus=1', '--memory=2g', '--memory-swap=2g',
                    '--publish', f'127.0.0.1:{PORT}:7687', '--label', 'spectra.frozen.owner=contract_repair_v1',
                    '--label', f'spectra.frozen.run_uuid={run_id}', '--label', f"spectra.frozen.source_sha256={manifest['source']['sha256']}",
                    '--env', 'NEO4J_AUTH=none', '--env', 'NEO4J_server_memory_heap_initial__size=512m',
                    '--env', 'NEO4J_server_memory_heap_max__size=512m', '--env', 'NEO4J_server_memory_pagecache_size=256m',
                    '--volume', f'{data.resolve()}:/data', image_id)
            created = True
            guard_owned()
            helper.wait_empty_database(bolt)
            resource.setrlimit(resource.RLIMIT_AS, (8 * GIB, 8 * GIB))
            os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
            loader = module(LOADER, 'root_RAN2_exact_public_loader')
            nodes, relations, stats = loader.parse_ttl(snapshot)
            assert len(nodes) == 156296 and len(relations) == 939168 and not stats['prop_conflicts']
            readonly=sqlite3.connect(db.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
            try:
                node_keys={}
                for node_id,source_iri,labels_json,properties_json in readonly.execute('SELECT node_id,source_iri,labels_json,properties_json FROM _node_record'):
                    match=loader.INST_RE.match(source_iri);assert match,source_iri
                    key=(match.group('cls'),match.group('nid'));node_keys[node_id]=key
                    assert nodes[key]['labels']==set(json.loads(labels_json)),source_iri
                    assert json.dumps(nodes[key]['props'],sort_keys=True,ensure_ascii=False,separators=(',',':'))==json.dumps(json.loads(properties_json),sort_keys=True,ensure_ascii=False,separators=(',',':')),source_iri
                assert len(node_keys)==len(nodes)==156296
                sql_edges={(node_keys[a],r,node_keys[b]) for a,r,b in readonly.execute('SELECT src_id,rel_type,dst_id FROM edge')}
                assert sql_edges==relations
                save(WORK/'actual_root_full_public_parse_vs_SQL_all_facts.json',{'status':'PASS','nodes':len(nodes),'directed_edges':len(relations),'full_native_property_dictionaries_and_labels_equal':True,'raw_source_IRI_used':True,'new_Section_nodes':8,'new_directed_edges':131,'new_MODIFIES':107,'new_Section_edges':24,'old_node_properties_unchanged':True,'code':pin(Path(__file__))})
                del node_keys,sql_edges
            finally:readonly.close()
            inventory = {'nodes': len(nodes), 'relationships': len(relations), 'labels': dict(stats['class_subjects']),
                         'relations': {loader.decode_rel_type(k): v for k, v in stats['rel_pred_camel'].items()}}
            manifest['parse_inventory'] = inventory
            manifest['status'] = 'loading'
            save(target_manifest, manifest)
            guard_owned()
            helper.wait_empty_database(bolt)
            counts = loader.load_neo4j(bolt, 'neo4j', '', nodes, relations, 2000)
            assert counts['total_nodes'] == inventory['nodes']
            assert counts['label_counts'] == inventory['labels'] and counts['rel_counts'] == inventory['relations']
            manifest['measured_counts'] = counts
            from neo4j import GraphDatabase
            driver = GraphDatabase.driver(bolt, auth=None, connection_timeout=10)
            captures = {}
            try:
                for name, q in queries.items():
                    guard_owned()
                    with driver.session(default_access_mode='READ') as session:
                        tx = session.begin_transaction(timeout=90)
                        try:
                            plan_summary = tx.run('EXPLAIN ' + q).consume()
                            assert plan_summary.query_type == 'r' and not plan_summary.counters.contains_updates
                            result = tx.run(q)
                            columns = list(result.keys())
                            rows = [list(record.values()) for record in result]
                            summary = result.consume()
                            assert summary.query_type == 'r' and not summary.counters.contains_updates
                            assert columns == ['specNumber','crCnt','secCnt','density']
                            assert comparable(rows)==comparable(expected[name]),'Native/SQL all-four-field set mismatch'
                            assert all(rows[i][3]>=rows[i+1][3]for i in range(len(rows)-1)),'Literal density-DESC execution order was violated'
                            if name=='selected':assert len(rows)==len({r[0]for r in rows})==5
                            captures[name] = {'literal_query': q, 'columns': columns, 'rows': rows,
                                              'row_n': len(rows), 'EXPLAIN_query_type': plan_summary.query_type,
                                              'actual_query_type': summary.query_type, 'contains_updates': False,
                                              'complete': True, 'truncated': False, 'transaction_rolled_back': True}
                        finally:
                            tx.rollback()
            finally:
                driver.close()
            save(WORK / 'actual_native_four_column_source_capture.json', captures)
            assert sha(snapshot) == manifest['source']['sha256'] and sha(db) == manifest['db']['sha256']
            assert sha(ROOT/'release_package/kg/per_wg/RAN2-body.ttl')=='f0997bbfb5fd5844837514cd29cfe943b8cb2d0240f0ea5579c5e69b4e547d6c'
            manifest['status'] = 'ACTUAL_NATIVE_FULL156296_939168_AND_EXACT_DENSITY_REFERENCE_EQUAL_SQL'
            manifest['selected_rows']=len(captures['selected']['rows'])
            manifest['whole_matching_pool_rows']=len(captures['whole_matching_pool']['rows'])
            manifest['capture']=pin(WORK/'actual_native_four_column_source_capture.json')
            with(WORK/'requested_records.jsonl').open('x')as stream:
                stream.write(''.join(json.dumps(dict(zip(fields,r)),ensure_ascii=False)+'\n'for r in captures['selected']['rows']))
            print(json.dumps({'status':manifest['status'],'selected':manifest['selected_rows'],'whole':manifest['whole_matching_pool_rows']}),flush=True)

        except BaseException as exc:
            manifest['status'] = 'FAILED_PRESERVED_FOR_DIAGNOSIS'
            manifest['error_type'], manifest['error'] = type(exc).__name__, str(exc)[:1000]
            raise
        finally:
            signal.signal(signal.SIGTERM,signal.SIG_IGN)
            # Docker may have created the owned container just before an
            # interrupt aborted the docker-run client return. Check by exact
            # name as well, then require the UUID/source/port ownership guard.
            if created or NAME in command('docker','ps','-a','--format','{{.Names}}').splitlines():
                guard_owned()
                command('docker', 'stop', '--time', '20', NAME)
                assert not inspect()['State']['Running']
                manifest['owned_container_stopped'] = True
            manifest['elapsed_seconds'] = time.monotonic() - started
            manifest['max_rss_kib'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            manifest['updated_utc'] = datetime.now(timezone.utc).isoformat()
            save(target_manifest, manifest)


if __name__ == '__main__':
    main()
