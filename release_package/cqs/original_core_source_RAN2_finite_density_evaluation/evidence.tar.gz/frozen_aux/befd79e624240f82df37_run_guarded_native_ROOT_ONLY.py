#!/usr/bin/env python3
"""ROOT-only native child with continuous dual-host reserve and owned cleanup.

Use /usr/bin/python3 -B -I for this stdlib wrapper. The actual native child uses
/usr/bin/python3 -B, preserving the Neo4j driver's real import environment.
"""
from pathlib import Path
import hashlib,importlib.util,json,re,subprocess,sys,time
HERE=Path(__file__).resolve().parent
CHILD=HERE/'root_native_RAN2_finite_density_prepared_v3.py'
GIB=1024**3
CHILD_SHA='6d55e39ce628af8fd34b346c99cae9be46a28d7d0b6abca25da5291d50f8dae6'
EXPECTED_MATERIALIZATION_SHA='ed32d12626321b994e0b4c06e11ff115a86fb603a7fcd0f9ceb9b51b260d5149'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(p,name):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def linux_available():return int(next(l.split()[1]for l in Path('/proc/meminfo').read_text().splitlines()if l.startswith('MemAvailable:')))*1024
def windows_available():
 r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command','(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'],capture_output=True,text=True,timeout=20)
 assert r.returncode==0 and re.fullmatch(r'\d+',r.stdout.strip()),r.stderr
 return int(r.stdout.strip())*1024
def command(*args):return subprocess.check_output(args,text=True,timeout=30).strip()
def static_owned_identity_guard(raw,name,port,run_uuid,source_sha,image_id):
 labels=raw['Config'].get('Labels')or{}
 assert raw['Name']=='/'+name
 assert all(labels.get(k)==v for k,v in {'spectra.frozen.owner':'contract_repair_v1','spectra.frozen.run_uuid':run_uuid,'spectra.frozen.source_sha256':source_sha}.items())
 assert raw['HostConfig'].get('Memory')==2*GIB and raw['HostConfig'].get('NanoCpus')==10**9
 assert raw['HostConfig'].get('MemorySwap')==2*GIB
 assert raw.get('Image')==image_id
 assert all(raw['State'].get(k)is False for k in ['Paused','Restarting','Dead'])
 assert raw['HostConfig'].get('PortBindings')=={'7687/tcp':[{'HostIp':'127.0.0.1','HostPort':str(port)}]}
def owned_cleanup(native):
 names=command('docker','ps','-a','--format','{{.Names}}').splitlines()
 if native.NAME not in names:return {'container_created':False,'fallback_stop_performed':False}
 p=native.WORK/'actual_native_manifest.json';m=json.loads(p.read_text())
 assert m['target']['container']==native.NAME and m['target']['bolt']==f'bolt://127.0.0.1:{native.PORT}'
 assert sha(native.HELPER)=='81713cdbdbd38ffe2a957b7d8f466f63483224c76f091f082abaf98c64c21c9b'
 helper=module(native.HELPER,'guard_watchdog_fallback_helper');raw=json.loads(command('docker','inspect',native.NAME))[0]
 static_owned_identity_guard(raw,native.NAME,native.PORT,m['run_uuid'],m['source']['sha256'],m['image_id'])
 if raw['State']['Running']:helper.guard_container(raw,native.NAME,native.PORT,m['run_uuid'],m['source']['sha256'])
 fallback=bool(raw['State']['Running'])
 if fallback:command('docker','stop','--time','20',native.NAME)
 assert not json.loads(command('docker','inspect',native.NAME))[0]['State']['Running']
 return {'container_created':True,'fallback_stop_performed':fallback,'owned_container_stopped':True,'UUID_and_source_and_port_and_owner_verified':True}
PROGRESS={'native_child_started':False,'phase':'prestart'}
def run_native():
 assert sha(CHILD)==CHILD_SHA
 native=module(CHILD,'root_only_native_v2');receipt=HERE/'actual_guarded_native_watchdog_receipt.json';assert not receipt.exists()
 initial={'Linux_available_bytes':linux_available(),'Windows_available_bytes':windows_available()};assert min(initial.values())>=26*GIB,initial
 assert sha(HERE/'actual_materialization_manifest.json')==EXPECTED_MATERIALIZATION_SHA
 cmd=['/usr/bin/python3','-B',str(CHILD),'--materialization-manifest-sha256',EXPECTED_MATERIALIZATION_SHA]
 began=time.monotonic();samples=[];reason=None;cleanup=None
 with(HERE/'native.stdout').open('x')as so,(HERE/'native.stderr').open('x')as se:
  child=subprocess.Popen(cmd,stdout=so,stderr=se)
  PROGRESS.update(native_child_started=True,phase='native_child_running')
  print(json.dumps({'status':'ROOT_NATIVE_STARTED','pid':child.pid,'initial_memory':initial,'child_isolated_flag':False}),flush=True)
  last=time.monotonic();win=initial['Windows_available_bytes']
  try:
   while child.poll()is None:
    linux=linux_available()
    if time.monotonic()-last>=10:
     try:win=windows_available()
     except Exception as e:reason='Windows reserve remeasurement failed: '+repr(e);child.terminate();break
     last=time.monotonic()
    samples.append({'elapsed_seconds':round(time.monotonic()-began,3),'Linux_available_bytes':linux,'Windows_available_bytes':win})
    if min(linux,win)<16*GIB:reason='Dual-host16GiB reserve violated';child.terminate();break
    time.sleep(2)
   try:code=child.wait(timeout=45)
   except subprocess.TimeoutExpired:reason=(reason or'child exit timeout')+'; forced kill';child.kill();code=child.wait()
  finally:
   if child.poll()is None:
    child.terminate()
    try:child.wait(timeout=45)
    except subprocess.TimeoutExpired:child.kill();child.wait()
   # Child SIGTERM raises SystemExit so its finally normally stops the owned DB.
   # Independently verify it; on kill/race use only exact UUID/source-owned stop.
   PROGRESS['phase']='owned_cleanup'
   cleanup=owned_cleanup(native)
 result={'status':'PASS'if code==0 and reason is None else'FAIL_PRESERVED','command':cmd,'returncode':code,'guard_failure_reason':reason,'initial_memory':initial,'prestart_minimum_available_bytes':26*GIB,'watchdog_minimum_available_bytes':16*GIB,'Linux_check_seconds':2,'Windows_check_seconds':10,'memory_samples':samples,'owned_cleanup':cleanup,'native_child_SIGTERM_runs_finally':True,'child_isolated_flag':False,'child_wrapper_sha256':sha(CHILD),'materialization_manifest_sha256':EXPECTED_MATERIALIZATION_SHA,'elapsed_seconds':time.monotonic()-began,'API_calls':0,'original560_increment':0}
 with receipt.open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'status':result['status'],'receipt_sha256':sha(receipt),'owned_cleanup':cleanup}),flush=True)
 assert result['status']=='PASS'
def main():
 try:run_native()
 except BaseException as e:
  receipt=HERE/'actual_guarded_native_watchdog_receipt.json'
  if not receipt.exists():
   failure={'status':'FAIL_PRESERVED','phase':PROGRESS['phase'],'native_child_started':PROGRESS['native_child_started'],'error_type':type(e).__name__,'error':str(e)[:2000],'API_calls':0,'original560_increment':0}
   with receipt.open('x')as f:f.write(json.dumps(failure,indent=2)+'\n')
  raise
if __name__=='__main__':main()
