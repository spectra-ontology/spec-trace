#!/usr/bin/env python3
"""Use real physical DDL and mocked transport only; never contacts a provider."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


class MockCaller:
    def __init__(self):
        self.messages = []

    def call(self, ident, messages, max_tokens):
        self.messages.append(copy.deepcopy(messages))
        return {'ok': True, 'finish_reason': 'stop',
                'content': '{"query":"","abstain":true}', 'usage': {},
                'provider': 'MOCK_NO_NETWORK'}


def main():
    output = HERE / 'actual_pre_call_mock_controls'
    assert not output.exists()
    output.mkdir()
    structured = load(HERE / 'runtime/structured_adapter.py', 'precall_R1_structured')
    stage = load(HERE / 'runtime/container_stage_guard.py', 'precall_R1_stages')
    tasks = json.loads((HERE / 'public_tasks.json').read_text())
    real_schema = json.loads((HERE / 'sql_schema.json').read_text())
    source = json.loads((HERE / 'prospective_preparation.json').read_text())['SQL_input']
    schema_cases = []
    for title, mutation in [
        ('legacy_dictionary', lambda value: {'nodes': {}, 'relationships': []}),
        ('dropped_physical_table', lambda value: dict(value, tables=value['tables'][:-1])),
        ('renamed_DDL_column', lambda value: dict(value, tables=[dict(value['tables'][0], ddl=value['tables'][0]['ddl'].replace('node_id', 'invented_id'))] + value['tables'][1:])),
        ('wrong_database_digest', lambda value: value),
    ]:
        task = copy.deepcopy(tasks[0])
        task['sql_schema'] = mutation(copy.deepcopy(real_schema))
        caller = MockCaller()
        error = None
        try:
            structured.evaluate(task, 'Text2SQL', caller, output / title,
                                sql_input=dict(source, sha256='0' * 64) if title == 'wrong_database_digest' else source)
        except (ValueError, AssertionError) as exc:
            error = repr(exc)
        assert error is not None and len(caller.messages) == 0, title
        schema_cases.append({'case': title, 'rejected': True, 'mock_call_count': 0, 'error': error})
    prompt_cases = []
    for task in tasks:
        task['sql_schema'] = real_schema
        caller = MockCaller()
        result = structured.evaluate(task, 'Text2SQL', caller, output / 'actual_DDL_positive', sql_input=source)
        assert len(caller.messages) == 1
        assert result['status'] == 'ABSTAIN'
        assert result['physical_SQL_interface_before_model_call']['status'] == 'PASS_FULL_PHYSICAL_SQL_INTERFACE_BEFORE_GENERATION'
        expected_messages = structured.messages_for(task, 'Text2SQL')
        assert caller.messages[0] == expected_messages
        user = json.loads(expected_messages[1]['content'])
        assert user['schema'] == real_schema
        assert user['question'] == task['question_en'] and user['selection_policy'] == task['selection_policy']
        prompt_cases.append({'id': task['id'], 'mock_call_count': 1,
                             'actual_DDL_is_exact_final_prompt_schema': True,
                             'prompt_sha256': hashlib.sha256(structured.canonical(expected_messages).encode()).hexdigest()})
    args = {'name': 'kdd-db-source-ran1-fixture-only', 'port': 57901,
            'run_uuid': 'control-only', 'source_sha256': 'a' * 64,
            'image_id': 'sha256:' + 'b' * 64}
    fixture = {'Name': '/' + args['name'], 'Image': args['image_id'],
               'Config': {'Labels': {'spectra.frozen.owner': 'contract_repair_v1',
                                     'spectra.frozen.run_uuid': args['run_uuid'],
                                     'spectra.frozen.source_sha256': args['source_sha256']}},
               'HostConfig': {'Memory': 2 * 1024**3, 'MemorySwap': 2 * 1024**3, 'NanoCpus': 10**9,
                              'PortBindings': {'7687/tcp': [{'HostIp': '127.0.0.1', 'HostPort': str(args['port'])}]}},
               'State': {'Running': False}}
    stage_cases = []
    for running in (False, True):
        data = copy.deepcopy(fixture)
        data['State']['Running'] = running
        before = copy.deepcopy(data)
        receipt = stage.validate(data, **args, expected_running=running)
        assert data == before
        stage_cases.append({'case': 'valid_running' if running else 'valid_stopped', 'accepted': True, **receipt})
    for title in ('wrong_stage', 'owner', 'source', 'image', 'memory', 'memory_swap', 'cpu', 'external_port', 'paused'):
        data = copy.deepcopy(fixture)
        if title == 'wrong_stage': data['State']['Running'] = True
        if title == 'owner': data['Config']['Labels']['spectra.frozen.owner'] = 'foreign'
        if title == 'source': data['Config']['Labels']['spectra.frozen.source_sha256'] = 'foreign'
        if title == 'image': data['Image'] = 'foreign'
        if title == 'memory': data['HostConfig']['Memory'] = 0
        if title == 'memory_swap': data['HostConfig']['MemorySwap'] = -1
        if title == 'cpu': data['HostConfig']['NanoCpus'] = 0
        if title == 'external_port': data['HostConfig']['PortBindings']['7687/tcp'][0]['HostIp'] = '0.0.0.0'
        if title == 'paused': data['State']['Paused'] = True
        error = None
        try: stage.validate(data, **args, expected_running=False)
        except ValueError as exc: error = str(exc)
        assert error is not None, title
        stage_cases.append({'case': title, 'rejected': True, 'error': error})
    save(output / 'receipt.json', {'status': 'PASS', 'SQL_schema_negative_cases': schema_cases,
                                  'actual_physical_schema_positive_prompts': prompt_cases,
                                  'container_stage_cases': stage_cases,
                                  'mock_calls_only': True, 'paid_model_calls': 0,
                                  'docker_or_native_calls': 0, 'public_or_central_changes': 0})
    print(json.dumps({'status': 'PASS', 'schema_negative_cases': len(schema_cases),
                      'exact_final_prompt_replays': len(prompt_cases), 'stage_cases': len(stage_cases),
                      'actual_SQL_visible_tables': len(real_schema['tables']), 'paid_calls': 0}))


if __name__ == '__main__':
    main()
