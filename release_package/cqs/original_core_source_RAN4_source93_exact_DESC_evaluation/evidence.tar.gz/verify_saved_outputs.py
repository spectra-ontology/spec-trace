#!/usr/bin/env python3
"""Offline relocation of saved first5 evidence; no host-path fallback or execution.

The scientific runtime/scorer/request/response bytes remain unchanged. This wrapper
adapts path lookup and removes only unused repository discovery assignments from
retrieval's in-memory AST. It never executes SQL, FTS, Cypher, processes or API.
"""
from datetime import datetime, timezone
from decimal import Decimal
import argparse, ast, hashlib, importlib.util, json, socket, sqlite3, subprocess, sys, types, urllib.request
from pathlib import Path as RealPath
sys.dont_write_bytecode=True
HOME=RealPath(__file__).resolve().parent
IDENT='RAN4_P4_CQ4-5'
METHODS=['Text2Cypher','Text2SQL','C','D']
INVENTORY_SHA='f1d86001d8301e1c62685c28df78fa74948b182c6e7f1233eb1673617e0cb38d'
SOURCE_SHA='2832f351d2fce599b0d6d1f3727e605be59dd93cf4e8521f3dbae6d237201d8b'
FREEZE_SHA='7608a1bbc477a7a2d2ee41a2ee3346bec212d98f38e82b6d10c6711aec19f208'
AUDIT_SHA='32b9551419bbd80fc502a3ea6c859b3e5ce2fb68cc2f727f4ec2a732284b2a93'
EXCLUDED={'ran4.sqlite3','RAN4-source93-body.ttl','RAN4-source93.sqlite'}
def forbidden(*a,**k):raise AssertionError('Network/database/process operation forbidden in saved-output replay')
socket.socket=forbidden;socket.create_connection=forbidden;urllib.request.urlopen=forbidden;sqlite3.connect=forbidden;subprocess.Popen=forbidden

def file_sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return h.hexdigest()
def safe(root,rel):
 p=RealPath(rel)
 assert not p.is_absolute() and '..' not in p.parts,rel
 q=root/p
 assert q.is_file() and not q.is_symlink() and q.resolve().is_relative_to(root.resolve()),str(q)
 for parent in q.parents:
  if parent==root:break
  assert not parent.is_symlink()
 return q

def setup(source):
 global SOURCE,INVENTORY,BRIDGE,PATHMAP,OMITTED,E,T,OUT
 SOURCE=source.resolve();OUT=E=HOME;T=E/'actual_call_trial_v1'
 assert file_sha(HOME/'frozen_evidence_inventory.json')==INVENTORY_SHA
 INVENTORY=json.loads((HOME/'frozen_evidence_inventory.json').read_text())
 inv=INVENTORY['files'];assert len(inv)==len({x['path'] for x in inv})
 for x in inv:
  p=safe(HOME,x['path']);assert p.stat().st_size==x['bytes'] and file_sha(p)==x['sha256'],str(p)
 wrappers={'verify_saved_outputs.py','frozen_evidence_inventory.json','README.md','manifest.json'}
 actual={str(p.relative_to(HOME)) for p in HOME.rglob('*') if p.is_file()}
 assert actual=={x['path'] for x in inv}|wrappers,'Unlisted/missing local file'
 assert file_sha(safe(SOURCE,'manifest.json'))==SOURCE_SHA
 sm=json.loads((SOURCE/'manifest.json').read_text());assert len(sm['files'])==67
 assert {str(p.relative_to(SOURCE)) for p in SOURCE.rglob('*') if p.is_file()}=={x['path'] for x in sm['files']}|{'manifest.json'}
 for x in sm['files']:
  p=safe(SOURCE,x['path']);assert p.stat().st_size==x['bytes'] and file_sha(p)==x['sha256']
 assert file_sha(HOME/'precall_freeze.json')==FREEZE_SHA
 BRIDGE=json.loads((HOME/'frozen_path_bridge.json').read_text())
 freeze=json.loads((HOME/'precall_freeze.json').read_text())
 assert BRIDGE['original_freeze_sha256']==FREEZE_SHA and BRIDGE['source_manifest_sha256']==SOURCE_SHA
 assert BRIDGE['counts']=={'source_evidence':27,'evaluation':142,'excluded_large_source':3}
 assert len(BRIDGE['entries'])==len(freeze['pinned_files'])==172
 PATHMAP={};OMITTED=set()
 for en,original in zip(BRIDGE['entries'],freeze['pinned_files']):
  assert {k:en[k] for k in ('path','bytes','sha256')}==original
  loc=en['location']
  if loc=='excluded_large_source':
   assert RealPath(en['path']).name in EXCLUDED and en['bytes']>100000000
   OMITTED.add(en['path']);continue
  assert loc in {'source_evidence','evaluation'}
  p=safe(SOURCE if loc=='source_evidence' else HOME,en['relative_path'])
  assert p.stat().st_size==en['bytes'] and file_sha(p)==en['sha256']
  assert en['path'] not in PATHMAP or PATHMAP[en['path']]==p
  PATHMAP[en['path']]=p
 for en in BRIDGE['additional_original_paths']:
  p=safe(HOME,en['relative_path']);assert p.stat().st_size==en['bytes'] and file_sha(p)==en['sha256']
  assert en['path'] not in PATHMAP or PATHMAP[en['path']]==p
  PATHMAP[en['path']]=p
 assert file_sha(safe(HOME,'independent_audit/actual_independent_RAN4_first5_saved_output_audit.json'))==AUDIT_SHA
 manifest=json.loads((HOME/'manifest.json').read_text())
 assert manifest['precall_freeze_sha256']==FREEZE_SHA and manifest['independent_audit_sha256']==AUDIT_SHA
 assert manifest['original560_admission_delta']==manifest['human_experts']==0
 assert manifest['saved_first_attempt_calls']==5 and manifest['N_per_method']==1
 assert manifest['known_provider_reported_cost_USD']=='0.446060'
 for en in manifest['files']:
  p=safe(HOME,en['path']);assert p.stat().st_size==en['bytes'] and file_sha(p)==en['sha256']
 assert {x['path'] for x in manifest['files']}==actual-{'manifest.json'}

def Path(value):
 p=RealPath(value)
 key=str(p)
 assert key not in OMITTED,'Excluded large source must never be opened'
 if key in PATHMAP:return PATHMAP[key]
 # All direct portable paths must already belong to the validated closed inventory.
 if p.is_absolute() and (p.is_relative_to(HOME) or p.is_relative_to(SOURCE)):
  assert p.is_file() or p.is_dir(),str(p)
  return p
 raise AssertionError('No host-path fallback: '+str(p))
def sha(p):return file_sha(Path(p))
def read(p):return json.loads(Path(p).read_text())
def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(v):return hashlib.sha256(canonical(v).encode()).hexdigest()
def module(path,name):
 path=Path(path)
 if path.name=='retrieval_adapter.py':
  tree=ast.parse(path.read_text(),filename=str(path));kept=[];skipped=[]
  for node in tree.body:
   names={t.id for t in node.targets if isinstance(t,ast.Name)} if isinstance(node,ast.Assign) else set()
   if names & {'ROOT','CORPUS_DIR'}:
    assert len(names)==1;skipped.extend(names)
   else:kept.append(node)
  assert sorted(skipped)==['CORPUS_DIR','ROOT']
  tree.body=kept;ast.fix_missing_locations(tree)
  result=types.ModuleType(name);result.__file__=str(path);sys.modules[name]=result
  exec(compile(tree,str(path),'exec'),result.__dict__);return result
 spec=importlib.util.spec_from_file_location(name,path);result=importlib.util.module_from_spec(spec)
 sys.modules[name]=result;spec.loader.exec_module(result);return result

def main():
    cfg_path = E / 'root_configuration_final.json'
    freeze_path = E / 'precall_freeze.json'
    cfg, freeze = read(cfg_path), read(freeze_path)
    assert freeze['root_configuration_sha256'] == sha(cfg_path)
    assert freeze['status'] == 'FROZEN_BEFORE_ALL_NEW_PAID_CALLS'
    assert freeze['original560_admission_delta'] == cfg['original560_admission_delta'] == 0
    assert freeze['human_expert_validation_n'] == 0 and freeze['quality_retries'] == 0
    assert freeze['expected_request_stages'] == 5 and freeze['N_per_method'] == 1
    assert freeze['methods'] == METHODS and freeze['cases'] == [IDENT]
    pins = freeze['pinned_files']
    assert len(pins) == len({p['path'] for p in pins}) == 172
    checked_pins = []
    for item in pins:
        if item['path'] in OMITTED:
            continue
        path = Path(item['path'])
        assert path.is_file() and path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], str(path)
        checked_pins.append({'path': str(path), 'bytes': item['bytes'], 'sha256': item['sha256'], 'matches': True})
    pinmap = {p['path']: p for p in pins}
    for name in ['TTL_input', 'SQL_input', 'FTS_input']:
        assert cfg[name]['sha256'] == pinmap[cfg[name]['path']]['sha256']
    frozen_trial_files = {str(p): sha(p) for p in T.rglob('*') if p.is_file()}
    generated_path = T / 'generated_before_execution.json'
    generated = read(generated_path)
    executed = read(T / 'executed_predictions.json')
    summary = read(T / 'actual_results_summary.json')
    queryfreeze = read(T / 'before_execution_queries_frozen.json')
    assert queryfreeze['generated_record_sha256'] == sha(generated_path)
    assert generated['freeze_sha256'] == executed['freeze_sha256'] == sha(freeze_path)
    assert generated['database_execution_during_generation'] is False
    assert set(generated['results']) == set(executed['results']) == {IDENT}
    before, after = generated['results'][IDENT], executed['results'][IDENT]
    assert set(before) == set(after) == set(METHODS)
    public = read(E / 'public_tasks.json')
    assert len(public) == 1 and public[0]['id'] == IDENT
    task = public[0]
    case = cfg['cases'][IDENT]
    definition_path = Path(case['definition']['path'])
    reference_path = Path(case['actual_reference_rows']['path'])
    assert sha(definition_path) == case['definition']['sha256']
    assert sha(reference_path) == case['actual_reference_rows']['sha256']
    definition = read(definition_path)
    assert definition['repair_sha256'] == task['repair_sha256']
    assert digest({k: v for k, v in definition.items() if k != 'repair_sha256'}) == definition['repair_sha256']
    assert definition['question_en'] == task['question_en']
    assert definition['original_question_sha256'] == hashlib.sha256(task['question_en'].encode()).hexdigest()
    assert definition['collection'] == task['collection'] == {'kind': 'set'}
    assert task['cardinality_policy'] == {'mode': 'exact', 'value': 10}
    assert [f['name'] for f in task['required_fields']] == ['tdocNumber', 'summary']
    structured = module(E / 'runtime/structured_adapter.py', 'independent_R4_saved_structured')
    retrieval = module(E / 'runtime/retrieval_adapter.py', 'independent_R4_saved_retrieval')
    transport = module(E / 'runtime/openrouter_client.py', 'independent_R4_saved_transport_constants')
    physical = module(E / 'runtime/physical_schema.py', 'independent_R4_saved_physical_shape_only')
    schema = read(E / 'sql_schema.json')
    physical.require_shape(schema)  # No database connection or DDL execution.
    assert schema['format'] == 'physical_sqlite_ddl'
    assert freeze['physical_SQL_interface_gate']['status'] == 'PASS_FULL_PHYSICAL_SQL_INTERFACE_BEFORE_GENERATION'
    assert before['Text2SQL']['physical_SQL_interface_before_model_call'] == freeze['physical_SQL_interface_gate']
    stages = ['Text2Cypher', 'Text2SQL', 'C_answer', 'D_followup', 'D_answer']
    requests = list((T / 'calls').glob('*.request.json'))
    responses = list((T / 'calls').glob('*.attempt*.response.json'))
    outcomes = list((T / 'calls').glob('*.outcome.json'))
    assert len(requests) == len(responses) == len(outcomes) == 5
    assert all('.attempt0.response.json' in p.name for p in responses)
    calls, total, tokens = [], Decimal('0'), {'prompt': 0, 'completion': 0, 'total': 0}
    parser_replays = {}
    for stage in stages:
        prefix = T / 'calls' / (IDENT + '_' + stage)
        rp = Path(str(prefix) + '.request.json')
        sp = Path(str(prefix) + '.attempt0.response.json')
        op = Path(str(prefix) + '.outcome.json')
        request, saved, outcome = read(rp), read(sp), read(op)
        exact = json.loads(sp.read_text(), parse_float=Decimal)
        payload, response = request['payload'], saved['response']
        assert request['authorization_header_omitted'] is True
        assert request['payload_sha256'] == hashlib.sha256(json.dumps(payload, ensure_ascii=False).encode()).hexdigest()
        assert saved['request_id'] == request['request_id'] == IDENT + '_' + stage
        assert saved['attempt'] == 0 and saved['http_status'] == 200 and outcome['ok'] is True
        assert outcome['error'] is None and outcome['unknown_cost_attempts'] == 0
        assert len(outcome['attempts']) == 1 and outcome['attempts'][0]['attempt'] == 0
        assert outcome['attempts'][0]['retryable'] is False
        assert payload['model'] == response['model'] == outcome['model'] == transport.MODEL
        assert response['provider'] == outcome['provider'] == transport.PROVIDER == 'Anthropic'
        assert payload['provider'] == {'only': ['Anthropic'], 'allow_fallbacks': False, 'require_parameters': True}
        assert payload['response_format'] == {'type': 'json_object'} and payload['reasoning'] == {'enabled': False}
        assert payload['stream'] is False
        assert datetime.fromisoformat(request['created_utc']) > datetime.fromisoformat(freeze['utc'])
        assert datetime.fromisoformat(saved['received_utc']) < datetime.fromisoformat(queryfreeze['utc'])
        assert len(response['choices']) == 1
        choice = response['choices'][0]
        assert choice['finish_reason'] == outcome['finish_reason'] == 'stop'
        assert choice['native_finish_reason'] == 'end_turn'
        assert choice['message'].get('refusal') is None
        content = choice['message']['content']
        assert content == outcome['content'] and response['usage'] == outcome['usage']
        cost = exact['response']['usage']['cost']
        assert Decimal(str(outcome['known_actual_cost_usd'])) == cost and cost >= 0
        total += cost
        u = response['usage']
        assert u['prompt_tokens'] + u['completion_tokens'] == u['total_tokens']
        for name in tokens:
            tokens[name] += u[name + '_tokens']
        if stage in METHODS[:2]:
            visible = dict(task)
            key = 'graph_schema' if stage == 'Text2Cypher' else 'sql_schema'
            visible[key] = read(E / (key + '.json'))
            expected_messages = structured.messages_for(visible, stage)
            assert payload['max_tokens'] == structured.MAX_GENERATION_TOKENS
            obj = json.loads(content)
            assert isinstance(obj, dict) and set(obj) == {'query', 'abstain'}
            assert type(obj['query']) is str and type(obj['abstain']) is bool and not obj['abstain']
            assert obj['query'].strip() and len(obj['query'].encode()) <= 65536
            g, e = before[stage], after[stage]
            prediction = read(T / 'predictions' / stage / (IDENT + '.json'))
            assert prediction == g
            assert g['status'] == 'QUERY_READY' and g['abstain'] is False
            assert obj['query'].encode() == g['generated_query'].encode() == e['generated_query'].encode()
            qsha = hashlib.sha256(obj['query'].encode()).hexdigest()
            assert qsha == g['query_sha256'] == e['query_sha256'] == queryfreeze['queries'][IDENT][stage]
            assert digest(payload['messages']) == g['prompt_sha256']
            assert g['call'] == outcome
            parser_replays[stage] = {'status': 'QUERY_READY', 'query_sha256': qsha, 'query_unchanged_after_execution': True}
        else:
            method = stage[0]
            name = 'initial_context.json' if stage == 'D_followup' else 'final_context.json'
            directory = T / 'retrieval' / method / IDENT
            context = read(directory / name)
            for doc in context['documents']:
                assert hashlib.sha256(doc['formatted'].encode()).hexdigest() == doc['formatted_sha256']
            passages = '\n\n'.join(doc['formatted'] for doc in context['documents'])
            assert len(passages) == context['stats']['characters']
            instruction = retrieval.QUERY_INSTRUCTION if stage == 'D_followup' else retrieval.ANSWER_INSTRUCTION
            expected_messages = [{'role': 'system', 'content': instruction}, {'role': 'user', 'content': canonical({'question': task['question_en'], 'contract': retrieval.public_contract(task)}) + '\nSOURCE PASSAGES:\n' + passages}]
            if stage == 'D_followup':
                assert payload['max_tokens'] == retrieval.PROTOCOL['followup_max_tokens']
                obj = json.loads(content)
                assert set(obj) == {'query'} and type(obj['query']) is str and obj['query'].strip()
                round2 = read(directory / 'retrieval_round_2.json')
                assert round2['query'] == obj['query']
                assert round2['query_sha256'] == hashlib.sha256(obj['query'].encode()).hexdigest()
                parser_replays[stage] = {'status': 'VALID_FOLLOWUP_QUERY', 'saved_round2_query_exact': True}
            else:
                assert payload['max_tokens'] == retrieval.PROTOCOL['answer_max_tokens']
                result = read(directory / 'result.json')
                assert result == before[method] == after[method]
                try:
                    parsed = retrieval.parse_answer(content)
                except (ValueError, TypeError, KeyError) as exc:
                    assert result['status'] == 'answer_parse_error' and result['records'] == []
                    assert str(exc) == result['error']
                    parser_replays[stage] = {'status': 'answer_parse_error', 'error_class': type(exc).__name__, 'error': str(exc), 'accepted_records': 0}
                else:
                    status = 'abstained' if parsed['abstain'] else ('ok' if parsed['complete'] else 'partial')
                    assert result['status'] == status and result['records'] == parsed['records']
                    assert result['abstain'] == parsed['abstain'] and result['self_reported_complete'] == parsed['complete']
                    parser_replays[stage] = {'status': status, 'accepted_records': len(parsed['records']), 'model_abstain': parsed['abstain'], 'model_complete': parsed['complete']}
            assert read(directory / 'retrieval_round_1.json')['query'] == task['question_en']
        assert expected_messages == payload['messages'], stage
        calls.append({'stage': stage, 'request_sha256': sha(rp), 'response_sha256': sha(sp), 'outcome_sha256': sha(op),
                      'actual_HTTP_status': 200, 'attempt': 0, 'prompt_reconstruction_exact': True,
                      'prompt_sha256': digest(payload['messages']), 'raw_content_sha256': hashlib.sha256(content.encode()).hexdigest(),
                      'model': response['model'], 'provider': response['provider'], 'cost_decimal_USD': str(cost), 'usage': u,
                      'finish_reason': choice['finish_reason'], 'native_finish_reason': choice['native_finish_reason']})
    usage = read(T / 'usage.json')
    assert usage == generated['usage'] == summary['usage']
    assert Decimal(str(usage['known_actual_cost_usd'])) == total == Decimal('0.446060')
    assert usage['received_response_calls'] == 5 and usage['unknown_cost_attempts'] == 0
    assert not usage['halted_unknown_cost'] and usage['all_actual_costs_known'] is True
    assert usage['model'] == transport.MODEL and usage['provider'] == transport.PROVIDER
    reference = [json.loads(line) for line in reference_path.read_text().splitlines() if line]
    gold = [{field['name']: row[field['name']] for field in definition['required_fields']} for row in reference]
    assert len(gold) == len({canonical(row) for row in gold}) == 10
    sys.path.insert(0, str(E / 'scoring'))
    module(E / 'scoring/scorer.py', 'scorer')
    scorer = module(E / 'scoring/original_scorer.py', 'independent_R4_saved_score')
    bymethod = {row['method']: row for row in summary['results']}
    assert set(bymethod) == set(METHODS)
    score_replays = []
    for method in METHODS:
        outcome = after[method]
        valid = outcome['status'] in {'OK', 'ok', 'partial'} and not outcome.get('abstain', False)
        pred = outcome.get('records', []) if valid else []
        score = scorer.score(definition, gold, pred, diagnostic=True)
        saved = bymethod[method]
        assert score == saved['score'] and saved['valid_answer'] == valid
        assert saved['status'] == outcome['status'] and saved['abstention'] == bool(outcome.get('abstain'))
        assert saved['failure_remains_in_denominator'] is True
        if method in METHODS[:2]:
            execution = outcome['execution']
            assert outcome['status'] == 'OK' and execution['status'] == 'OK' and execution['complete'] is True
            assert execution['rows'] == pred and len(pred) == 10 and score['exact'] is True
            assert execution['columns'] == ['tdocNumber', 'summary']
        else:
            assert score['f1'] == 0 and not score['exact']
        assert summary['macro'][method] == {'N': 1, 'f1': score['f1'], 'exact': int(score['exact'])}
        score_replays.append({'method': method, 'status': outcome['status'], 'valid_answer': valid, 'actual_saved_score_reproduced': score,
                              'query_or_FTS_reexecuted': False})
    assert summary['N_per_method'] == 1 and summary['expected_total_method_items'] == 4
    assert summary['original560_admission_delta'] == summary['human_expert_validation_n'] == 0
    positive = scorer.score(definition, gold, list(reversed(gold)), diagnostic=True)
    assert positive['exact'] is True
    missing = scorer.score(definition, gold, gold[:-1], diagnostic=True)
    assert missing['exact'] is False and missing['cardinality_valid'] is False
    wrong = [dict(row) for row in gold]
    wrong[0]['summary'] = None
    wrongtype = scorer.score(definition, gold, wrong, diagnostic=True)
    assert wrongtype['exact'] is False and wrongtype['type_errors']
    changed_trials = [path for path, old in frozen_trial_files.items() if sha(path) != old]
    assert not changed_trials
    for item in pins:
        if item['path'] not in OMITTED:
            assert sha(item['path']) == item['sha256']
    receipt = {'status': 'PASS_INDEPENDENT_FIRST5_SAVED_PROMPT_PARSER_SCORE_REPLAY',
               'utc': datetime.now(timezone.utc).isoformat(), 'question_id': IDENT, 'cohort': cfg['cohort'],
               'configuration_sha256': sha(cfg_path), 'precall_freeze_sha256': sha(freeze_path),
               'included_pinned_files_rehashed_twice': len(checked_pins), 'historical_frozen_pin_count': len(pins), 'omitted_large_source_pins_not_opened': len(OMITTED), 'pinned_bytes': sum(x['bytes'] for x in pins),
               'all_saved_trial_files_unchanged': len(frozen_trial_files), 'checked_pre_call_pins': checked_pins,
               'calls': calls, 'Decimal_actual_cost_USD': str(total), 'tokens': tokens,
               'first_attempts': 5, 'HTTP200': 5, 'quality_retries': 0, 'transport_retries': 0,
               'actual_prompt_reconstructions': 5, 'parser_replays': parser_replays, 'score_replays': score_replays,
               'reference_rows_sha256': sha(reference_path), 'actual_reference_rows': 10,
               'two_field_set_controls': {'row_order_invariant': positive, 'missing_record_rejected': missing, 'null_summary_rejected': wrongtype},
               'physical_SQL_schema': {'format': schema['format'], 'table_count': len(schema['tables']), 'shape_valid': True,
                                       'pre_call_physical_validation_receipts_equal': True, 'physical_DB_reopened_by_this_audit': False},
               'execution_scope': 'Saved actual native/SQL execution outcomes were scored; this independent audit did not execute any generated query or recertify source truth.',
               'original560_admission_delta': 0, 'API_calls': 0, 'native_container_operations': 0,
               'database_connections': 0, 'FTS_searches': 0, 'generated_query_executions': 0,
               'scientific_input_or_output_modifications': 0, 'human_experts': 0, 'reviewer_kind': 'nonblind_AI',
               'limits': ['Separate enriched source cohort, not pooled with original560 or historical evaluation.',
                          'Common underlying facts do not establish equal exposure, complete retrieval or causal superiority.',
                          'C has a valid partial two-record answer with zero complete-record matches; it is not a strict parse failure.',
                          'D is rejected by the original strict answer parser; no prose/fenced recovery is scored.']}
    assert len(checked_pins) == 169 and len(OMITTED) == 3
    receipt['status'] = 'PASS_PORTABLE_SAVED_FIRST5_PROMPT_PARSER_SCORE_REPLAY'
    receipt['historical_independent_audit_sha256'] = AUDIT_SHA
    receipt['source_manifest_sha256'] = SOURCE_SHA
    receipt['closed_evidence_file_count'] = len(INVENTORY['files'])
    print(json.dumps(receipt, ensure_ascii=False, allow_nan=False))

if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--source-evidence',type=RealPath,default=HOME.parent/'original_core_source_RAN4_source93_exact_DESC');v=a.parse_args();setup(v.source_evidence);main()
