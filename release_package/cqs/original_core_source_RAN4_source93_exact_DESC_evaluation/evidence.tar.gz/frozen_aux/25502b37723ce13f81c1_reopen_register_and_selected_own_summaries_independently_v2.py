#!/usr/bin/env python3
"""Independent original XML and bounded CR form replay. No SQL or native operations."""
from pathlib import Path
from collections import Counter
from xml.etree import ElementTree as ET
import hashlib,importlib.util,io,json,re,sqlite3,sys,urllib.request,zipfile
sys.dont_write_bytecode=True
ROOT=Path('/home/sihyeon/workspace/spectra');O=ROOT/'logs/pending-tasks/spectracq-core-contract-2026-10-13/empirical/overnight_reaudit/root_evidence/two_agent_unresolved_loop'
OUT=Path(__file__).resolve().parent;H=O/'priority71_fast_closure/RAN4_93_exact_DESC_common_source_v1';L=O/'RAN2_RAN5/source_lane13'
PK=L/'RAN4_93_additive_source_snapshot_portable_v1/package_v2';N=O/'root_RAN4_source93_exact_DESC_native_v2'
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';X='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}';M='{http://schemas.openxmlformats.org/officeDocument/2006/math}'
def refuse(*a,**kw):raise AssertionError('No database or network operation permitted')
sqlite3.connect=refuse;urllib.request.urlopen=refuse
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
def save(n,x):
 p=OUT/n;assert not p.exists();p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');return pin(p)
def visible(e):
 if e.tag in (W+'del',W+'moveFrom'):return ''
 if e.tag==W+'t':return e.text or ''
 if e.tag==W+'tab':return '\t'
 if e.tag in (W+'br',W+'cr'):return '\n'
 return ''.join(visible(c) for c in e)
def cell(e):return '\n'.join(visible(p) for p in e.findall(W+'p')).strip()
def fold(t):return ' '.join(t.split())
report=ROOT/'data/corpus/tsg/RAN/formal/meetings/RAN4/source/TSGR4_93/Report/R4-2000002.zip'
with zipfile.ZipFile(report) as z:
 assert z.testzip() is None;wb=z.read('TDoc_List_Meeting_RAN4#93.xlsx')
with zipfile.ZipFile(io.BytesIO(wb)) as z:
 assert z.testzip() is None
 shared=[''.join(x.itertext()) for x in []]
 shared=[''.join(e.text or '' for e in si.iter(X+'t')) for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall(X+'si')]
 sheetbytes=z.read('xl/worksheets/sheet1.xml');sheet=ET.fromstring(sheetbytes)
 header=None;register={};physical_rows=0
 for row in sheet.iter(X+'row'):
  physical_rows+=1;values={}
  for c in row.findall(X+'c'):
   coordinate=c.attrib['r'];column=re.match('[A-Z]+',coordinate).group();typ=c.get('t');v=c.find(X+'v')
   value=shared[int(v.text)] if typ=='s' and v is not None else ''.join(t.text or '' for t in c.iter(X+'t')) if typ=='inlineStr' else v.text or '' if v is not None else ''
   values[column]=value
  if header is None:header=values;assert 'TDoc' in header.values();continue
  p={name:values.get(col,'') for col,name in header.items() if name}
  if not p.get('TDoc'):continue
  td=p['TDoc'];assert td not in register
  register[td]={'excel_row':int(row.get('r')),'properties':p,'ET_UTF8_row_sha256':sha(ET.tostring(row,encoding='utf-8'))}
assert len(register)==3112
retained={r['tdocNumber']:r for r in map(json.loads,(PK/'source/all3112_register.jsonl').read_text().splitlines())}
assert set(register)==set(retained)
for td,r in register.items():
 assert r['properties']==retained[td]['properties']
 assert r['excel_row']==retained[td]['excel_row']
 assert r['ET_UTF8_row_sha256']==retained[td]['ET_UTF8_row_sha256']
observations={r['tdocNumber']:r for r in map(json.loads,(PK/'source/all1858_observations.jsonl').read_text().splitlines())}
assert set(observations)=={td for td,r in register.items() if r['properties']['Type'] in {'CR','draftCR','pCR'}}
for td,r in observations.items():
 p=register[td]['properties'];assert (r['original_type'],r['original_final_status'],r['original_revised_to'])==(p['Type'],p['TDoc Status'],p['Revised to'])
eligible=[td for td,p in register.items() if p['properties']['Type'] in {'CR','draftCR','pCR'} and p['properties']['TDoc Status'] in {'agreed','approved','endorsed'}]
positive=[td for td in eligible if observations[td]['source_summary'] is not None]
assert len(eligible)==1027 and len(positive)==808
variants={
 'all_CR_classes_three_statuses_before_summary':sorted(eligible,reverse=True)[:10],
 'all_CR_classes_three_statuses_nonnull_summary':sorted(positive,reverse=True)[:10],
 'strict_CR_agreed_before_summary':sorted((td for td in eligible if register[td]['properties']['Type']=='CR' and register[td]['properties']['TDoc Status']=='agreed'),reverse=True)[:10],
 'all_CR_classes_agreed_before_summary':sorted((td for td in eligible if register[td]['properties']['TDoc Status']=='agreed'),reverse=True)[:10]}
expected=variants['all_CR_classes_three_statuses_before_summary'];assert all(x==expected for x in variants.values())
assert len(expected)==len(set(expected))==10
fields=[]
spec=importlib.util.spec_from_file_location('independent_binary_doc_fields',ROOT/'scripts/tsg/RAN/formal/common/doc_fields.py');df=importlib.util.module_from_spec(spec);spec.loader.exec_module(df)
for td in expected:
 ob=observations[td];assert len(ob['source_fields'])==1;field=ob['source_fields'][0]
 archive=ROOT/ob['archive']['path'];assert sha(archive.read_bytes())==ob['archive']['sha256']
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None;member=z.read(field['member']['name']);crc=z.getinfo(field['member']['name']).CRC
 assert sha(member)==field['member']['sha256'] and crc==field['member']['CRC32']
 binary=None;derivative=None
 if field['access']=='original_DOCX':docx=member
 else:
  assert member[:8]==bytes.fromhex('d0cf11e0a1b11ae1')
  derivative=ROOT/field['derivative']['pin']['path'];sibling=ROOT/field['derivative']['original_DOC']['path']
  assert sibling.read_bytes()==member and sha(derivative.read_bytes())==field['derivative']['pin']['sha256'];docx=derivative.read_bytes()
  stories,props=df._doc_read(member,props=True);raw=stories[0];live=props[0][1].replace('\ufdd0','') if props and props[0] is not None else None
  binary={'raw_main_story_sha256':sha(raw.encode()),'visible_field_result_summary_folded_present':fold(ob['source_summary']) in fold(df._visible(raw)),
    'raw_summary_folded_present':fold(ob['source_summary']) in fold(raw),'live_deletion_story_available':live is not None,
    'live_summary_folded_present':None if live is None else fold(ob['source_summary']) in fold(df._visible(live)),
    'native_strike_properties_decoded':False}
  assert binary['visible_field_result_summary_folded_present']
 with zipfile.ZipFile(io.BytesIO(docx)) as z:
  assert z.testzip() is None;xml=z.read('word/document.xml');styles=z.read('word/styles.xml')
 assert sha(xml)==field['word_document_XML_sha256'] and sha(styles)==field['styles_XML_sha256']
 tree=ET.fromstring(xml);style=ET.fromstring(styles);paragraphs=[visible(p) for p in tree.iter(W+'p')]
 own_tokens=sorted(set(re.findall(r'R4-\d{7}', '\n'.join(paragraphs[:30]))));assert td in own_tokens
 rows=[]
 for table in tree.iter(W+'tbl'):
  for row in table.findall(W+'tr'):
   cells=[cell(tc) for tc in row.findall(W+'tc')]
   if cells and re.fullmatch(r'\s*Summary\s+of\s+change\s*:\s*',cells[0],re.I):rows.append((row,cells))
 assert len(rows)==1;row,cells=rows[0];summary='\n'.join(cells[1:]).strip();assert summary==ob['source_summary']
 issues=[{'tag':e.tag,'attributes':dict(e.attrib)} for part in (row,style) for e in part.iter() if e.tag in {W+'strike',W+'dstrike',W+'vanish',W+'webHidden'} and e.get(W+'val','true').lower() not in {'0','false','off'}]
 deleted=len(list(row.iter(W+'del')))+len(list(row.iter(W+'moveFrom')))
 math=len(list(row.iter(M+'oMath')));drawing=len(list(row.iter(W+'drawing')))
 assert issues==[] and deleted==math==drawing==0
 fields.append({'tdocNumber':td,'original_register':register[td],'original_archive':pin(archive),'original_member':field['member'],'original_member_sha256':sha(member),
  'access':field['access'],'existing_derivative':None if derivative is None else pin(derivative),'own_cover_first30_tokens':own_tokens,
  'word_document_xml_sha256':sha(xml),'styles_xml_sha256':sha(styles),'summary_row_ET_UTF8_sha256':sha(ET.tostring(row,encoding='utf-8')),
  'summary':summary,'summary_row_XML':ET.tostring(row,encoding='unicode'),'deleted_or_moveFrom_nodes':deleted,'positive_strike_hidden_style_nodes':issues,
  'OMML_nodes':math,'drawing_nodes':drawing,'original_CFB_corroboration':binary})
records=[{'tdocNumber':r['tdocNumber'],'summary':r['summary']} for r in fields]
assert len({r['summary'] for r in records})==10
capture=read(N/'actual_native_two_field_DESC_capture.json');sql=read(N/'actual_immutable_SQL_two_field_DESC_reference.json')
assert set(capture)=={'selected','whole_eligible_pool'}
for name,n in [('selected',10),('whole_eligible_pool',808)]:
 c=capture[name];s=sql['rows'][name];assert c['columns']==['tdocNumber','summary'];assert len(c['rows'])==len(s)==n
 assert c['complete'] and not c['truncated'] and c['transaction_rolled_back'] and not c['contains_updates'] and c['EXPLAIN_query_type']==c['actual_query_type']=='r'
 assert c['rows']==s
 assert len(c['rows'])==len({(r[0],r[1]) for r in c['rows']})
 expectedpool=[[td,observations[td]['source_summary']] for td in sorted(positive,reverse=True)]
 assert c['rows']==(expectedpool[:10] if name=='selected' else expectedpool)
assert records==[dict(zip(capture['selected']['columns'],r)) for r in capture['selected']['rows']]
assert records==[json.loads(l) for l in(N/'RAN4_P4_CQ4-5.jsonl').read_text().splitlines()]
receipt={'status':'PASS_FRESH_RAW_XML_WHOLE_REGISTER_BOUNDED_OWN_SUMMARY_AND_SAVED_ROOT_NATIVE_SQL_COMPARISON','original_id':'RAN4_P4_CQ4-5',
 'whole_original_register_rows':len(register),'original_register_physical_rows':physical_rows,'original_register_sheet_XML_sha256':sha(sheetbytes),'all3112_register_raw_properties_and_rowhashes_exact':True,
 'CR_family_source_observations':len(observations),'type_status_candidates':len(eligible),'nonnull_source_summary_pool':len(positive),'counterpolicies_DESC10':variants,
 'all_higher_candidates_have_direct_own_summary':True,'source_derived_records':records,'selected_unique_IDs':10,'selected_unique_summary_values':10,
 'source_summary_fields':fields,'whole808_root_saved_native_SQL_source_projection_exact':True,'ROOT_native_execution_attribution':True,
 'new_native_SQL_API_calls_by_this_reviewer':0,'new_conversions':0,'original560_admissions':0,'public_or_central_mutations':0,
 'CFB_assurance':'Five exact-member existing conversions corroborated in original main-story visible field text;3 live-deletion stories corroborated,2 unavailable; original binary strike properties are not decoded. No discrepant own-summary text observed.',
 'source_pins':[pin(p) for p in [report,PK/'source/all3112_register.jsonl',PK/'source/all1858_observations.jsonl',N/'actual_native_exact_DESC_receipt.json',N/'actual_native_two_field_DESC_capture.json',N/'actual_immutable_SQL_two_field_DESC_reference.json',Path(__file__)]]}
p=save('actual_independent_secondary_register_own_summary_and_saved_native_replay.json',receipt)
print(json.dumps({'status':'PASS','receipt':p,'register':3112,'selected':10,'whole_pool':808}))
