from pathlib import Path
import json,hashlib,shutil,difflib,sqlite3,importlib.util,sys
R=Path('/home/sihyeon/workspace/spectra');O=R/'logs/pending-tasks/spectracq-core-contract-2026-10-13/empirical/overnight_reaudit/root_evidence/two_agent_unresolved_loop';H=O/'priority71_fast_closure/RAN4_93_exact_DESC_common_source_v1';E=O/'root_RAN1_common3176_prepared_evaluation_v1';T=H/'runtime_preparation_v1';T.mkdir(exist_ok=False);(T/'runtime').mkdir();(T/'scoring').mkdir()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(8*1024*1024):h.update(b)
 return h.hexdigest()
def save(n,d):
 p=T/n;p.parent.mkdir(exist_ok=True,parents=True)
 with p.open('x')as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
def module(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
changes=[]
for q in sorted((E/'runtime').glob('*.py')):
 target=T/'runtime'/q.name
 if q.name=='retrieval_adapter.py':
  text=q.read_text();old="CORPUS_DIR = Path('/home/sihyeon/workspace/spectra/logs/pending-tasks/spectracq-core-contract-2026-10-13/empirical/overnight_reaudit/root_evidence/two_agent_unresolved_loop/RAN1_RAN3_RAN4/loop121_RAN1_generic_fullgraph_FTS_disjoint_repeat_merge/actual_corpus')";assert text.count(old)==1
  text=text.replace(old,'CORPUS_DIR = Path('+repr(str(H/'actual_corpus'))+')');assert text.count("working_groups or ('RAN1',)")==1;text=text.replace("working_groups or ('RAN1',)","working_groups or ('RAN4',)");target.write_text(text)
 else:shutil.copyfile(q,target)
 changes.append({'source':str(q),'source_sha256':sha(q),'prepared':str(target.relative_to(T)),'prepared_sha256':sha(target),'byte_equal':q.read_bytes()==target.read_bytes()})
 if q.read_bytes()!=target.read_bytes():(T/(q.name+'.adaptation.diff')).write_text(''.join(difflib.unified_diff(q.read_text().splitlines(True),target.read_text().splitlines(True),fromfile=str(q),tofile=str(target))))
for q in sorted((E/'scoring').iterdir()):
 if q.is_file():shutil.copyfile(q,T/'scoring'/q.name)
shutil.copyfile(E/'run_pre_call_physical_schema_and_stage_controls.py',T/'run_pre_call_physical_schema_and_stage_controls.py')
sql=O/'root_RAN4_source93_full_materialized_v1/RAN4-source93.sqlite';ttl=sql.with_name('RAN4-source93-body.ttl');fts=H/'actual_corpus/ran4.sqlite3'
pins={k:{'path':str(p),'sha256':sha(p)}for k,p in [('TTL_input',ttl),('SQL_input',sql),('FTS_input',fts)]}
physical=module(T/'runtime/physical_schema.py','R4_actualphysicalDDL');schema,receipt=physical.build(str(sql),pins['SQL_input']['sha256']);save('sql_schema.json',schema);save('actual_complete_physical_SQL_schema_build.json',receipt)
c=sqlite3.connect(sql.as_uri()+'?mode=ro&immutable=1',uri=True);c.execute('PRAGMA query_only=ON')
labels=[r[0]for r in c.execute('select distinct label from node_label order by label')]
props={x:{'iri':['STRING']}for x in labels}
types={'array':'LIST','boolean':'BOOLEAN','integer':'INTEGER','number':'FLOAT','string':'STRING','object':'MAP','null':'NULL'}
for l,k,t in c.execute('select distinct l.label,p.key,p.native_type from node_label l join node_property p using(node_id) order by l.label,p.key,p.native_type'):
 props[l].setdefault(k,[]).append(types[t])
rels=[list(x)for x in c.execute('select distinct a.label,e.rel_type,b.label from edge e join node_label a on a.node_id=e.src_id join node_label b on b.node_id=e.dst_id order by a.label,e.rel_type,b.label')];c.close()
save('graph_schema.json',{'labels':labels,'properties_by_label':props,'directed_relationships':rels,'auxiliary_identity_codec':'iri is a loader-assigned stable node identity. Property types are the observed type union over every source node bearing this label, without nonnull assertions. No property value, example or population count is supplied in this schema.'})
d=json.loads((H/'exact_DESC_two_field_source_definition_NOT_ADMITTED.json').read_text())
task={k:d[k]for k in ['id','question_en','collection','cardinality_policy','repair_sha256']};task['wg']='RAN4';task['required_fields']=[{k:f[k]for k in ['name','type','nullable']}for f in d['required_fields']]
task['selection_policy']={'kind':'original_authored_DESC_bounded_documentary_change_summary_review','order_keys':[{'field':'tdocNumber','direction':'desc','comparison':'lexical'}],'limit':10,'serialization':'Set of tdocNumber and literal own Summary of change pairs; row serialization order is not scored.','approval_scope':'Final recorded documentary WG acceptance at the question meeting, not physical-week attendance, TSG approval or normative incorporation. Use original own register CR/draftCR/pCR identity/type and final status agreed/approved/endorsed, and its own nonnull source Summary of change field. These are the same separate-source interpretation for every method.','null_policy':'Exclude absent own summaries before DESC selection; do not infer a missing summary from its title, abstract, another CR or another revision.'}
assert 'literal_terms'not in task['selection_policy'];save('public_tasks.json',[task])
save('prospective_preparation.json',{'status':'PREPARED_NOT_FROZEN_NO_NEW_CALLS','cohort':'RAN4_source93_exact_DESC_two_field_N1_common_fullgraph','original560_admission_delta':0,**pins,'parent_source_handoff_manifest_sha256':sha(H/'manifest.json'),'definition_sha256':sha(H/'exact_DESC_two_field_source_definition_NOT_ADMITTED.json'),'source_pool_distinction':{'status_type_pool_before_own_summary_join':1027,'exact_nonnull_own_summary_inner_pool':808,'selected':10,'authority':'Root immutable SQL preflight; 1027 is not asserted to be the exact nonnull pool. The earlier ASC1027 hard-check failure is preserved by root.'},'runtime_adaptations':changes,'runtime_source':'Latest root RAN1 current preparation bytes; no saved responses, predictions, contexts or scores copied.','source_policy':'Same separate fullgraph facts for native/SQLite/generic FTS, not equal retrieval exposure/cost. No raw cover, private review, reference query, source-prefix fixture or answer is a generator input.','expected_N_per_method':1,'expected_method_items':4,'expected_request_stages':5,'new_API_calls':0,'new_native_calls':0,'public_or_source_graph_changes':0,'human_expert_validation_n':0})
# R1 runner deliberately copied into a separate new filename, with explicit finite adaptations.
old=(E/'run_separate_common3176_experiment.py').read_text();text=old
repls=[('three-question','one-question'),('RAN1_common3176_three_question_source_variant','RAN4_source93_exact_DESC_two_field_N1_common_fullgraph'),('RAN1_new','RAN4_new'),('RAN1_freeze','RAN4_freeze'),('len(ids) == 3','len(ids) == 1'),("'N_per_method': 3","'N_per_method': 1"),("'expected_request_stages': 15","'expected_request_stages': 5"),("target['name'].startswith('kdd-db-source-ran1-')","target['name'].startswith('kdd-db-source-ran4-')"),('(nodes, edges) == (165418, 848228)','(nodes, edges) == (346617, 1600412)'),("'expected_total_method_items': 12","'expected_total_method_items': 4"),("{'N': 3, 'f1':","{'N': 1, 'f1':"),(" / 3,"," / 1,"),('Fixed recorded literal keyword search, not proof of new technical changes.','Final documentary WG acceptance plus original own Summary of change; not TSG approval, physical-week attendance, normative incorporation, or a whole-population rendered-binary certification.')]
for a,b in repls:
 assert a in text,a;text=text.replace(a,b)
oldblock="""    official_path = pin(cfg['definition_digest_implementation'])
    sys.path.insert(0, str(official_path.parent))
    official = module(official_path, 'RAN1_definition_digest')
    files.append(official_path)
"""
assert oldblock in text;text=text.replace(oldblock,'')
oldblock="""        assert set(d) == set(official.DEFINITION_KEYS)
        assert official.digest({key: d[key] for key in official.DEFINITION_KEYS}) == public['repair_sha256']
        assert d['original_question_preserved'] is True
"""
newblock="""        # This separate source contract hashes its complete prospective definition
        # excluding only the self hash; the original560 schema is not silently reused.
        assert hashlib.sha256(canonical({k: v for k, v in d.items() if k != 'repair_sha256'}).encode()).hexdigest() == public['repair_sha256']
        assert d['repair_sha256'] == public['repair_sha256']
        assert hashlib.sha256(d['question_en'].encode()).hexdigest() == d['original_question_sha256']
        assert d['required_fields'] == [
            {'name':'tdocNumber','type':'string','nullable':False,'source_column_or_expression':'d.tdocNumber'},
            {'name':'summary','type':'string','nullable':False,'source_column_or_expression':'s.sourceSummary'}]
        assert d['collection'] == {'kind':'set'} and d['cardinality_policy'] == {'mode':'exact','value':10}
"""
assert oldblock in text;text=text.replace(oldblock,newblock)
# Same actual interpreter imports are checked before freeze and paid calls, without opening a connection.
needle="def freeze(cfg, config_path):\n";assert text.count(needle)==1
text=text.replace(needle,"""def interpreter_preflight(cfg):
    import importlib.metadata
    import neo4j
    from neo4j import GraphDatabase, READ_ACCESS
    assert sys.executable == cfg['execution_interpreter'], 'Use the exact preflighted interpreter for every stage'
    return {'sys_executable':sys.executable,'neo4j_version':importlib.metadata.version('neo4j'),
            'neo4j_origin':neo4j.__file__,'GraphDatabase_import_available':GraphDatabase is not None,
            'READ_ACCESS_import_available':READ_ACCESS is not None,'native_or_network_calls':0}


def freeze(cfg, config_path):
    interpreter_receipt = interpreter_preflight(cfg)
""")
text=text.replace("'budget_usd': cfg['budget_usd'], 'physical_SQL_interface_gate': sql_receipt,","'budget_usd': cfg['budget_usd'], 'physical_SQL_interface_gate': sql_receipt, 'execution_interpreter_preflight':interpreter_receipt,")
text=text.replace("def calls(cfg, config_path):\n    verify_freeze(cfg, config_path)","def calls(cfg, config_path):\n    interpreter_preflight(cfg)\n    verify_freeze(cfg, config_path)")
text=text.replace("def execute(cfg, config_path):\n    verify_freeze(cfg, config_path)","def execute(cfg, config_path):\n    interpreter_preflight(cfg)\n    verify_freeze(cfg, config_path)")
(T/'run_separate_source93_experiment.py').write_text(text)
(T/'run_separate_source93_experiment.py.adaptation.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile=str(E/'run_separate_common3176_experiment.py'),tofile=str(T/'run_separate_source93_experiment.py'))))
# Incomplete configuration cannot pass config() or freeze(). Root supplies exact native/secondary/control receipts.
empty={'path':None,'sha256':None,'assertions':[]}
cfg={'cohort':'RAN4_source93_exact_DESC_two_field_N1_common_fullgraph','original560_admission_delta':0,'ready_for_root_review':False,'budget_usd':None,'execution_interpreter':sys.executable,'trial_directory':str(T/'ROOT_NEW_FIRST_TRIAL_NOT_CREATED'),'native_lock_path':str(O.parents[1]/'native_capture.lock'),**pins,'cases':{d['id']:{'definition':{'path':str(H/'exact_DESC_two_field_source_definition_NOT_ADMITTED.json'),'sha256':sha(H/'exact_DESC_two_field_source_definition_NOT_ADMITTED.json')},'actual_reference_rows':{'path':None,'sha256':None,'provenance':'actual_owned_native_capture'}}},'gate_receipts':{k:dict(empty)for k in ['whole_native_reference_capture','whole_independent_SQL_agreement','independent_second_seven_unit_semantics','generic_and_boundary_scoring_controls','whole_source_and_FTS_equivalence']},'native_manifest':{'path':None,'sha256':None},'native_container':{'name':None,'port':None,'bolt':None,'run_uuid':None,'source_sha256':pins['TTL_input']['sha256'],'image_id':None},'read_query_guard':{'path':'/home/sihyeon/workspace/spectra-public/spec-trace/release_package/cqs/contract_repair_v1/replay_generated_read_queries.py','sha256':'0a710cec92a65d7034e24d47e78abdd7a175947229c675064b65056664cd0e66'},'additional_evidence_files':[],'scoring_files':[{'path':str(q),'sha256':sha(q)}for q in sorted((T/'scoring').iterdir())if q.is_file()]}
save('root_configuration_TEMPLATE_INCOMPLETE_DO_NOT_EXECUTE.json',cfg)
runner=module(T/'run_separate_source93_experiment.py','RAN4_prospective_runner');save('actual_same_interpreter_neo4j_import_preflight.json',runner.interpreter_preflight(cfg))
# Syntax only, no code phase or network/native call.
for q in T.rglob('*.py'):compile(q.read_text(),str(q),'exec')
save('draft_code_checks.json',{'status':'PASS','python_source_syntax_compiled':len(list(T.rglob('*.py'))),'same_interpreter_neo4j_import':'PASS','new_API_native_calls':0,'freeze_written':False})
shutil.copyfile('/tmp/prepare_ran4_runtime_v1.py',T/'prepare_runtime_from_pinned_RAN1_history.py')
print(json.dumps({'status':'PREPARED_NOT_FROZEN','path':str(T),'runtime_n':len(changes),'schema_tables':len(schema['tables']),'labels':len(labels),'relationship_triples':len(rels),'interpreter':sys.executable,'calls':0}))
