#!/usr/bin/env python3
"""Hash/JSON/AST-only audit. Never loads a runtime module or opens a database."""
from pathlib import Path
from decimal import Decimal
import ast, hashlib, json, time
HERE=Path(__file__).resolve().parent
O=HERE.parents[2]
E=O/'root_RAN4_source93_exact_DESC_prepared_evaluation_v1'
T=O/'priority71_fast_closure/RAN4_93_exact_DESC_common_source_v1/runtime_preparation_v1'
EXPECTED_CONFIG='6549e4d19520ce9cfbb96715d725cc7bc16732c43bf0fc9ae87adf9d8a272696'
def read(p):return json.loads(Path(p).read_text())
cache={}
def sha(p):
    p=Path(p).resolve(strict=True)
    if p in cache:return cache[p]
    h=hashlib.sha256()
    with p.open('rb')as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    cache[p]=h.hexdigest();return cache[p]
def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
c=read(E/'root_configuration.json')
assert sha(E/'root_configuration.json')==EXPECTED_CONFIG
assert c['cohort']=='RAN4_source93_exact_DESC_two_field_N1_common_fullgraph'
assert c['original560_admission_delta']==0 and c['ready_for_root_review'] is True
assert c['budget_usd']==3.0 and c['execution_interpreter']=='/usr/bin/python3'
assert set(c['cases'])=={'RAN4_P4_CQ4-5'}
assert len(c['additional_evidence_files'])==144
assert not (E/'precall_freeze.json').exists() and not Path(c['trial_directory']).exists()
allpins=[]
def walk(v):
    if isinstance(v,dict):
        if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
            p=Path(v['path']);assert p.is_file() and not p.is_symlink(),v
            assert sha(p)==v['sha256'],v
            if 'bytes'in v:assert p.stat().st_size==v['bytes'],v
            allpins.append({'path':str(p),'sha256':v['sha256'],'bytes':p.stat().st_size})
        for x in v.values():walk(x)
    elif isinstance(v,list):
        for x in v:walk(x)
walk(c)
upstream=read(E/'upstream_preparation_manifest.json')
assert sha(E/'upstream_preparation_manifest.json')==sha(T/'preparation_manifest.json')=='92d5ba339ed121bc55d164df30f6b32d7b3774e1586b59c72e4a41e2d45629cb'
for f in upstream['files']:
    assert (E/f['path']).is_file() and sha(E/f['path'])==sha(T/f['path'])==f['sha256'],f
    assert (E/f['path']).stat().st_size==f['bytes']
assert len(upstream['files'])==42
gate_results=[]
expected_gates={'whole_native_reference_capture','whole_independent_SQL_agreement','independent_second_seven_unit_semantics','generic_and_boundary_scoring_controls','whole_source_and_FTS_equivalence'}
assert set(c['gate_receipts'])==expected_gates
for name,g in c['gate_receipts'].items():
    v=read(g['path']);assert g['assertions']
    for a in g['assertions']:
        x=v
        for key in a['key_path']:x=x[key]
        assert x==a['equals'],(name,a,x)
    gate_results.append({'name':name,'sha256':g['sha256'],'assertions_passed':len(g['assertions'])})
case=c['cases']['RAN4_P4_CQ4-5'];d=read(case['definition']['path']);public=read(E/'public_tasks.json')
assert len(public)==1;p=public[0]
assert hashlib.sha256(canonical({k:v for k,v in d.items()if k!='repair_sha256'}).encode()).hexdigest()==d['repair_sha256']==p['repair_sha256']=='7957b2aafd2de27129500c98ae5190bd630e63dc6cdfecba248a92fced97e42d'
assert d['question_en']==p['question_en'] and hashlib.sha256(d['question_en'].encode()).hexdigest()==d['original_question_sha256']
assert p['required_fields']==[{'name':'tdocNumber','type':'string','nullable':False},{'name':'summary','type':'string','nullable':False}]
assert d['collection']==p['collection']=={'kind':'set'}
assert d['cardinality_policy']==p['cardinality_policy']=={'mode':'exact','value':10}
ref=[json.loads(x)for x in Path(case['actual_reference_rows']['path']).read_text().splitlines()if x]
assert len(ref)==10 and all(set(x)=={'tdocNumber','summary'}and all(isinstance(v,str)and v for v in x.values())for x in ref)
assert len({(x['tdocNumber'],x['summary'])for x in ref})==len({x['tdocNumber']for x in ref})==10
assert [x['tdocNumber']for x in ref]==sorted((x['tdocNumber']for x in ref),reverse=True)
N=O/'root_RAN4_source93_exact_DESC_native_v2'
cap=read(N/'actual_native_two_field_DESC_capture.json');sql=read(N/'actual_immutable_SQL_two_field_DESC_reference.json')
assert cap['selected']['rows']==sql['rows']['selected']==ref
assert cap['whole_eligible_pool']['rows']==sql['rows']['whole_eligible_pool']
assert len(cap['whole_eligible_pool']['rows'])==808
assert all(cap[k]['complete']is True for k in ['selected','whole_eligible_pool'])
assert cap['whole_eligible_pool']['rows'][:10]==ref
native=read(c['native_manifest']['path']);exact=read(c['gate_receipts']['whole_native_reference_capture']['path']);target=c['native_container']
assert target['name']==native['target']['container']=='kdd-db-source-ran4-source93-audit-v1'
assert target['bolt']==native['target']['bolt']=='bolt://127.0.0.1:57914'
assert target['port']==57914 and target['run_uuid']==native['run_uuid']==exact['container_run_uuid']=='788bf7e6-b965-4721-9feb-4ce1ff8619cc'
assert target['image_id']==native['image_id']=='sha256:3b9cf65b6cae8b166d5091969e80a5600028aa2e8676a45a925dcc15c379024e'
assert target['source_sha256']==native['source']['sha256']==exact['source_sha256']==c['TTL_input']['sha256']
assert native['db']['sha256']==exact['db_sha256']==c['SQL_input']['sha256']
assert native['parse_inventory']['nodes']==346617 and native['parse_inventory']['relationships']==1600412
assert native['owned_container_stopped']is True and exact['owned_container_stopped']is True
assert native['whole_eligible_rows']==1027 and exact['whole_eligible_rows']==808
stage_receipts=read(N/'actual_owned_container_lifecycle_stages.json')
assert stage_receipts[0]['validated_stage']==stage_receipts[-1]['validated_stage']=='stopped'
assert all(x['status']=='PASS'and x['inspection_response_mutated']is False for x in stage_receipts)
assert all(x['validated_stage']=='running'for x in stage_receipts[1:-1])
stages=read(E/'actual_common_contract_and_two_field_controls/actual_mock_five_stage_messages.json')
assert len(stages)==5
est=0.0
for stage in stages:
    messages=stage['messages'];u=json.loads(messages[1]['content'].split('\nSOURCE PASSAGES:\n',1)[0])
    contract=u.get('contract',u.get('output_format'))
    assert u['question']==p['question_en'] and contract['required_fields']==p['required_fields']
    assert (u['selection_policy']if 'selection_policy'in u else contract['selection_policy'])==p['selection_policy']
    assert all(x not in u for x in ['reference_query','gold','native_rows','primary_review','secondary_review'])
    est+=2*(sum(len(m['content'])for m in messages)/3.0*0.000005+stage['max_tokens']*0.000025)
budget=read(E/'actual_pre_call_budget_estimate.json')
assert abs(est-budget['estimated_two_attempt_all_stage_reservation_usd'])<1e-12 and est<3.0
assert budget['not_an_account_balance_or_strict_token_cost_cap']is True
sqlschema=read(E/'sql_schema.json');graph=read(E/'graph_schema.json')
assert sqlschema['format']=='physical_sqlite_ddl'and len(sqlschema['tables'])==85
assert sum(x['name'].startswith('rel_')for x in sqlschema['tables'])==50
assert all('SourceMeetingDocument'in json.dumps(x)for x in [sqlschema,graph])
assert all('SourceOwnCRSummary'in json.dumps(x)for x in [sqlschema,graph])
ddl=read(E/'actual_complete_physical_SQL_schema_build.json')
assert hashlib.sha256(canonical(sqlschema).encode()).hexdigest()==ddl['schema_sha256']
assert ddl['database_sha256']==c['SQL_input']['sha256']
controls=read(E/'actual_pre_call_mock_controls/receipt.json')
assert len(controls['SQL_schema_negative_cases'])==4 and all(x['rejected']and x['mock_call_count']==0 for x in controls['SQL_schema_negative_cases'])
assert len(controls['container_stage_cases'])==11
assert any(x['case']=='memory_swap'and x['rejected']for x in controls['container_stage_cases'])
scores=read(E/'actual_common_contract_and_two_field_controls/actual_synthetic_two_field_scoring_controls.json')
assert scores['status']=='PASS'and len(scores['cases'])==12
assert [x['case']for x in scores['cases']if x['score']['exact']]==['both_fields_exact','set_reverse_serialization']
for x in scores['cases']:
    if x['case']in ['ID_only','summary_only','swapped_pair_mapping','modified_summary','numeric_ID','null_summary','empty']:assert x['score']['f1']==0
code=(E/'run_separate_source93_experiment.py').read_text();tree=ast.parse(code)
f={x.name:ast.get_source_segment(code,x)for x in tree.body if isinstance(x,ast.FunctionDef)}
assert f['freeze'].index('interpreter_preflight(cfg)')<f['freeze'].index('physical.validate(')<f['freeze'].index('save(out,')
assert f['calls'].index('interpreter_preflight(cfg)')<f['calls'].index('credentials.secret(')
assert "assert clean == query"in f['execute_cypher']
assert f['execute_cypher'].index('inspect(False)')<f['execute_cypher'].index("command('docker', 'start'")<f['execute_cypher'].index('inspect(True)')
assert f['execute_cypher'].index('tx.rollback()')<f['execute_cypher'].index("command('docker', 'stop'")
assert '26 * GIB'in f['execute_cypher']and '16 * GIB'in f['execute_cypher']
guard=(E/'runtime/container_stage_guard.py').read_text()
assert "host.get('MemorySwap') != 2 * 1024**3"in guard and "host.get('NanoCpus') != 10**9"in guard
client=(E/'runtime/openrouter_client.py').read_text()
assert sha(E/'runtime/openrouter_client.py')=='602ab2b85cf5a39823c528644dabf8e0aa305cafba28d7efc1a92b1cb2adf141'
assert 'self.halted_unknown_cost = True'in client and 'for attempt in range(2):'in client
assert 'guard_is_approximate_not_a_provider_billing_cap'in client
preflight=read(E/'actual_same_interpreter_neo4j_import_preflight.json')
assert preflight['sys_executable']==c['execution_interpreter'] and preflight['GraphDatabase_import_available']is True
assert '/.local/'in preflight['neo4j_origin']
assert not (E/'precall_freeze.json').exists() and not Path(c['trial_directory']).exists()
receipt={'status':'PASS_FINAL_ROOT_CONFIGURATION_STATIC_PRECALL_AUDIT_NO_BLOCKERS','root_configuration_sha256':EXPECTED_CONFIG,'cohort':c['cohort'],'cases':list(c['cases']),'N_per_method':1,'method_items':4,'expected_request_stages':5,'original560_admission_delta':0,'additional_evidence_pins':144,'config_pin_occurrences_checked':len(allpins),'unique_files_rehashed':len(cache),'unique_bytes_rehashed':sum(p.stat().st_size for p in cache),'copied_preparation_files_byte_equal':42,'gate_assertions':gate_results,'native_reference_records':10,'whole_native_SQL_rows':808,'native_and_SQL_and_reference_exact_order_equal':True,'reference_two_field_set_self_comparison':{'intersection':10,'predicted':10,'reference':10,'f1':1.0,'exact':True,'actual_scorer_executed_in_this_audit':False},'synthetic_scorer_controls_saved_actual_receipts_checked':12,'common_selection_contract_all_saved_five_mock_messages_checked':True,'physical_schema_saved_actual_gate_checked':{'tables':85,'relationship_tables':50,'DB_not_opened_by_auditor':True},'budget_guard_usd':3.0,'all_five_stage_two_attempt_estimate_usd':est,'estimate_is_not_live_balance_or_actual_cost':True,'runtime_snapshot_and_gate_separation':{'historical_inventory_only_manifest_prior_ASC_pool':1027,'current_exact_DESC_nonnull_native_pool':808,'old_capture_not_relabelled_as_new_reference':True},'native_owned_clone_static_identity':target,'frozen_or_called_at_audit_end':False,'blockers':[],'required_root_execution_conditions':['Use /usr/bin/python3 -B, without -I, preserving installed user-site neo4j access.','Recheck live owned stopped container, host 26GiB/16GiB and exact source/image/resource guards at execution.','Freeze after adding only this audit evidence pin, preserve original question/query/source/reference/scoring and first attempts.','No output-quality retry or parser relaxation; unknown-cost latch cannot cancel already in-flight up to4 requests.'],'reviewer':'/root/verify_public467_readonly','distinct_agent_secondary':True,'nonblind_AI_review':True,'human_expert_validation_n':0,'DB_or_SQL_or_FTS_connections':0,'mock_adapter_or_transport_executions':0,'native_or_container_executions':0,'API_calls':0,'runtime_or_source_or_public_or_central_mutations':0}
out=HERE/'actual_final_root_configuration_static_pre_call_audit.json';assert not out.exists();out.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'path':str(out),'sha256':sha(out),'bytes':out.stat().st_size,'unique_hashes':len(cache),'config_pin_occurrences':len(allpins),'blockers':[]}))
