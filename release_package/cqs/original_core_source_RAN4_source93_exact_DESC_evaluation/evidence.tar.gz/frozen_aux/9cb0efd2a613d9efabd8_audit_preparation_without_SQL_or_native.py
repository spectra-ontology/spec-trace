#!/usr/bin/env python3
"""Independent prospective runtime audit; no SQL, network or native calls."""
from pathlib import Path
import ast, copy, hashlib, importlib.util, json, socket, sqlite3, sys, urllib.request
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
O = HERE.parents[2]
T = O/'priority71_fast_closure/RAN4_93_exact_DESC_common_source_v1/runtime_preparation_v1'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
def load(p,n):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def blocked(*a,**k): raise AssertionError('Independent audit forbids DB/network/native execution')
sqlite3.connect = blocked
socket.create_connection = blocked
urllib.request.urlopen = blocked
manifest=read(T/'preparation_manifest.json')
pins=[]
for item in manifest['files']:
    p=T/item['path']; assert p.is_file() and not p.is_symlink()
    assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],item
    pins.append(item)
for item in read(T/'prospective_preparation.json')['runtime_adaptations']:
    assert sha(item['source'])==item['source_sha256']
    assert sha(T/item['prepared'])==item['prepared_sha256']
    if item['byte_equal']: assert Path(item['source']).read_bytes()==(T/item['prepared']).read_bytes()
runner=load(T/'run_separate_source93_experiment.py','R4_independent_runner')
s=load(T/'runtime/structured_adapter.py','R4_independent_structured')
r=load(T/'runtime/retrieval_adapter.py','R4_independent_retrieval')
public=read(T/'public_tasks.json'); assert len(public)==1
task=public[0]
assert task['id']=='RAN4_P4_CQ4-5'
assert task['repair_sha256']=='7957b2aafd2de27129500c98ae5190bd630e63dc6cdfecba248a92fced97e42d'
assert task['collection']=={'kind':'set'} and task['cardinality_policy']=={'mode':'exact','value':10}
assert task['required_fields']==[{'name':'tdocNumber','type':'string','nullable':False},{'name':'summary','type':'string','nullable':False}]
assert task['selection_policy']['order_keys']==[{'field':'tdocNumber','direction':'desc','comparison':'lexical'}]
assert task['selection_policy']['limit']==10
prompts=[]
for method in ['Text2Cypher','Text2SQL']:
    messages=s.messages_for(runner.task(task['id'],method),method)
    value=json.loads(messages[1]['content'])
    assert value['question']==task['question_en']
    assert value['selection_policy']==task['selection_policy']
    assert value['output_format']['required_fields']==task['required_fields']
    assert value['output_format']['collection']==task['collection']
    prompts.append({'method':method,'prompt_sha256':hashlib.sha256(s.canonical(messages).encode()).hexdigest()})
assert r.public_contract(task)['selection_policy']==task['selection_policy']
assert r.public_contract(task)['required_fields']==task['required_fields']
private=[]
for name in ['gold','reference_query','native_rows','primary_review','reference_outputs']:
    try: s.messages_for(dict(runner.task(task['id'],'Text2Cypher'),**{name:'FORBIDDEN'}),'Text2Cypher')
    except ValueError: private.append(name)
    else: raise AssertionError(name)
parse_cases=[]
valid='{"records":[],"abstain":true,"complete":false}'
assert r.parse_answer(valid)['abstain'] is True
for name,content in [('prose_fenced','Answer:\n```json\n'+valid+'\n```'),('fenced','```json\n'+valid+'\n```'),('NaN','{"records":[{"summary":NaN}],"abstain":false,"complete":true}'),('string_boolean','{"records":[],"abstain":"false","complete":true}'),('abstain_with_records','{"records":[{}],"abstain":true,"complete":true}')]:
    try:r.parse_answer(content)
    except (ValueError,TypeError):parse_cases.append({'case':name,'rejected':True})
    else:raise AssertionError(name)
sys.path.insert(0,str(T/'scoring'))
sc=load(T/'scoring/original_scorer.py','R4_independent_scorer')
d=read(T.parent/'exact_DESC_two_field_source_definition_NOT_ADMITTED.json')
truth=[{'tdocNumber':f'SYNTH-{i:02d}','summary':f'synthetic own summary {i}'}for i in range(10)]
fixtures=[('exact',truth,True),('reversed_set',truth[::-1],True),('ID_only',[{'tdocNumber':x['tdocNumber']}for x in truth],False),('summary_only',[{'summary':x['summary']}for x in truth],False),('swapped_pair',[dict(x,summary=truth[(i+1)%10]['summary'])for i,x in enumerate(truth)],False),('changed_summary',[dict(x,summary=x['summary']+' CHANGED')for x in truth],False),('numeric_ID',[dict(x,tdocNumber=i)for i,x in enumerate(truth)],False),('null_summary',[dict(x,summary=None)for x in truth],False),('missing_one',truth[:-1],False),('duplicate_one',truth[:-1]+truth[:1],False),('empty',[],False),('one_record',truth[:1],False)]
scores=[]
for name,pred,exact in fixtures:
    v=sc.score(d,truth,pred,diagnostic=True)
    assert v['exact'] is exact,(name,v)
    if name in {'ID_only','summary_only','swapped_pair','changed_summary','numeric_ID','null_summary','empty'}:assert v['f1']==0,(name,v)
    if name=='missing_one':assert abs(v['f1']-18/19)<1e-12
    scores.append({'case':name,'score':v})
blocked_incomplete=False
try:runner.config(T/'root_configuration_TEMPLATE_INCOMPLETE_DO_NOT_EXECUTE.json')
except AssertionError:blocked_incomplete=True
assert blocked_incomplete
tree=ast.parse((T/'run_separate_source93_experiment.py').read_text())
functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
def function_text(name):return ast.get_source_segment((T/'run_separate_source93_experiment.py').read_text(),functions[name])
calls=function_text('calls'); execution=function_text('execute_cypher'); freeze=function_text('freeze')
assert 'ThreadPoolExecutor(max_workers=4)' in calls
assert "METHODS = ('Text2Cypher', 'Text2SQL', 'C', 'D')" in (T/'run_separate_source93_experiment.py').read_text()
assert "'expected_request_stages': 5" in freeze and "'N_per_method': 1" in freeze
assert 'interpreter_preflight(cfg)' in freeze
assert freeze.index('physical.validate(')<freeze.index('save(out,')
assert execution.index('inspect(False)')<execution.index("command('docker', 'start'")<execution.index('inspect(True)')
assert execution.index('tx.rollback()')<execution.index("command('docker', 'stop'")
assert '26 * GIB' in execution and '16 * GIB' in execution
assert "assert clean == query" in execution
receipt={'status':'PASS_PROSPECTIVE_PREPARATION_READONLY_NOT_FINAL_ROOT_CONFIG','preparation_manifest_sha256':sha(T/'preparation_manifest.json'),'manifest_files_rehashed':len(pins),'structured_prompts_rebuilt':prompts,'common_selection_policy_and_two_fields':True,'private_fields_rejected':private,'strict_retrieval_parse_negative_controls':parse_cases,'synthetic_two_field_score_controls':scores,'incomplete_template_rejected':blocked_incomplete,'source_runtime_bytes_inherited_exact_when_declared':True,'static_lifecycle_and_pre_call_DDL_order_checked':True,'final_root_config_freeze_and_call_authorization_not_audited_yet':True,'limits':['This audits preparation bytes and saved mock receipts, not actual root configuration or native state.','Physical DDL DB contents were not opened; existing root/agent DDL receipts are pinned rather than rerun.','Unknown-cost client is unchanged from independently tested RAN1 version. Its latch blocks queued unsent work but cannot cancel already in-flight requests.','Source final documentary acceptance interpretation remains bounded to the separate source variant; not a physical-week/TSG/normative claim.'],'new_API_calls':0,'new_native_or_container_calls':0,'SQL_or_FTS_connections':0,'public_or_central_mutations':0,'human_expert_validation_n':0}
out=HERE/'actual_preparation_static_prompt_parse_and_scoring_audit.json';assert not out.exists();out.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'output':str(out),'sha256':sha(out),'bytes':out.stat().st_size,'manifest_files':len(pins),'score_controls':len(scores),'strict_parse_negatives':len(parse_cases)}))
