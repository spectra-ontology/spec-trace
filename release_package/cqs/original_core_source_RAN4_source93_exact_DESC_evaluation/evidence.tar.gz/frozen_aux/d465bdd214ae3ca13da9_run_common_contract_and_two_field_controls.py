from pathlib import Path
import json,hashlib,importlib.util,sys,copy
H=Path('/home/sihyeon/workspace/spectra/logs/pending-tasks/spectracq-core-contract-2026-10-13/empirical/overnight_reaudit/root_evidence/two_agent_unresolved_loop/priority71_fast_closure/RAN4_93_exact_DESC_common_source_v1');T=H/'runtime_preparation_v1';OUT=T/'actual_common_contract_and_two_field_controls';OUT.mkdir(exist_ok=False)
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def save(n,d):(OUT/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=load(T/'runtime/structured_adapter.py','R4_teststructured');r=load(T/'runtime/retrieval_adapter.py','R4_testretrieval');runner=load(T/'run_separate_source93_experiment.py','R4_testrunner');task=json.loads((T/'public_tasks.json').read_text())[0];prep=json.loads((T/'prospective_preparation.json').read_text())
# Actual full corpus inventory is real, gold-free, immutable, and separate from the later first trial.
inventory=r.prepare_corpus_inventory(OUT/'actual_inventory');assert len(inventory['shards'])==1;shard=inventory['shards'][0];assert shard['WG']=='RAN4'and shard['sha256']==prep['FTS_input']['sha256'];assert sum(x['stored_rows']for x in shard['collections'])==537311
checks=[]
for method in ['Text2Cypher','Text2SQL']:
 t=runner.task(task['id'],method);messages=s.messages_for(t,method);u=json.loads(messages[1]['content']);assert u['selection_policy']==task['selection_policy'];assert u['question']==task['question_en'];assert [f['name']for f in u['output_format']['required_fields']]==['tdocNumber','summary'];assert 'literal_terms'not in u['selection_policy'];checks.append({'method':method,'same_selection_and_both_fields':True,'prompt_sha256':hashlib.sha256(s.canonical(messages).encode()).hexdigest()})
c=r.public_contract(task);assert c['selection_policy']==task['selection_policy'];assert [f['name']for f in c['required_fields']]==['tdocNumber','summary']
for f in ['gold','reference_query','native_rows']:
 rejected=False
 try:s.messages_for(dict(runner.task(task['id'],'Text2Cypher'),**{f:'FORBIDDEN'}),'Text2Cypher')
 except ValueError:rejected=True
 assert rejected,f
# Five-stage wiring uses only mocked empty retrieval and transport, never a provider/database connection.
class Caller:
 def __init__(self):self.calls=[]
 def call(self,ident,messages,max_tokens):
  self.calls.append({'id':ident,'messages':copy.deepcopy(messages),'max_tokens':max_tokens})
  content='{"query":"CONTROL GENERIC FOLLOWUP"}'if ident.endswith('_D_followup')else('{"query":"","abstain":true}'if ident.endswith(('Text2SQL','Text2Cypher'))else'{"records":[],"abstain":true,"complete":false}')
  return {'ok':True,'finish_reason':'stop','content':content,'usage':{},'provider':'MOCK_NO_NETWORK','model':'MOCK'}
caller=Caller()
for method in ['Text2Cypher','Text2SQL']:
 result=s.evaluate(runner.task(task['id'],method),method,caller,OUT/'mock_five_stages',sql_input=prep['SQL_input']);assert result['status']=='ABSTAIN'
r.prepare_corpus_inventory=lambda *args,**kwargs:inventory
r.retrieve=lambda *args,**kwargs:{'status':'MOCK_EMPTY_RETRIEVAL','context_candidate_truncated':False,'hits':[]}
r.contexts=lambda *args,**kwargs:([],{'document_selection_truncated':False,'characters':0,'utf8_bytes':0,'whitespace_terms':0})
for method in ['C','D']:
 result=r.evaluate(task,method,caller,OUT/'mock_five_stages');assert result['status']=='abstained'
assert len(caller.calls)==5
for call in caller.calls:
 text=call['messages'][1]['content']; payload=json.loads(text.split('\nSOURCE PASSAGES:\n',1)[0]);contract=payload.get('contract',payload.get('output_format'));assert payload['question']==task['question_en'];assert contract['required_fields']==task['required_fields'];assert (payload['selection_policy']if 'selection_policy'in payload else contract['selection_policy'])==task['selection_policy'];assert 'literal_terms'not in text
save('actual_mock_five_stage_messages.json',caller.calls)
# Synthetic complete-record controls use no real selected TDoc or summary values.
sys.path.insert(0,str(T/'scoring'));sc=load(T/'scoring/original_scorer.py','R4_twocolscorer');d=json.loads((H/'exact_DESC_two_field_source_definition_NOT_ADMITTED.json').read_text());truth=[{'tdocNumber':f'CONTROL-{i:02d}','summary':f'own synthetic summary {i}'}for i in range(10)]
fixtures=[('both_fields_exact',truth,True),('set_reverse_serialization',list(reversed(truth)),True),('ID_only',[{'tdocNumber':x['tdocNumber']}for x in truth],False),('summary_only',[{'summary':x['summary']}for x in truth],False),('swapped_pair_mapping',[dict(x,summary=truth[(i+1)%10]['summary'])for i,x in enumerate(truth)],False),('modified_summary',[dict(x,summary=x['summary']+' CHANGED')for x in truth],False),('numeric_ID',[dict(x,tdocNumber=i)for i,x in enumerate(truth)],False),('null_summary',[dict(x,summary=None)for x in truth],False),('missing_one_record',truth[:-1],False),('duplicate_one_record',truth[:-1]+[truth[0]],False),('empty',[],False),('one_partial_record',[truth[0]],False)]
scored=[]
for title,pred,exact in fixtures:
 v=sc.score(d,truth,pred,diagnostic=True);assert v['exact']is exact,(title,v)
 if title in ['ID_only','summary_only','swapped_pair_mapping','modified_summary','numeric_ID','null_summary','empty']:assert v['f1']==0,(title,v)
 if title=='missing_one_record':assert abs(v['f1']-18/19)<1e-12
 scored.append({'case':title,'expected_exact':exact,'score':v})
save('actual_synthetic_two_field_scoring_controls.json',{'status':'PASS','cases':scored,'synthetic_fields_only':True,'real_reference_rows_or_answers_read':False})
# Incomplete root config and a mismatched actual interpreter cannot silently run.
cfgpath=T/'root_configuration_TEMPLATE_INCOMPLETE_DO_NOT_EXECUTE.json';cfg=json.loads(cfgpath.read_text());assert runner.interpreter_preflight(cfg)['GraphDatabase_import_available'];blocked=False
try:runner.config(cfgpath)
except AssertionError:blocked=True
assert blocked
blocked=False
try:runner.interpreter_preflight(dict(cfg,execution_interpreter='/NOT_THE_CURRENT_PYTHON'))
except AssertionError:blocked=True
assert blocked
# Actual prospective definition hash, no public560 admission.
assert hashlib.sha256(runner.canonical({k:v for k,v in d.items()if k!='repair_sha256'}).encode()).hexdigest()==d['repair_sha256']==task['repair_sha256']
save('receipt.json',{'status':'PASS','actual_corpus_inventory_rows':537311,'actual_FTS_sha256':shard['sha256'],'structured_prompt_checks':checks,'common_selection_contract_all_five_mock_stages':True,'mock_transport_stages':len(caller.calls),'both_requested_fields_scoring_controls':len(scored),'forbidden_generator_fields_rejected':3,'incomplete_root_configuration_rejected':True,'mismatched_execution_interpreter_rejected':True,'exact_definition_digest_replayed':True,'paid_calls':0,'native_or_docker_calls':0,'source_SQL_and_FTS_reads':'mode=ro&immutable=1/query_only','human_expert_validation_n':0,'original560_admission_delta':0})
print(json.dumps({'status':'PASS','mock_transport_stages':5,'synthetic_two_field_controls':12,'actual_FTS_inventory':537311,'new_calls':0}))
