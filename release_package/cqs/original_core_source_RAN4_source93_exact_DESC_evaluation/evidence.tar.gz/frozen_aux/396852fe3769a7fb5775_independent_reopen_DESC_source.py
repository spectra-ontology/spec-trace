#!/usr/bin/env python3
"""Independently reopen register/own summary evidence for the DESC proposal.

No graph DB/native/API is used. The whole register and all source observations
are compared for the finite prefix; source-only bodies remain verification
evidence and are never corpus or model inputs.
"""
from pathlib import Path
from xml.etree import ElementTree as ET
from collections import Counter
import hashlib
import importlib.util
import io
import json
import re
import zipfile

import openpyxl

HERE=Path(__file__).resolve().parent
ROOT=next(p for p in HERE.parents if(p/'CLAUDE.md').exists())
LANE=HERE.parent.parent/'RAN2_RAN5/source_lane13'
PK=LANE/'RAN4_93_additive_source_snapshot_portable_v1/package_v2'
OLD=LANE/'RAN4_93_source_contract_rechallenge_v1'
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'


def sha(b):return hashlib.sha256(b).hexdigest()


def pin(p):return{'path':str(p.relative_to(ROOT)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}


def save(name,value):
    p=HERE/name
    with p.open('x')as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
    return pin(p)


def visible(e):
    if e.tag in(W+'del',W+'moveFrom'):return''
    if e.tag==W+'t':return e.text or''
    if e.tag==W+'tab':return'\t'
    if e.tag in(W+'br',W+'cr'):return'\n'
    return''.join(visible(c)for c in e)


def cell(e):return'\n'.join(visible(p)for p in e.findall(W+'p')).strip()


def folded(s):return' '.join(s.split())


def main():
    old=json.loads((OLD/'actual_original_DESC_first10_own_source_packet_v2.json').read_text())
    observations={r['tdocNumber']:r for r in map(json.loads,(PK/'source/all1858_observations.jsonl').read_text().splitlines())}
    retained=[json.loads(l)for l in(PK/'source/all3112_register.jsonl').read_text().splitlines()]
    archive=ROOT/'data/corpus/tsg/RAN/formal/meetings/RAN4/source/TSGR4_93/Report/R4-2000002.zip'
    with zipfile.ZipFile(archive)as z:
        assert z.testzip()is None
        workbook=z.read('TDoc_List_Meeting_RAN4#93.xlsx')
    book=openpyxl.load_workbook(io.BytesIO(workbook),read_only=True,data_only=True)
    sheet=book.worksheets[0];it=sheet.iter_rows(values_only=True);header=next(it)
    columns={v:i for i,v in enumerate(header)if v is not None}
    assert all(k in columns for k in('TDoc','TDoc Status','Type','CR','CR revision','Spec','Version'))
    rows=[]
    for rownum,cells in enumerate(it,2):
        if cells[columns['TDoc']]is None:continue
        rows.append({'tdocNumber':str(cells[columns['TDoc']]),'excel_row_1based':rownum,
            'properties':{k:''if cells[i]is None else str(cells[i])for k,i in columns.items()}})
    assert len(rows)==len(retained)==3112
    own={r['tdocNumber']:r for r in rows};assert len(own)==len(rows)
    # Verify the exact original fields used by the proposal for every row,
    # independent of XML's shared-string implementation and serialized hashes.
    keys=('Type','TDoc Status','Spec','CR','CR revision','Version','Is revision of','Revised to')
    for r in retained:
        fresh=own[r['tdocNumber']]
        assert fresh['excel_row_1based']==r['excel_row']
        for k in keys:
            assert fresh['properties'][k]==r['properties'][k],(r['tdocNumber'],k,fresh['properties'][k],r['properties'][k])
    eligible=[r for r in rows if r['properties']['Type']in('CR','draftCR','pCR')and r['properties']['TDoc Status']in('agreed','approved','endorsed')]
    def choose(rs,positive=False):
        if positive:rs=[r for r in rs if observations[r['tdocNumber']]['source_summary']is not None]
        return sorted((r['tdocNumber']for r in rs),reverse=True)[:10]
    variants={
        'existing_three_final_statuses_before_optional_projection':choose(eligible),
        'existing_three_statuses_original_nonnull_summary_predicate':choose(eligible,True),
        'recorded_agreed_only_before_optional_projection':choose([r for r in eligible if r['properties']['TDoc Status']=='agreed']),
        'recorded_agreed_only_original_nonnull_summary_predicate':choose([r for r in eligible if r['properties']['TDoc Status']=='agreed'],True),
        'strict_CR_agreed_only_original_nonnull_summary_predicate':choose([r for r in eligible if r['properties']['TDoc Status']=='agreed'and r['properties']['Type']=='CR'],True)}
    expected=[r['tdocNumber']for r in old]
    assert all(v==expected for v in variants.values())
    spec=importlib.util.spec_from_file_location('source93_original_CFB_reader',ROOT/'scripts/tsg/RAN/formal/common/doc_fields.py')
    df=importlib.util.module_from_spec(spec);spec.loader.exec_module(df)
    fields=[]
    for td in expected:
        obs=observations[td]
        original=ROOT/obs['archive']['path']
        assert sha(original.read_bytes())==obs['archive']['sha256']
        assert own[td]['properties']['TDoc Status']=='agreed'
        assert len(obs['source_fields'])==1
        field=obs['source_fields'][0]
        with zipfile.ZipFile(original)as z:
            assert z.testzip()is None
            member=z.read(field['member']['name'])
        assert sha(member)==field['member']['sha256']
        binary=None
        if field['access']=='original_DOCX':docx=member;derivative=None
        else:
            derivative=ROOT/field['derivative']['pin']['path']
            assert sha(derivative.read_bytes())==field['derivative']['pin']['sha256']
            assert(ROOT/field['derivative']['original_DOC']['path']).read_bytes()==member
            docx=derivative.read_bytes()
            stories,props=df._doc_read(member,props=True)
            live=props[0][1].replace('\ufdd0','')if props and props[0]is not None else None
            binary={'raw_main_story_sha256':sha(stories[0].encode()),
                'raw_folded_summary_present':folded(field['summary'])in folded(stories[0]),
                'visible_field_result_folded_summary_present':folded(field['summary'])in folded(df._visible(stories[0])),
                'live_deletion_story_available':live is not None,
                'live_folded_summary_present':None if live is None else folded(field['summary'])in folded(df._visible(live)),
                'original_CFB_strike_decoded':False}
            assert binary['visible_field_result_folded_summary_present']
        with zipfile.ZipFile(io.BytesIO(docx))as z:
            document=z.read('word/document.xml');styles=z.read('word/styles.xml')
        assert sha(document)==field['word_document_XML_sha256']
        assert sha(styles)==field['styles_XML_sha256']
        tree=ET.fromstring(document);style=ET.fromstring(styles)
        allparas=[visible(p)for p in tree.iter(W+'p')]
        assert td in'\n'.join(allparas[:30])
        matches=[]
        for ti,t in enumerate(tree.iter(W+'tbl')):
            for ri,row in enumerate(t.findall(W+'tr')):
                cs=[cell(c)for c in row.findall(W+'tc')]
                if cs and re.fullmatch(r'\s*summary\s+of\s+change\s*:\s*',cs[0],re.I):
                    matches.append({'table_index0':ti,'row_index0':ri,'cells':cs,
                        'row_xml':ET.tostring(row,encoding='unicode'),
                        'row_deleted_nodes':len(list(row.iter(W+'del'))),
                        'summary':'\n'.join(cs[1:]).strip()})
        assert len(matches)==1,(td,len(matches))
        m=matches[0];assert m['summary']==field['summary']==obs['source_summary']
        assert not m['row_deleted_nodes']
        positives=[{'tag':e.tag,'value':e.get(W+'val','true')}for root in(tree,style)
            for e in root.iter()if e.tag in(W+'strike',W+'dstrike',W+'vanish',W+'webHidden')
            and e.get(W+'val','true').lower()not in('0','false','off')]
        # Whole document may strike normative change blocks. Only the row and
        # style authority are relevant to the requested own summary value.
        relevant=[{'tag':e.tag,'value':e.get(W+'val','true')}for root in(ET.fromstring(m['row_xml']),style)
            for e in root.iter()if e.tag in(W+'strike',W+'dstrike',W+'vanish',W+'webHidden')
            and e.get(W+'val','true').lower()not in('0','false','off')]
        assert not relevant,(td,relevant)
        fields.append({'tdocNumber':td,'fresh_register':own[td],
            'archive':pin(original),'member_name':field['member']['name'],'member_sha256':sha(member),
            'access':field['access'],'existing_derivative':None if derivative is None else pin(derivative),
            'document_xml_sha256':sha(document),'styles_xml_sha256':sha(styles),
            'independently_found_own_summary_row':m,'own_summary_and_styles_positive_strike_hidden':relevant,
            'whole_document_positive_strike_hidden_count':len(positives),
            'original_binary_corroboration':binary})
    fieldpin=save('actual_independent_DESC10_original_register_and_own_summary_reopen.json',fields)
    result={'status':'ACTUAL_WHOLE_REGISTER_AND_BOUNDED_OWN_FIELD_SOURCE_PASS_WITH_DECLARED_CFB_LIMITS',
        'id':'RAN4_P4_CQ4-5','report_archive':pin(archive),
        'workbook_member':'TDoc_List_Meeting_RAN4#93.xlsx','workbook_member_sha256':sha(workbook),
        'all_original_register_records_independently_compared':len(rows),
        'all_source_CR_document_records':len(observations),'all_status_type_counts':[
            {'type':k[0],'status':k[1],'n':v}for k,v in sorted(Counter((r['properties']['Type'],r['properties']['TDoc Status'])for r in rows).items())],
        'all_generic_candidate_records':len(eligible),'prefix_counterpolicy_variants':variants,
        'all_variants_same_original_DESC10':True,'selected_all_recorded_agreed':True,
        'selected_all_own_summary_present':True,'selected_own_fields':fieldpin,
        'original_binary_limit':'Five source fields use exact-member existing CFB-to-DOCX derivatives. Original main-story field-result text corroborates all five; live deletion story is unavailable for two. Original CFB strike formatting is not decoded. There is no observed discrepant summary sentence; that assurance limit is not advertised as direct native binary rendering certification.',
        'source_graph_TTL_not_read_by_this_source_check':True,'native_SQL_API_calls':0,
        'public_mutations':0,'central_changes':0,'question_admissions':0,'expert_validation_n':0}
    rp=save('actual_independent_DESC10_source_reopen_receipt.json',result)
    print(json.dumps({'receipt':rp,'register_records':len(rows),'eligible':len(eligible),'summary_fields':len(fields),
        'all_prefix_variants_equal':True}),flush=True)


if __name__=='__main__':main()
