#!/usr/bin/env python3
"""Read-only equality of every source SQL node/property/edge and new corpus.

No question/query/selected prefix/answer is an input. This compares the complete
materialized source graph, not task answer quality or retrieval completeness.
"""
from pathlib import Path
import importlib.util
import json
import os
import resource
import sqlite3
import time

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent.parent/'root_RAN4_source93_full_materialized_v1/RAN4-source93.sqlite'
SOURCE_SHA='14aaa5bab66b89df9782525c9c6f5ba64dd9fcc5153bf3ae533eea786d858d0b'
FTS=HERE/'actual_corpus/ran4.sqlite3'


def ro(p):
    db=sqlite3.connect(p.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
    db.execute('PRAGMA query_only=ON');db.execute('PRAGMA cache_size=-32768')
    db.execute('PRAGMA temp_store=FILE');db.execute('PRAGMA mmap_size=0')
    return db


def main():
    resource.setrlimit(resource.RLIMIT_AS,(8*1024**3,8*1024**3))
    os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
    began=time.monotonic()
    spec=importlib.util.spec_from_file_location('source93_corpus_generic_comparison',HERE/'build_generic_graph_corpus.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    build=json.loads((HERE/'actual_corpus/build_receipt.json').read_text())
    reconstruction=json.loads((HERE/'actual_corpus/all_fact_reconstruction_receipt.json').read_text())
    assert reconstruction['status']=='PASS'
    assert m.sha(SOURCE)==SOURCE_SHA
    assert m.sha(FTS)==reconstruction['immutable_database_sha256']==build['database']['sha256']
    source,corpus=ro(SOURCE),ro(FTS)
    ids={};nodes=property_count=0
    for nid,iri,labels,props in source.execute('SELECT node_id,source_iri,labels_json,properties_json FROM _node_record'):
        assert nid not in ids and iri is not None
        ids[nid]=iri
        actual=corpus.execute('SELECT labels,properties FROM graph_nodes WHERE iri=?',(iri,)).fetchone()
        assert actual is not None,('Missing corpus node',iri)
        expected_labels,expected_props=sorted(json.loads(labels)),json.loads(props)
        assert m.canonical(json.loads(actual[0]))==m.canonical(expected_labels),('Node labels',iri)
        assert m.canonical(json.loads(actual[1]))==m.canonical(expected_props),('Node properties',iri)
        nodes+=1;property_count+=len(expected_props)
        if nodes%25000==0:print(m.canonical({'nodes_compared':nodes}),flush=True)
    assert nodes==len(set(ids.values()))==corpus.execute('SELECT count(*) FROM graph_nodes').fetchone()[0]==build['inventory']['nodes']
    triples=[(ids[s],r,ids[t])for s,r,t in source.execute('SELECT src_id,rel_type,dst_id FROM edge')]
    assert len(triples)==len(set(triples))==build['inventory']['edges']
    digest=m.digest(sorted(triples))
    assert digest==build['inventory']['directed_edges_sha256']
    source.close();corpus.close()
    assert m.sha(SOURCE)==SOURCE_SHA
    assert m.sha(FTS)==build['database']['sha256']
    receipt={'status':'PASS','source_SQLite_sha256':SOURCE_SHA,
        'whole_FTS_sha256':build['database']['sha256'],
        'all_node_labels_and_native_typed_properties_compared':nodes,
        'all_property_values_compared':property_count,
        'all_directed_edges_independently_compared':len(triples),
        'directed_edges_sha256':digest,
        'all_fact_reconstruction_receipt_sha256':m.sha(HERE/'actual_corpus/all_fact_reconstruction_receipt.json'),
        'all_source_and_corpus_inputs_unchanged':True,
        'question_query_answer_raw_cover_inputs':[],
        'comparison_is_not_retrieval_or_answer_completeness':True,
        'SQL_connection_policy':'Both source graph and corpus mode=ro&immutable=1, PRAGMA query_only=ON; no SQL writes',
        'API_native_calls':0,'public_or_operational_mutations':0,
        'AS_cap_bytes':8*1024**3,'CPU_count':1,
        'elapsed_seconds':time.monotonic()-began,
        'peak_RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    m.write_new(HERE/'actual_complete_SQLite_corpus_fact_equivalence.json',receipt)
    print(m.canonical(receipt),flush=True)


if __name__=='__main__':main()
