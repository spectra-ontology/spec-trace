#!/usr/bin/env python3
"""ROOT-ONLY execution proposal for a new, unpooled one-question cohort.

Preparation and mocked controls make no provider/database calls. A root-owned
configuration must pin actual native/SQL/semantic/control gates before freeze.
No historical predictions, model outputs, or scores are read or reused.
"""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse
import fcntl
import hashlib
import importlib.util
import json
import math
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / 'CLAUDE.md').exists())
B = HERE.parents[3]
METHODS = ('Text2Cypher', 'Text2SQL', 'C', 'D')
GIB = 1024**3


def utc():
    return datetime.now(timezone.utc).isoformat()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def pin(item):
    path = Path(item['path']).resolve(strict=True)
    assert sha(path) == item['sha256'], ('Pinned input changed', str(path))
    return path


def adapters():
    return (module(HERE / 'runtime/structured_adapter.py', 'RAN4_new_common_structured'),
            module(HERE / 'runtime/retrieval_adapter.py', 'RAN4_new_common_retrieval'))


def task(ident, method):
    tasks = read(HERE / 'public_tasks.json')
    result = next(row for row in tasks if row['id'] == ident)
    if method in METHODS[:2]:
        key = 'graph_schema' if method == 'Text2Cypher' else 'sql_schema'
        result[key] = read(HERE / (key + '.json'))
    return result


def config(path):
    result = read(path)
    assert result['cohort'] == 'RAN4_source93_exact_DESC_two_field_N1_common_fullgraph'
    assert result['original560_admission_delta'] == 0
    assert result['ready_for_root_review'] is True
    ids = {row['id'] for row in read(HERE / 'public_tasks.json')}
    assert set(result['cases']) == ids and len(ids) == 1
    assert type(result['budget_usd']) in (int, float) and math.isfinite(result['budget_usd']) and result['budget_usd'] > 0
    return result


def freeze_path(cfg):
    return Path(cfg['trial_directory']).parent / 'precall_freeze.json'


def verify_freeze(cfg, config_path):
    frozen = read(freeze_path(cfg))
    assert frozen['root_configuration_sha256'] == sha(config_path)
    for item in frozen['pinned_files']:
        pin(item)
    assert frozen['budget_usd'] == cfg['budget_usd']
    return frozen


def interpreter_preflight(cfg):
    import importlib.metadata
    import neo4j
    from neo4j import GraphDatabase, READ_ACCESS
    assert sys.executable == cfg['execution_interpreter'], 'Use the exact preflighted interpreter for every stage'
    return {'sys_executable':sys.executable,'neo4j_version':importlib.metadata.version('neo4j'),
            'neo4j_origin':neo4j.__file__,'GraphDatabase_import_available':GraphDatabase is not None,
            'READ_ACCESS_import_available':READ_ACCESS is not None,'native_or_network_calls':0}


def freeze(cfg, config_path):
    interpreter_receipt = interpreter_preflight(cfg)
    out = freeze_path(cfg)
    assert not out.exists() and not Path(cfg['trial_directory']).exists()
    files = [Path(__file__), Path(config_path), HERE / 'public_tasks.json', HERE / 'graph_schema.json', HERE / 'sql_schema.json',
             HERE / 'prospective_preparation.json', HERE / 'actual_pre_call_mock_controls/receipt.json']
    assert read(files[-1])['status'] == 'PASS'
    files.extend(sorted((HERE / 'runtime').glob('*.py')))
    for key in ('TTL_input', 'SQL_input', 'FTS_input'):
        files.append(pin(cfg[key]))
    prep = read(HERE / 'prospective_preparation.json')
    for key in ('TTL_input', 'SQL_input', 'FTS_input'):
        assert prep[key]['sha256'] == cfg[key]['sha256']
    physical = module(HERE / 'runtime/physical_schema.py', 'RAN4_freeze_physical_DDL')
    sql_receipt = physical.validate(read(HERE / 'sql_schema.json'), cfg['SQL_input']['path'], cfg['SQL_input']['sha256'])
    required_gate_classes = {'whole_native_reference_capture', 'whole_independent_SQL_agreement',
                             'independent_second_seven_unit_semantics', 'generic_and_boundary_scoring_controls',
                             'whole_source_and_FTS_equivalence'}
    assert set(cfg['gate_receipts']) == required_gate_classes, 'All actual independent gates must be pinned by root'
    for kind, item in cfg['gate_receipts'].items():
        path = pin(item)
        value = read(path)
        assert item['assertions'], 'Each gate requires explicit result assertions'
        for assertion in item['assertions']:
            actual = value
            for key in assertion['key_path']:
                actual = actual[key]
            assert actual == assertion['equals'], (kind, assertion)
        files.append(path)
    for ident, case in cfg['cases'].items():
        definition_path = pin(case['definition'])
        d = read(definition_path)
        public = task(ident, 'C')
        assert d['id'] == ident and d['question_en'] == public['question_en']
        # This separate source contract hashes its complete prospective definition
        # excluding only the self hash; the original560 schema is not silently reused.
        assert hashlib.sha256(canonical({k: v for k, v in d.items() if k != 'repair_sha256'}).encode()).hexdigest() == public['repair_sha256']
        assert d['repair_sha256'] == public['repair_sha256']
        assert hashlib.sha256(d['question_en'].encode()).hexdigest() == d['original_question_sha256']
        assert d['required_fields'] == [
            {'name':'tdocNumber','type':'string','nullable':False,'source_column_or_expression':'d.tdocNumber'},
            {'name':'summary','type':'string','nullable':False,'source_column_or_expression':'s.sourceSummary'}]
        assert d['collection'] == {'kind':'set'} and d['cardinality_policy'] == {'mode':'exact','value':10}
        records_path = pin(case['actual_reference_rows'])
        # Raw source-derived evidence must not substitute for actual native capture.
        assert case['actual_reference_rows']['provenance'] == 'actual_owned_native_capture'
        files.extend([definition_path, records_path])
    files.extend(pin(item) for item in cfg['additional_evidence_files'])
    files.extend(pin(item) for item in cfg['scoring_files'])
    files.append(pin(cfg['read_query_guard']))
    files.append(pin(cfg['native_manifest']))
    files = sorted(set(path.resolve(strict=True) for path in files))
    save(out, {'status': 'FROZEN_BEFORE_ALL_NEW_PAID_CALLS', 'utc': utc(),
               'cohort': cfg['cohort'], 'original560_admission_delta': 0,
               'root_configuration_sha256': sha(config_path), 'cases': list(cfg['cases']),
               'N_per_method': 1, 'methods': list(METHODS), 'expected_request_stages': 5,
               'budget_usd': cfg['budget_usd'], 'physical_SQL_interface_gate': sql_receipt, 'execution_interpreter_preflight':interpreter_receipt,
               'shared_underlying_facts_do_not_establish_equal_exposure_or_causal_effect': True,
               'human_expert_validation_n': 0, 'quality_retries': 0,
               'transport_retry': 'At most one identical network/429/5xx retry; retain all failures',
               'pinned_files': [{'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size} for path in files]})
    print(json.dumps({'status': 'FROZEN', 'sha256': sha(out), 'pinned_files': len(files)}))


def calls(cfg, config_path):
    interpreter_preflight(cfg)
    verify_freeze(cfg, config_path)
    trial = Path(cfg['trial_directory'])
    assert not trial.exists(), 'First trial only; never regenerate scientific outputs'
    trial.mkdir(parents=True)
    structured, retrieval = adapters()
    retrieval.prepare_corpus_inventory(trial)
    sys.path.insert(0, str(ROOT / 'scripts/common/common'))
    import credentials
    transport = module(HERE / 'runtime/openrouter_client.py', 'RAN4_new_common_transport')
    caller = transport.OpenRouterCaller(trial, api_key=credentials.secret('OPENROUTER_API_KEY'), budget_usd=cfg['budget_usd'])
    results = {}
    def work(ident, method):
        public = task(ident, method)
        if method in METHODS[:2]:
            return structured.evaluate(public, method, caller, trial, sql_input=cfg['SQL_input'])
        return retrieval.evaluate(public, method, caller, trial)
    with ThreadPoolExecutor(max_workers=4) as pool:
        jobs = {pool.submit(work, ident, method): (ident, method) for ident in cfg['cases'] for method in METHODS}
        for future in as_completed(jobs):
            ident, method = jobs[future]
            try:
                record = future.result()
            except Exception as exc:
                record = {'id': ident, 'method': method, 'status': 'ADAPTER_EXCEPTION',
                          'records': [], 'abstain': True, 'error_class': type(exc).__name__}
                save(trial / 'preserved_adapter_exceptions' / (ident + '_' + method + '.json'), record)
            results.setdefault(ident, {})[method] = record
            print(json.dumps({'id': ident, 'method': method, 'status': record['status']}), flush=True)
    save(trial / 'generated_before_execution.json', {'utc': utc(), 'freeze_sha256': sha(freeze_path(cfg)),
          'results': results, 'usage': caller.summary_unlocked(), 'database_execution_during_generation': False})
    verify_freeze(cfg, config_path)


def command(*args):
    return subprocess.check_output(list(args), text=True).strip()


def host_available():
    linux = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))) * 1024
    windows = int(command('powershell.exe', '-NoProfile', '-NonInteractive', '-Command', '(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory')) * 1024
    return {'Linux_available_bytes': linux, 'Windows_available_bytes': windows}


def execute_cypher(query, cfg, event_path):
    """Run exact generated query only in the root-configured already loaded clone."""
    from neo4j import GraphDatabase, READ_ACCESS
    guard = module(pin(cfg['read_query_guard']), 'RAN4_new_read_query_guard')
    stages = module(HERE / 'runtime/container_stage_guard.py', 'RAN4_new_container_stage_guard')
    target = cfg['native_container']
    assert target['name'].startswith('kdd-db-source-ran4-')
    assert target['source_sha256'] == cfg['TTL_input']['sha256']
    clean = guard.screen_query(query)
    assert clean == query, 'Generated queries are never rewritten'
    def inspect(running):
        value = json.loads(command('docker', 'inspect', target['name']))[0]
        stages.validate(value, name=target['name'], port=target['port'], run_uuid=target['run_uuid'],
                        source_sha256=target['source_sha256'], image_id=target['image_id'], expected_running=running)
        return value
    began = time.monotonic()
    rows, columns, size = [], [], 0
    result = {'status': 'ERROR', 'complete': False, 'rows': [], 'rollback_completed': False}
    events = []
    with Path(cfg['native_lock_path']).open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        available = host_available()
        assert min(available.values()) >= 26 * GIB, available
        assert not any(name.startswith('kdd-db-') for name in command('docker', 'ps', '--format', '{{.Names}}').splitlines())
        inspect(False)
        events.append({'stage': 'owned_stopped_before_start', 'available': available})
        started = False
        try:
            command('docker', 'start', target['name'])
            started = True
            inspect(True)
            events.append({'stage': 'owned_running_after_start'})
            driver = GraphDatabase.driver(target['bolt'], auth=None, connection_timeout=5, max_transaction_retry_time=0)
            try:
                deadline = time.monotonic() + 90
                while True:
                    assert min(host_available().values()) >= 16 * GIB
                    try:
                        driver.verify_connectivity()
                        break
                    except Exception:
                        if time.monotonic() > deadline:
                            raise
                        time.sleep(1)
                with driver.session(database='neo4j', default_access_mode=READ_ACCESS, fetch_size=100) as session:
                    tx = session.begin_transaction(timeout=60)
                    try:
                        nodes = tx.run('MATCH (n) RETURN count(n) AS n').single()['n']
                        edges = tx.run('MATCH ()-[r]->() RETURN count(r) AS n').single()['n']
                        assert (nodes, edges) == (346617, 1600412)
                        plan = tx.run('EXPLAIN ' + clean).consume()
                        guard.require_read_plan(plan)
                        cur = tx.run(clean)
                        columns = list(cur.keys())
                        assert len(columns) == len(set(columns))
                        status, last_memory_check = 'OK', time.monotonic()
                        for row in cur:
                            if time.monotonic() - last_memory_check >= 10:
                                assert min(host_available().values()) >= 16 * GIB
                                last_memory_check = time.monotonic()
                            record = row.data()
                            added = len(canonical(record).encode()) + 1
                            if len(rows) == 100000: status = 'ROW_CAP'; break
                            if size + added > 256 * 1024 * 1024: status = 'BYTE_CAP'; break
                            rows.append(record)
                            size += added
                        if status == 'OK':
                            summary = cur.consume()
                            assert summary.query_type == 'r' and not summary.counters.contains_updates and not summary.counters.contains_system_updates
                        result.update(status=status, complete=status == 'OK', truncated=status != 'OK',
                                      inventory_before={'nodes': nodes, 'relationships': edges})
                    finally:
                        tx.rollback()
                        result['rollback_completed'] = True
            finally:
                driver.close()
        except Exception as exc:
            result.update(status='ERROR', complete=False, error_class=type(exc).__name__)
        finally:
            if started:
                # docker stop is attempted even if running-stage inspection fails.
                try:
                    inspect(True)
                finally:
                    command('docker', 'stop', '--time', '20', target['name'])
                inspect(False)
                events.append({'stage': 'owned_stopped_after_execution'})
            save(event_path, {'utc': utc(), 'events': events, 'result_status': result['status']})
    result.update(rows=rows, columns=columns, retained_json_bytes=size,
                  elapsed_s=time.monotonic() - began, source_variant_only=True)
    return result


def execute(cfg, config_path):
    interpreter_preflight(cfg)
    verify_freeze(cfg, config_path)
    trial = Path(cfg['trial_directory'])
    original = trial / 'generated_before_execution.json'
    generated = read(original)
    assert not (trial / 'executed_predictions.json').exists()
    save(trial / 'before_execution_queries_frozen.json', {'utc': utc(), 'generated_record_sha256': sha(original),
          'queries': {ident: {method: records[method].get('query_sha256') for method in METHODS[:2]}
                      for ident, records in generated['results'].items()}})
    structured, _ = adapters()
    results = generated['results']
    for ident, methods in results.items():
        for method in METHODS[:2]:
            record = methods[method]
            if record['status'] != 'QUERY_READY': continue
            query = record['generated_query']
            assert hashlib.sha256(query.encode()).hexdigest() == record['query_sha256']
            try:
                outcome = (execute_cypher(query, cfg, trial / 'native_stage_events' / (ident + '.json'))
                           if method == 'Text2Cypher' else structured.run_sql_query(
                               cfg['SQL_input']['path'], query, task(ident, method)['required_fields'],
                               expected_db_sha=cfg['SQL_input']['sha256']))
            except Exception as exc:
                outcome = {'status': 'ERROR', 'complete': False, 'rows': [], 'error_class': type(exc).__name__}
            record.update(execution=outcome, records=outcome['rows'] if outcome['complete'] else [],
                          abstain=not outcome['complete'], status='OK' if outcome['complete'] else 'EXECUTION_' + outcome['status'])
    save(trial / 'executed_predictions.json', {'utc': utc(), 'freeze_sha256': sha(freeze_path(cfg)), 'results': results})
    verify_freeze(cfg, config_path)


def score(cfg, config_path):
    verify_freeze(cfg, config_path)
    trial = Path(cfg['trial_directory'])
    results = read(trial / 'executed_predictions.json')['results']
    sys.path.insert(0, str(HERE / 'scoring'))
    scorer = module(HERE / 'scoring/original_scorer.py', 'RAN4_new_prospective_scoring')
    details = []
    for ident, case in cfg['cases'].items():
        definition = read(pin(case['definition']))
        native = [json.loads(line) for line in pin(case['actual_reference_rows']).read_text().splitlines() if line]
        projected = [{field['name']: row[field['name']] for field in definition['required_fields']} for row in native]
        groups = (scorer.make_order_groups(definition, native, projected)
                  if definition['collection']['kind'] == 'top_k_boundary_ties' else None)
        for method in METHODS:
            outcome = results[ident][method]
            valid = outcome['status'] in {'OK', 'ok', 'partial'} and not outcome.get('abstain', False)
            predicted = outcome.get('records', []) if valid else []
            value = scorer.score(definition, projected, predicted, diagnostic=True, order_groups=groups)
            if not valid: assert value['f1'] == 0 and not value['exact']
            details.append({'id': ident, 'method': method, 'status': outcome['status'],
                            'valid_answer': valid, 'score': value, 'self_reported_complete': outcome.get('self_reported_complete'),
                            'abstention': bool(outcome.get('abstain')), 'failure_remains_in_denominator': True})
    summary = {'status': 'ACTUAL_SEPARATE_SOURCE_COHORT_NOT_ORIGINAL_ADMISSION', 'utc': utc(),
               'cohort': cfg['cohort'], 'N_per_method': 1, 'expected_total_method_items': 4,
               'original560_admission_delta': 0, 'results': details, 'usage': read(trial / 'usage.json'),
               'macro': {method: {'N': 1, 'f1': sum(row['score']['f1'] for row in details if row['method'] == method) / 1,
                                  'exact': sum(bool(row['score']['exact']) for row in details if row['method'] == method)} for method in METHODS},
               'human_expert_validation_n': 0,
               'limits': 'Final documentary WG acceptance plus original own Summary of change; not TSG approval, physical-week attendance, normative incorporation, or a whole-population rendered-binary certification. Common facts do not prove equal exposure, complete retrieval, equal cost, or causal superiority. Do not pool with historical cohorts.'}
    save(trial / 'actual_results_summary.json', summary)
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('freeze', 'calls', 'execute', 'score'))
    parser.add_argument('--root-config', type=Path, required=True)
    args = parser.parse_args()
    cfg = config(args.root_config)
    globals()[args.phase](cfg, args.root_config)
