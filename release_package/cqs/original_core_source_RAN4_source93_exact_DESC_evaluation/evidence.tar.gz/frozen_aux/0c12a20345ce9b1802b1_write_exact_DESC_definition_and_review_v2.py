#!/usr/bin/env python3
"""Write a prospective two-field DESC source variant and source-only review.

The ASC package, frozen graph, legacy truth and all existing failures remain
unchanged. This review does not admit an original question or claim evaluation.
"""
from pathlib import Path
import hashlib
import importlib.util
import json

HERE=Path(__file__).resolve().parent
ROOT=next(p for p in HERE.parents if(p/'CLAUDE.md').exists())
O=HERE.parent.parent
LANE=O/'RAN2_RAN5/source_lane13'
AUTH=LANE/'RAN4_93_default_and_approved_record_authority'
PK=LANE/'RAN4_93_additive_source_snapshot_portable_v1/package_v2'
PUBLIC=ROOT.parent/'spectra-public/spec-trace/release_package/cqs/original_core_source_enriched_repair'


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)


def save(n,x):
    p=HERE/n
    data=json.dumps(x,ensure_ascii=False,indent=2)+'\n'
    if p.exists():assert p.read_text()==data, 'Existing output differs: '+str(p)
    else:
        with p.open('x')as f:f.write(data)
    return {'path':n,'sha256':sha(p),'bytes':p.stat().st_size}


def main():
    originalpath=ROOT.parent/'spectra-public/spec-trace/release_package/cqs/original_core_repair/provenance/original_benchmark.jsonl'
    original=next(r for r in map(json.loads,originalpath.read_text().splitlines())if r['id']=='RAN4_P4_CQ4-5')
    assert original['question_en']==(PK/'query/original_English.txt').read_text()
    assert original['cypher']==(PK/'query/original_query.cypher').read_text()
    source=json.loads((HERE/'actual_independent_DESC10_source_reopen_receipt.json').read_text())
    assert source['all_variants_same_original_DESC10']
    assert source['all_original_register_records_independently_compared']==3112
    assert sha(PUBLIC/'criteria.json')=='bfefc447de02b451da33e0c85afb2708cf6ca7a201fedf07ec4d5b984d492fa4'
    query="""MATCH (d:SourceMeetingDocument)-[:SOURCE_HAS_OWN_SUMMARY]->(s:SourceOwnCRSummary)
WHERE d.meetingNumberInt = 93
  AND d.sourceType IN ['CR','draftCR','pCR']
  AND d.finalDocumentaryStatus IN ['agreed','approved','endorsed']
  AND s.sourceSummary IS NOT NULL
RETURN d.tdocNumber AS tdocNumber, s.sourceSummary AS summary
ORDER BY d.tdocNumber DESC LIMIT 10"""
    qp=HERE/'separate_source_exact_DESC_query.cypher'
    if qp.exists():assert qp.read_text()==query
    else:
        with qp.open('x')as f:f.write(query)
    definition={
        'id':original['id'],'question_en':original['question_en'],
        'original_question_sha256':hashlib.sha256(original['question_en'].encode()).hexdigest(),
        'original_query':original['cypher'],'reference_query':query,
        'original_query_sha256':hashlib.sha256(original['cypher'].encode()).hexdigest(),
        'reference_query_sha256':hashlib.sha256(query.encode()).hexdigest(),
        'required_fields':[{'name':'tdocNumber','type':'string','nullable':False,'source_column_or_expression':'d.tdocNumber'},
            {'name':'summary','type':'string','nullable':False,'source_column_or_expression':'s.sourceSummary'}],
        'collection':{'kind':'set'},'cardinality_policy':{'mode':'exact','value':10},
        'repair_class':'query_and_scorer','data_repair_class':'separate_additive_documentary_source_snapshot',
        'criteria_sha256':sha(PUBLIC/'criteria.json'),
        'reference_graph_kind':'separate_full_RAN4_source93_snapshot',
        'new_snapshot_sha256':'d2a66b1f2ecd60301a39b2102a0145aa6e4f2791cd5b5a2726b2185b612ffc8f',
        'new_SQLite_sha256':'14aaa5bab66b89df9782525c9c6f5ba64dd9fcc5153bf3ae533eea786d858d0b',
        'source_variant_population':'All3112 own original final meeting93 register identities and1858 CR/draftCR/pCR observations; source-first own-summary facts are additive, not overrides of original CR fields.',
        'approval_scope':'Final documentary WG acceptance at the recorded meeting, supported by the original own TDoc Status field. No physical-week event, TSG approval, normative incorporation or equivalence of all statuses in every setting is asserted. Every requested selected10 is independently recorded agreed; all alternative relevant status/type subsets select the same10.',
        'selection_policy':'Preserve specific authored tdocNumber DESC LIMIT10 over generic group ASC default. Preserve original explicit nonnull summary predicate against its authentic source field. All3112 identities and1858 observations establish a complete finite source selection in this snapshot.',
        'summary_policy':'Both TDoc identity and literal own CR-form Summary of change are mandatory answer fields. No ID-only projection, summary deduplication or generated paraphrase supplies reference truth.',
        'legacy_CFB_assurance_limit':source['original_binary_limit'],
        'source_proof_sha256':sha(HERE/'actual_independent_DESC10_source_reopen_receipt.json'),
        'old_ASC_package_manifest_sha256':sha(PK/'manifest.json'),
        'old_ASC_package_unchanged':True,'original560_pass_increment':0,
        'status':'LOCAL_PROSPECTIVE_SEPARATE_SOURCE_VARIANT_NOT_ADMITTED',
        'expert_validation_n':0,'human_author_review_completed':False,
        'new_API_native_SQL_calls':0,'public_mutations':0,
        'integration_gates':['Independent second exact-DESC two-field semantic judgment',
            'Root exact-DESC isolated native and independent typed SQL, source fields and complete-prefix equality',
            'Two-field controls, schema/DDL and common whole-graph source input replay',
            'Pre-call protocol freeze and authorized first attempts; report separately from prior cohorts and original560']}
    definition['repair_sha256']=hashlib.sha256(canonical(definition).encode()).hexdigest()
    dp=save('exact_DESC_two_field_source_definition_NOT_ADMITTED.json',definition)
    ev=[]
    def unit(name,quote,clauses,finding,counter):
        assert quote in original['question_en'],quote
        ev.append({'unit':name,'status':'pass','original_quote':quote,'query_clauses':clauses,
            'finding':finding,'counterinterpretation_and_limit':counter})
    unit('requested answer roles and fields','change summaries of CRs',
        ['RETURN d.tdocNumber AS tdocNumber, s.sourceSummary AS summary',
         'required_fields=[tdocNumber:string nonnull,summary:string nonnull]'],
        'A CR identity and its substantive own change summary are both requested. Original particular query also returns both. Source Summary of change is the literal authored CR-form value, distinct from a TDoc abstract, title, generated explanation or reason. All10 source selected records have unique nonempty own summaries and unique TDoc identities; no field is dropped as incidental.',
        'An identifier-only answer is insufficient here. Ten different IDs may share text in another prefix; identity/text pairs remain records rather than deduplicated summary strings. The former ASC summary-only/multiset contract is preserved and is a different contract.')
    unit('population and source context','at meeting #93',
        ['d.meetingNumberInt = 93',"d.sourceType IN ['CR','draftCR','pCR']"],
        'Original WG=RAN4 and Phase4 meeting-scoped CR metadata context are retained. The actual official original meeting93 report ZIP includes its3112-row TDoc register. Independently read all3112 original entries and all1858 CR-class observations; no selected-ID whitelist determines graph facts. The complete source snapshot adds generic record/own-summary nodes while preserving the old graph.',
        'This is the fixed final documentary meeting packet, not all external CRs or proof of physical submission/approval in that calendar week. Draft/pCR classes are explicit original CR-source classes; all selected10 are strict Type=CR, so this boundary does not depend on treating a draft as a final CR.')
    unit('filters and relationship meaning','CRs approved',
        ["d.finalDocumentaryStatus IN ['agreed','approved','endorsed']",'d.meetingNumberInt = 93'],
        'Original Phase1 designL206 explicitly answers approved/agreed-at-meeting TDocs with Meeting and TDoc Status;L705 maps status to the recorded meeting decision. Source agreed is therefore direct documentary acceptance evidence, without inventing a universal need for a second own-report paragraph. The whole source prefix is invariant between the prior three-status convention, agreed-only and strict CR-agreed-only. Every selected10 is actually agreed, including6202. Its Not provided to RAN86 secretary remark concerns TSG forwarding, not a negative WG agreement record.',
        'Original particular query uses Agreement REFERENCES as a surrogate, whereas this separate source repair uses the original direct recorded outcome. Citation alone is not approval. Original status taxonomy distinguishes agreed/endorsed/approved; they are not universally interchangeable. The requested10 is robust across those counterpolicies, but no entire1027-record universal acceptance equivalence, TSG approval, normative incorporation or physical-week event is claimed.')
    unit('counting unit and join multiplicity','summaries of CRs',
        ['SourceMeetingDocument -> SOURCE_HAS_OWN_SUMMARY -> SourceOwnCRSummary',
         'required record=(tdocNumber,summary);collection={kind:set}'],
        'The source identity is one original register TDoc, with a unique own-summary record only when generic parsing yielded one value. All3112 original IDs are unique; all10 selected own records were independently reopened and each has exactly one matching Summary of change row. Unique identity prevents accidental collapse even when summaries repeat. Original query selection and all2 field values still need root native/SQL verification.',
        'This is not a claim that every1343 whole-population summary has exhaustive formatting certification. We directly certify the bounded10 source fields and preserve132 missing archives and unsupported observations outside selection. Set answer comparison does not authorize dropping either required field.')
    unit('cardinality and completeness','List the change summaries',
        ['s.sourceSummary IS NOT NULL','ORDER BY d.tdocNumber DESC LIMIT 10',
         'cardinality_policy={mode:exact,value:10}'],
        'Specific authored LIMIT10 and its explicit nonnull summary filter are retained. Existing source ASC package chose identities before optional summary; that is preserved as a separate older route. Complete source3112/1858 comparison demonstrates that positive-summary filtering before selection, or selecting before optional projection, gives the exact same requested DESC10 here: all ten authentic fields are available. No nulls were omitted posthoc to change this observed prefix.',
        'If a selected summary were missing, the authored nonnull policy and optional-before-limit policy would differ; those are different tasks. This new reference deliberately follows the original explicit predicate, not a generic rule that complete records can always be selected to make an answer easy. No exhaustive-all-summaries reading is claimed.')
    unit('ordering and ties when requested','List',
        ['ORDER BY d.tdocNumber DESC LIMIT 10','collection={kind:set}'],
        'The exact particular original benchmark query specifies tdocNumber DESC and LIMIT10. It takes priority over the Phase4 generic Tdoc ASC default for this authored instance. The two bounds have entirely different membership and are not declared equivalent. Unique TDoc keys remove boundary ties. English asks for summaries, not ranked answer serialization; order-insensitive comparison of the exact selected identity/summary pairs preserves selection.',
        'DESC lexical identity is a benchmark selection convention, not proven upload/physical event chronology. The earlier ASC package/review remains byte-identical and its previous native run cannot substitute for this new exact-DESC execution.')
    unit('unverified additional inputs or external interpretation','meeting-scoped change review',
        ['separate source snapshot pinned independently from original frozen graph',
         'common full-graph corpus for all methods; raw source/prefix/gold verification excluded from prompts'],
        'This is an explicit separate additive source experiment. Generic whole-graph serialization uses only the pinned full346617-node/1600412-edge TTL, including all old facts and every new source record; no question, query, target ID, selected10 or raw-cover fixture supplies corpus facts. Source truth comes from own register/CR forms, not model answers. Independently reopened all ten own summaries, five direct OOXML and five exact-member legacy derivatives; raw CFB visible field-result text corroborates all five.',
        'Original CFB strike formatting is not decoded and live deletion properties are unavailable for two; this declared assurance limit is not fabricated contrary text or proof of native binary rendering. Independent second review, native/SQL, corpus reconstruction/SQL equality, scorer/schema controls and pre-call freeze remain gates. Original560 increment, human/expert, API and public mutation are zero.')
    criteria=json.loads((PUBLIC/'criteria.json').read_text())
    evidence=[HERE/'actual_independent_DESC10_source_reopen_receipt.json',
        HERE/'actual_independent_DESC10_original_register_and_own_summary_reopen.json',
        AUTH/'phase1_design_actual_index.md',AUTH/'phase4_design_actual_index.md',
        LANE/'RAN4_93_recorded_status_gate_reassessment_v1/actual_recorded_status_and_summary_format_reassessment.json',
        O/'root_RAN4_source93_full_materialized_v1/actual_root_materialization_receipt.json',
        PK/'manifest.json',PUBLIC/'criteria.json']
    review={'id':definition['id'],'status':'pass','semantic_gate_only':True,
        'repair_sha256':definition['repair_sha256'],'criteria_sha256':definition['criteria_sha256'],
        'original_question_sha256':definition['original_question_sha256'],
        'original_query_sha256':definition['original_query_sha256'],'question_en':definition['question_en'],
        'definition_file_sha256':dp['sha256'],'semantic_evidence':ev,
        'reviewer_kind':'Independent exact-DESC source-meaning AI review by /root/priority71_fast_closure; nonblind, not human/expert',
        'independent_source_evidence':[{'path':str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p),'sha256':sha(p)}for p in evidence],
        'nonblind_exposure':'Prior source93 ASC packet, DESC fields, legacy source failures and root interpretation were read. Fresh register and ten own source fields were independently reopened. No paid model outcome or answer-based policy selection was used.',
        'new_source_reopen_n':{'whole_register':3112,'own_summary_fields':10},
        'secondary_AI_review_in_this_file':0,'expert_validation_n':0,
        'human_author_review_completed':False,'original560_pass_increment':0,
        'new_API_native_SQL_calls':0,'public_mutations':0,'question_admissions':0,
        'remaining_execution_gates':definition['integration_gates']}
    spec=importlib.util.spec_from_file_location('source93exact_review_schema',PUBLIC/'review_schema.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    m.check_pass(review,definition['question_en'],criteria['semantic_units'],
        criteria_sha=definition['criteria_sha256'],identity_key='repair_sha256',identity_sha=definition['repair_sha256'])
    rp=save('independent_exact_DESC_two_field_seven_unit_review.json',review)
    save('actual_exact_DESC_review_schema_check.json',{'status':'PASS_SOURCE_SEMANTICS_ONLY',
        'definition':dp,'review':rp,'repair_sha256':definition['repair_sha256'],
        'criteria_sha256':definition['criteria_sha256'],'review_schema_sha256':sha(PUBLIC/'review_schema.py'),
        'API_native_SQL_calls':0,'question_admissions':0,'expert_validation_n':0})
    print(json.dumps({'definition':dp,'review':rp,'repair_sha256':definition['repair_sha256']},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
