#!/usr/bin/env python3
"""Capture the prospective two-field DESC source query on the pinned whole clone.

No model call, graph loading, query repair, original admission, or prior-result
replacement occurs here. The prior ASC capture and graph inventory stay intact.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import fcntl
import hashlib
import importlib.util
import json
import sqlite3
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE = HERE.parent.parent
WORK = HERE / 'root_RAN4_source93_exact_DESC_native_v2'
PREVIOUS = HERE / 'root_RAN4_source93_public_parser_native_v1'
DEFINITION = HERE / 'priority71_fast_closure/RAN4_93_exact_DESC_common_source_v1/exact_DESC_two_field_source_definition_NOT_ADMITTED.json'
STAGE_GUARD = HERE / 'root_RAN1_common3176_prepared_evaluation_v1/runtime/container_stage_guard.py'
GIB = 1024**3


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda: f.read(1024*1024), b''):
            h.update(part)
    return h.hexdigest()


def save(path, value):
    temp = path.with_suffix(path.suffix + '.pending')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temp.replace(path)


def command(*args):
    return subprocess.check_output(list(args), text=True).strip()


def bag(rows):
    return Counter(json.dumps(x, ensure_ascii=False, sort_keys=True) for x in rows)


def main():
    assert not WORK.exists(), 'Preserve prior attempts; use a new audit directory'
    WORK.mkdir()
    assert sha(PREVIOUS/'actual_native_manifest.json') == 'e9895e952541bbf1dc2785f44ffda11f2cda255f2738391d952f4b01f8312798'
    previous = json.loads((PREVIOUS/'actual_native_manifest.json').read_text())
    assert sha(DEFINITION) == '04fefe44e397dca2c0a9fea42deb1a3ea893a60168c7ad1e10392d427d9af42f'
    definition = json.loads(DEFINITION.read_text())
    source, db = Path(previous['source']['path']), Path(previous['db']['path'])
    assert sha(source) == definition['new_snapshot_sha256'] == previous['source']['sha256']
    assert sha(db) == definition['new_SQLite_sha256'] == previous['db']['sha256']
    query = definition['reference_query']
    assert hashlib.sha256(query.encode()).hexdigest() == definition['reference_query_sha256']
    assert query.endswith('ORDER BY d.tdocNumber DESC LIMIT 10')
    definition_sha = sha(DEFINITION)
    sql = """SELECT d.tdocNumber AS tdocNumber, s.sourceSummary AS summary
FROM SourceMeetingDocument AS d
JOIN rel_SOURCE_HAS_OWN_SUMMARY AS r ON r.src_id=d.node_id
JOIN SourceOwnCRSummary AS s ON s.node_id=r.dst_id
WHERE d.meetingNumberInt=93 AND d.sourceType IN ('CR','draftCR','pCR')
AND d.finalDocumentaryStatus IN ('agreed','approved','endorsed')
AND s.sourceSummary IS NOT NULL
ORDER BY d.tdocNumber DESC LIMIT 10"""
    queries = {'selected': query, 'whole_eligible_pool': query.removesuffix(' LIMIT 10')}
    sql_queries = {'selected': sql, 'whole_eligible_pool': sql.removesuffix(' LIMIT 10')}
    expected = {}
    con = sqlite3.connect(db.resolve().as_uri()+'?mode=ro&immutable=1', uri=True)
    try:
        con.execute('PRAGMA query_only=ON')
        for key, statement in sql_queries.items():
            cursor = con.execute(statement)
            assert [x[0] for x in cursor.description] == ['tdocNumber', 'summary']
            expected[key] = [list(row) for row in cursor]
            assert all(len(row) == 2 and all(isinstance(v, str) for v in row) for row in expected[key])
    finally:
        con.close()
    assert len(expected['selected']) == len({x[0] for x in expected['selected']}) == 10
    assert len(expected['whole_eligible_pool']) == 808
    save(WORK/'actual_immutable_SQL_two_field_DESC_reference.json',
         {'queries': sql_queries, 'rows': expected, 'db_sha256': sha(db),
          'definition_sha256': definition_sha, 'query_implementation': 'Independent direct physical-table SQL; immutable read only'})
    # Test the real driver import in the same interpreter used by the native run.
    import neo4j
    from neo4j import GraphDatabase
    save(WORK/'actual_real_interpreter_dependency_preflight.json',
         {'status':'PASS', 'interpreter':sys.executable, 'isolated':sys.flags.isolated,
          'neo4j_version':neo4j.__version__, 'neo4j_module_sha256':sha(Path(neo4j.__file__)),
          'driver_import_exercised':True})
    spec = importlib.util.spec_from_file_location('pinned_stage_guard', STAGE_GUARD)
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    assert sha(STAGE_GUARD) == 'c087f91a6194645e46a95134d7ba9d7d7264d81a9abc31bf6b7f4353ccc04751'
    name = previous['target']['container']
    port = int(previous['target']['bolt'].rsplit(':',1)[1])
    stages = []
    def validate(running):
        info = json.loads(command('docker','inspect',name))[0]
        item = guard.validate(info, name=name, port=port, run_uuid=previous['run_uuid'],
                              source_sha256=previous['source']['sha256'],
                              image_id=previous['image_id'], expected_running=running)
        stages.append(item)
        save(WORK/'actual_owned_container_lifecycle_stages.json',stages)
    receipt = {'status':'PREPARED_NOT_EXECUTED', 'created_utc':datetime.now(timezone.utc).isoformat(),
               'definition_sha256':definition_sha, 'source_sha256':sha(source),'db_sha256':sha(db),
               'query_sha256':definition['reference_query_sha256'], 'wrapper_sha256':sha(Path(__file__)),
               'previous_whole_inventory_manifest_sha256':sha(PREVIOUS/'actual_native_manifest.json'),
               'reuses_exact_owned_loaded_snapshot':True, 'container_run_uuid':previous['run_uuid'],
               'original560_admissions':0, 'model_calls':0, 'expert_validation_n':0,
               'previous_ASC_capture_modified':False}
    target = WORK/'actual_native_exact_DESC_receipt.json'
    save(target, receipt)
    with (BASE/'native_capture.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
        windows = int(command('powershell.exe','-NoProfile','-Command',
                              '(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'))*1024
        available = next(int(s.split()[1])*1024 for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:'))
        receipt['host_guard'] = {'linux_available_bytes':available,'windows_available_bytes':windows,
                                 'minimum_available_bytes':26*GIB,'container_budget_bytes':2*GIB,
                                 'reserve_bytes':16*GIB}
        save(target,receipt)
        assert min(available,windows)>=26*GIB
        assert not any(n.startswith('kdd-db-') for n in command('docker','ps','--format','{{.Names}}').splitlines())
        validate(False)
        started = False
        driver = None
        try:
            command('docker','start',name)
            started = True
            validate(True)
            driver = GraphDatabase.driver(previous['target']['bolt'],auth=None,connection_timeout=3)
            deadline = time.monotonic()+50
            while True:
                try:
                    driver.verify_connectivity()
                    break
                except Exception:
                    if time.monotonic()>=deadline:
                        raise
                    time.sleep(0.5)
            with driver.session(default_access_mode='READ') as session:
                counts = {'total_nodes':session.run('MATCH(n) RETURN count(n)').single()[0],
                          'label_counts':dict(session.run('MATCH(n) UNWIND labels(n) AS label RETURN label,count(*) AS n').values()),
                          'rel_counts':dict(session.run('MATCH()-[r]->() RETURN type(r) AS kind,count(*) AS n').values())}
                assert counts == previous['measured_counts']
            captures = {}
            for key, statement in queries.items():
                validate(True)
                with driver.session(default_access_mode='READ') as session:
                    tx = session.begin_transaction(timeout=90)
                    try:
                        explain = tx.run('EXPLAIN '+statement).consume()
                        assert explain.query_type=='r' and not explain.counters.contains_updates
                        result = tx.run(statement)
                        columns = list(result.keys())
                        rows = [list(row.values()) for row in result]
                        summary = result.consume()
                        assert summary.query_type=='r' and not summary.counters.contains_updates
                        assert columns==['tdocNumber','summary'] and bag(rows)==bag(expected[key])
                        assert rows==expected[key], 'Exact original DESC order must match'
                        captures[key] = {'literal_query':statement,'columns':columns,'rows':rows,'row_n':len(rows),
                                         'EXPLAIN_query_type':explain.query_type,'actual_query_type':summary.query_type,
                                         'contains_updates':False,'complete':True,'truncated':False,
                                         'transaction_rolled_back':True}
                    finally:
                        tx.rollback()
            save(WORK/'actual_native_two_field_DESC_capture.json', captures)
            reference = WORK/'RAN4_P4_CQ4-5.jsonl'
            reference.write_text(''.join(json.dumps(dict(zip(['tdocNumber','summary'],row)),ensure_ascii=False)+'\n' for row in captures['selected']['rows']))
            assert sha(source)==previous['source']['sha256'] and sha(db)==previous['db']['sha256'] and sha(DEFINITION)==definition_sha
            assert sha(PREVIOUS/'actual_native_manifest.json')=='e9895e952541bbf1dc2785f44ffda11f2cda255f2738391d952f4b01f8312798'
            receipt.update(status='ACTUAL_EXACT_DESC_TWO_FIELDS_NATIVE_AND_INDEPENDENT_SQL_FULL_POOL_PASS',
                           whole_graph_counts=counts,selected_rows=10,whole_eligible_rows=808,
                           capture_sha256=sha(WORK/'actual_native_two_field_DESC_capture.json'),
                           reference_jsonl_sha256=sha(reference),SQL_reference_sha256=sha(WORK/'actual_immutable_SQL_two_field_DESC_reference.json'))
        except BaseException as exc:
            receipt.update(status='FAILED_PRESERVED',error_class=type(exc).__name__)
            raise
        finally:
            if driver is not None:
                driver.close()
            if started:
                validate(True)
                command('docker','stop','--time','20',name)
                validate(False)
                receipt['owned_container_stopped']=True
            receipt['updated_utc']=datetime.now(timezone.utc).isoformat()
            save(target,receipt)
    print(json.dumps({'status':receipt['status'],'selected_rows':receipt['selected_rows'],
                      'whole_eligible_rows':receipt['whole_eligible_rows'],'owned_container_stopped':True}))


if __name__=='__main__':
    main()
