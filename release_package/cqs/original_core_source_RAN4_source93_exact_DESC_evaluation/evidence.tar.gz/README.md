# RAN4 source93 saved first-five evaluation replay

This separate one-question source cohort contributes zero original560 admissions. Each of four methods has N=1. Text2Cypher and Text2SQL each return the two requested fields for all10 source-selected records and score F1=exact1. Single retrieval (C) produces a valid partial two-record answer with zero complete-record matches (F1=0); this is neither a parse failure nor a model abstention. Two-round retrieval (D) fails the original whole-content JSON parser (F1=0). Every failure stays in its denominator. No prose/fenced recovery is scored.

The saved first5 HTTP200 calls cost provider-reported Decimal $0.446060, with zero quality/transport retries. There are no new provider calls in this package, no replaced answers, no pooling with historical cohorts, and no causal conclusion from interface score differences. Expert validation N=0.

Place the separately supplied exact-DESC source package beside this directory as `../original_core_source_RAN4_source93_exact_DESC`, or supply it explicitly:

```sh
python3 -B -I verify_saved_outputs.py --source-evidence ../original_core_source_RAN4_source93_exact_DESC
```

The verifier checks a closed immutable inventory, the external source manifest and all67 manifest-listed files (68 including its manifest),169 relocated pre-call pins (27 shared+142 evaluation-only), all5 exact prompts, saved provider/request/response/usage identities and Decimal cost, unchanged generated query bytes, original strict parsers,10 saved actual-reference records, and all4 scores. It imports unchanged retrieval bytes after removing only the two unused ROOT/CORPUS_DIR environment assignments in an in-memory AST. No runtime adapter source bytes change.

Exactly3 large derived TTL/SQL/FTS artifacts are omitted; their172-pin pre-call freeze records remain intact in frozen_path_bridge.json. Their contents are not revalidated here. This command does not open a database, rerun queries or retrieval, restore containers, access credentials/network, or certify source truth. The separate source package verifies its documented source scope. Saved native/SQL execution records are scored without reexecuting them. Historical absolute paths are provenance only and never used as a fallback. Documentary acceptance is not proof of physical-floor timing, TSG approval, or normative incorporation. Shared underlying facts do not establish equal model exposure or retrieval completeness.
