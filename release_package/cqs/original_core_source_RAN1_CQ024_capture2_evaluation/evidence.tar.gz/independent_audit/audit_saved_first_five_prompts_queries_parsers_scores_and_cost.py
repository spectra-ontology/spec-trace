#!/usr/bin/env python3
"""Read-only scientific-output audit; pure prompt/parser/scorer calls only."""
import ast
from collections import Counter
from datetime import datetime
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
O = OUT.parents[2]
E = O / 'root_RAN1_CQ024_capture2_prepared_evaluation_v1'
T = E / 'actual_call_trial_v1'
IDENT = 'RAN1_P3_CQ024'
blocked = []
def audit(event, args):
    if event.startswith(('socket.', 'subprocess.', 'sqlite3.connect')) or event in {'os.system', 'os.exec', 'os.posix_spawn', 'os.fork'}:
        blocked.append(event)
        raise RuntimeError('Independent audit forbids DB/network/process/native: ' + event)
sys.addaudithook(audit)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p): return {'path': str(p), 'bytes': Path(p).stat().st_size, 'sha256': sha(p)}
def load(p): return json.loads(Path(p).read_text())
def canonical(v): return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
def digest(v): return hashlib.sha256(canonical(v).encode()).hexdigest()
def module(p, name):
    spec = importlib.util.spec_from_file_location(name, p)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result

cfgpath = E / 'root_configuration_final.json'
cfg = load(cfgpath)
assert sha(cfgpath) == 'fd2a7f7d6ee4bc07fd56c87d098e0f8de9bde74502cc451b5e4ab0bb710bd7f1'
frozen = load(E / 'precall_freeze.json')
assert frozen['root_configuration_sha256'] == sha(cfgpath)
assert frozen['expected_request_stages'] == 5 and frozen['N_per_method'] == 1
assert frozen['original560_admission_delta'] == frozen['quality_retries'] == frozen['human_expert_validation_n'] == 0
assert frozen['methods'] == ['Text2Cypher', 'Text2SQL', 'C', 'D']
assert len(frozen['pinned_files']) == 57
small_verified, large_reused = [], []
for rec in frozen['pinned_files']:
    p = Path(rec['path']); assert p.stat().st_size == rec['bytes']
    if rec['bytes'] <= 8 * 1024**2:
        assert sha(p) == rec['sha256'], p
        small_verified.append(rec)
    else:
        assert rec['sha256'] in {cfg[k]['sha256'] for k in ['TTL_input', 'SQL_input', 'FTS_input']}
        large_reused.append(rec)
assert len(small_verified) == 54 and len(large_reused) == 3
start_pins = {str(p.relative_to(T)): pin(p) for p in T.rglob('*') if p.is_file()}
runner = module(E / 'run_separate_CQ024_experiment.py', 'independent_CQ024_output_runner')
structured, retrieval = runner.adapters()
sys.path.insert(0, str(E / 'scoring'))
scorer = module(E / 'scoring/original_scorer.py', 'independent_CQ024_output_scorer')
definition = load(cfg['cases'][IDENT]['definition']['path'])
gold = [json.loads(s) for s in Path(cfg['cases'][IDENT]['actual_reference_rows']['path']).read_text().splitlines()]
assert len(gold) == len({r['resolutionId'] for r in gold}) == 10
assert scorer.score(definition, gold, gold, diagnostic=True)['exact'] is True
task = load(E / 'public_tasks.json')[0]
assert task['question_en'] == definition['question_en']
generated = load(T / 'generated_before_execution.json')
executed = load(T / 'executed_predictions.json')
summary = load(T / 'actual_results_summary.json')
assert generated['freeze_sha256'] == executed['freeze_sha256'] == sha(E / 'precall_freeze.json')
assert generated['database_execution_during_generation'] is False
assert set(generated['results'][IDENT]) == set(executed['results'][IDENT]) == set(frozen['methods'])
queryfreeze = load(T / 'before_execution_queries_frozen.json')
assert queryfreeze['generated_record_sha256'] == sha(T / 'generated_before_execution.json')
assert datetime.fromisoformat(generated['utc']) < datetime.fromisoformat(queryfreeze['utc']) < datetime.fromisoformat(executed['utc'])
assert datetime.fromisoformat(executed['utc']) < datetime.fromisoformat(summary['utc'])

requests = sorted((T / 'calls').glob('*.request.json'))
responses = sorted((T / 'calls').glob('*.response.json'))
outcomes = sorted((T / 'calls').glob('*.outcome.json'))
expected_names = {IDENT + '_' + s for s in ['Text2Cypher', 'Text2SQL', 'C_answer', 'D_followup', 'D_answer']}
assert len(requests) == len(responses) == len(outcomes) == 5
assert {p.name.removesuffix('.request.json') for p in requests} == expected_names
assert not list(T.rglob('*.attempt1.response.json'))
assert not list(T.rglob('*retry*')) and not (T / 'preserved_adapter_exceptions').exists()
calls = {}; exact_cost = Decimal(0); prompt_tokens = completion_tokens = 0
for request in requests:
    req = load(request); rid = req['request_id']; payload = req['payload']
    response_path = request.with_name(rid + '.attempt0.response.json')
    out = load(request.with_name(rid + '.outcome.json')); env = load(response_path); raw = env['response']
    assert req['payload_sha256'] == hashlib.sha256(json.dumps(payload, ensure_ascii=False).encode()).hexdigest()
    assert req['authorization_header_omitted'] is True
    assert payload['model'] == raw['model'] == 'anthropic/claude-opus-4.8'
    assert payload['provider'] == {'only': ['Anthropic'], 'allow_fallbacks': False, 'require_parameters': True}
    assert raw['provider'] == 'Anthropic' and payload['stream'] is False
    assert payload['reasoning'] == {'enabled': False} and payload['response_format'] == {'type': 'json_object'}
    assert env['request_id'] == rid and env['attempt'] == 0 and env['http_status'] == 200
    assert len(raw['choices']) == 1
    choice = raw['choices'][0]
    assert choice['finish_reason'] == out['finish_reason'] == 'stop'
    assert choice['native_finish_reason'] == 'end_turn'
    assert choice['message']['content'] == out['content']
    assert choice['message'].get('refusal') is None and choice['message'].get('reasoning') is None
    assert out['usage'] == raw['usage'] and out['generation_id'] == raw['id']
    assert out['ok'] is True and out['error'] is None and out['unknown_cost_attempts'] == 0
    assert out['attempts'] == [{'attempt': 0, 'http_status': 200, 'response_path': str(response_path), 'retryable': False}]
    assert datetime.fromisoformat(frozen['utc']) < datetime.fromisoformat(req['created_utc']) < datetime.fromisoformat(env['received_utc'])
    assert datetime.fromisoformat(env['received_utc']) <= datetime.fromisoformat(generated['utc'])
    usage = raw['usage']; cost = Decimal(str(usage['cost']))
    assert cost == Decimal(str(out['known_actual_cost_usd']))
    assert cost == Decimal(usage['prompt_tokens']) * Decimal('.000005') + Decimal(usage['completion_tokens']) * Decimal('.000025')
    assert usage['total_tokens'] == usage['prompt_tokens'] + usage['completion_tokens']
    assert usage['completion_tokens'] < payload['max_tokens'] and usage['completion_tokens_details']['reasoning_tokens'] == 0
    exact_cost += cost; prompt_tokens += usage['prompt_tokens']; completion_tokens += usage['completion_tokens']
    calls[rid] = {'request': req, 'envelope': env, 'outcome': out}

assert exact_cost == Decimal('.463310')
usage = load(T / 'usage.json')
assert abs(Decimal(str(usage['known_actual_cost_usd'])) - exact_cost) < Decimal('1e-12')
assert usage['received_response_calls'] == 5 and usage['unknown_cost_attempts'] == 0 and usage['all_actual_costs_known'] is True
assert usage['halted_unknown_cost'] is False and usage['budget_guard_usd'] == 3
assert usage['guard_is_approximate_not_a_provider_billing_cap'] is True
assert generated['usage'] == usage == summary['usage']

prompt_checks = []
for method in ['Text2Cypher', 'Text2SQL']:
    rid = IDENT + '_' + method
    messages = structured.messages_for(runner.task(IDENT, method), method)
    assert messages == calls[rid]['request']['payload']['messages']
    prediction = load(T / 'predictions' / method / (IDENT + '.json'))
    assert prediction == generated['results'][IDENT][method]
    parsed = json.loads(calls[rid]['outcome']['content'])
    assert set(parsed) == {'query', 'abstain'} and parsed['abstain'] is False
    assert prediction['generated_query'] == parsed['query'] == executed['results'][IDENT][method]['generated_query']
    assert prediction['query_sha256'] == hashlib.sha256(parsed['query'].encode()).hexdigest() == queryfreeze['queries'][IDENT][method]
    assert prediction['prompt_sha256'] == digest(messages)
    assert prediction['private_evidence_read_by_generator'] is False
    assert prediction['status'] == 'QUERY_READY'
    public = json.loads(messages[1]['content'])
    assert public['selection_policy'] == task['selection_policy']
    assert definition['reference_query'] not in canonical(public) and definition['original_query'] not in canonical(public)
    assert 'AGR-' not in canonical(public)
    structured.reject_private(public)
    if method == 'Text2SQL':
        physical = prediction['physical_SQL_interface_before_model_call']
        assert physical == frozen['physical_SQL_interface_gate']
        assert physical['table_n'] == 88 and physical['relationship_table_n'] == 55
        tables = {r['name'] for r in public['schema']['tables']}
        referenced = re.findall(r'\b(?:FROM|JOIN)\s+([A-Za-z_][A-Za-z_0-9]*)', parsed['query'], re.I)
        assert set(referenced) <= tables
    prompt_checks.append({'stage': rid, 'exact_rebuild': True, 'prompt_sha256': digest(messages), 'private_contract_prefix_excluded': True})

contract = retrieval.public_contract(task)
retrieval_checks = []
for method in ['C', 'D']:
    folder = T / 'retrieval' / method / IDENT
    initial = load(folder / 'initial_context.json'); final = load(folder / 'final_context.json')
    saved_result = load(folder / 'result.json')
    assert saved_result == generated['results'][IDENT][method] == executed['results'][IDENT][method]
    assert saved_result['protocol_sha256'] == digest(retrieval.PROTOCOL)
    assert saved_result['source_index_sha256'] == cfg['FTS_input']['sha256']
    assert saved_result['requested_population_completeness_verified'] is False
    assert saved_result['status'] == 'answer_parse_error' and saved_result['records'] == []
    assert 'abstain' not in saved_result
    for name, context in [('initial', initial), ('final', final)]:
        docs = context['documents']; passages = '\n\n'.join(d['formatted'] for d in docs)
        assert len(docs) == context['stats']['selected_documents'] == 12
        assert len(passages) == context['stats']['characters']
        assert len(passages.encode()) == context['stats']['utf8_bytes']
        assert len(passages) <= retrieval.PROTOCOL['total_context_characters']
        assert all(hashlib.sha256(d['formatted'].encode()).hexdigest() == d['formatted_sha256'] for d in docs)
    first = load(folder / 'retrieval_round_1.json')
    assert first['query'] == task['question_en'] and first['query_sha256'] == hashlib.sha256(task['question_en'].encode()).hexdigest()
    assert first['status'] == 'ok' and len(first['hits']) == 160
    assert first['matched_population_read_complete'] is False and first['context_candidate_truncated'] is True
    if method == 'C':
        assert initial == final
    else:
        follow = calls[IDENT + '_D_followup']
        obj = json.loads(follow['outcome']['content'])
        assert set(obj) == {'query'} and isinstance(obj['query'], str) and obj['query'].strip()
        second = load(folder / 'retrieval_round_2.json')
        assert second['query'] == obj['query'] and second['query_sha256'] == hashlib.sha256(obj['query'].encode()).hexdigest()
        assert datetime.fromisoformat(follow['envelope']['received_utc']) < datetime.fromisoformat(calls[IDENT + '_D_answer']['request']['created_utc'])
        messages = [{'role': 'system', 'content': retrieval.QUERY_INSTRUCTION}, {'role': 'user', 'content': canonical({'question': task['question_en'], 'contract': contract}) + '\nSOURCE PASSAGES:\n' + '\n\n'.join(d['formatted'] for d in initial['documents'])}]
        assert messages == follow['request']['payload']['messages']
        prompt_checks.append({'stage': IDENT + '_D_followup', 'exact_rebuild': True, 'prompt_sha256': digest(messages), 'private_contract_prefix_excluded': True})
    rid = IDENT + '_' + method + '_answer'
    messages = [{'role': 'system', 'content': retrieval.ANSWER_INSTRUCTION}, {'role': 'user', 'content': canonical({'question': task['question_en'], 'contract': contract}) + '\nSOURCE PASSAGES:\n' + '\n\n'.join(d['formatted'] for d in final['documents'])}]
    assert messages == calls[rid]['request']['payload']['messages']
    prefix = messages[1]['content'].split('\nSOURCE PASSAGES:\n')[0]
    assert 'AGR-' not in prefix and definition['reference_query'] not in messages[1]['content']
    try: retrieval.parse_answer(calls[rid]['outcome']['content'])
    except json.JSONDecodeError as exc:
        assert exc.pos == 0 and str(exc) == saved_result['error']
    else: raise AssertionError('Saved prose+JSON was accepted by strict parser')
    prompt_checks.append({'stage': rid, 'exact_rebuild': True, 'prompt_sha256': digest(messages), 'private_contract_prefix_excluded': True})
    retrieval_checks.append({'method': method, 'context_stats': final['stats'], 'status': saved_result['status'],
        'raw_content_starts_with_prose': True, 'accepted_model_abstention': None,
        'unparsed_tail_literal_abstain': False if method == 'C' else True,
        'tail_is_not_reparsed_or_scored': True})
assert len(prompt_checks) == 5
assert load(T / 'retrieval/C' / IDENT / 'initial_context.json') == load(T / 'retrieval/D' / IDENT / 'initial_context.json')

A = executed['results'][IDENT]['Text2Cypher']; B = executed['results'][IDENT]['Text2SQL']
assert A['status'] == B['status'] == 'OK' and A['abstain'] is B['abstain'] is False
assert A['records'] == [{'resolutionId': 'AGR-104-8.17-002'}] and B['records'] == []
for value in [A, B]:
    assert value['execution']['complete'] is True and value['execution']['truncated'] is False
    assert value['execution']['rows'] == value['records'] and value['execution']['columns'] == ['resolutionId']
assert A['execution']['rollback_completed'] is True
assert A['execution']['inventory_before'] == {'nodes': 165418, 'relationships': 848230}
assert B['execution']['immutable_read_only'] is True and B['execution']['source_guard_batch_verified'] is False
events = load(T / 'native_stage_events' / (IDENT + '.json'))
assert events['result_status'] == 'OK'
assert [x['stage'] for x in events['events']] == ['owned_stopped_before_start', 'owned_running_after_start', 'owned_stopped_after_execution']
assert min(events['events'][0]['available'].values()) >= 26 * 1024**3
runtime_source = (E / 'run_separate_CQ024_experiment.py').read_text()
tree = ast.parse(runtime_source)
native_function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'execute_cypher')
native_code = ast.get_source_segment(runtime_source, native_function)
for term in ['assert clean == query', "'EXPLAIN ' + clean", 'guard.require_read_plan(plan)', 'tx.run(clean)', "summary.query_type == 'r'", 'cur.consume()', 'tx.rollback()', 'inspect(False)']:
    assert term in native_code

assert summary['expected_total_method_items'] == 4 and summary['N_per_method'] == 1
assert summary['original560_admission_delta'] == summary['human_expert_validation_n'] == 0
independent_scores = []
for method in frozen['methods']:
    result = executed['results'][IDENT][method]
    valid = result['status'] in {'OK', 'ok', 'partial'} and not result.get('abstain', False)
    pred = result['records'] if valid else []
    value = scorer.score(definition, gold, pred, diagnostic=True)
    detail = next(x for x in summary['results'] if x['method'] == method)
    assert value == detail['score'] and detail['valid_answer'] is valid
    assert detail['failure_remains_in_denominator'] is True
    assert detail['abstention'] is bool(result.get('abstain'))
    assert value['f1'] == 0 and value['exact'] is False
    gold_ids = {r['resolutionId'] for r in gold}; pred_ids = {r['resolutionId'] for r in pred}
    assert not (gold_ids & pred_ids)
    assert summary['macro'][method] == {'N': 1, 'f1': 0.0, 'exact': 0}
    independent_scores.append({'method': method, 'status': result['status'], 'valid_parse_and_operational_answer': valid,
        'predicted_records': len(pred), 'matched_IDs': 0, 'f1': 0.0, 'exact': False,
        'model_abstention': False if method in ['Text2Cypher', 'Text2SQL'] else None,
        'primary_summary_abstention_boolean': detail['abstention'],
        'primary_summary_false_does_not_establish_valid_nonabstention_for_parse_failure': method in ['C', 'D']})

assert not blocked
assert {str(p.relative_to(T)): pin(p) for p in T.rglob('*') if p.is_file()} == start_pins
receipt = {'status': 'PASS_INDEPENDENT_SAVED_FIRST_FIVE_AUDIT_NO_SCORE_OR_PARSER_BUG_IDENTIFIED',
    'cohort': cfg['cohort'], 'N_per_method': 1, 'request_stages': 5, 'method_denominator': 4,
    'actual_cost_decimal_usd': str(exact_cost), 'raw_HTTP200_attempt0': 5, 'transport_retries': 0, 'quality_retries': 0,
    'model': 'anthropic/claude-opus-4.8', 'provider': 'Anthropic', 'all_finish_stop_not_length': True,
    'usage': {'prompt_tokens': prompt_tokens, 'completion_tokens': completion_tokens, 'total_tokens': prompt_tokens + completion_tokens,
        'unknown_cost_attempts': 0, 'reported_float_total_preserved': usage['known_actual_cost_usd'], 'actual_provider_billing_cap_claim': False},
    'configuration': pin(cfgpath), 'freeze': pin(E / 'precall_freeze.json'), 'freeze_pins': 57,
    'small_frozen_pins_rehashed': 54, 'large_pins_stat_and_prior_proof_only': large_reused,
    'requests_responses_outcomes_exact_and_unique': True, 'freeze_precedes_all5_request_timestamps': True,
    'generated_queries_frozen_before_any_execution': True, 'query_text_raw_parsed_generated_execution_SHA_exact': True,
    'five_prompt_rebuilds': prompt_checks, 'common_original_EN_and_shared_selection_preserved': True,
    'private_gold_query_and_reviews_not_added_to_prompts': True,
    'retrieval_passages_are_saved_graph_source_context_not_reference_fixture': True,
    'physical_SQL_88_table_prompt_and_saved_pre_generation_gate_consistent': True,
    'outcomes': independent_scores, 'retrieval': retrieval_checks,
    'literal_query_differences': {'Text2Cypher': 'Generated CR target path uses AFFECTS_CORE_SPEC|AFFECTS_OM_SPEC|AFFECTS_TEST_SPEC; reference uses MODIFIES. Saved actual execution returns one nonmatching ID.',
        'Text2SQL': 'Generated Agreement-to-CR join uses rel_RESOLUTION_BELONGS_TO; reference uses rel_REFERENCES. Saved immutable SQL execution succeeds with zero rows.'},
    'native_read_safety': {'saved_owned_start_running_stop_events': True, 'saved_full_complete_rollback': True,
        'saved_node_edge_inventory': A['execution']['inventory_before'],
        'frozen_successful_code_path_requires_EXPLAIN_read_plan_and_consumed_summary_type_r': True,
        'raw_generated_execution_plan_and_summary_query_type_not_separately_persisted': True,
        'current_container_or_SQL_not_reopened_by_reviewer': True},
    'abstention_caution': 'C/D are strict whole-response parse failures. Neither has an accepted abstain field; primary summary false is its missing-field default. D raw trailing JSON says true but is not reparsed or scored as an accepted abstention.',
    'original560_admission_delta': 0, 'expert_validation_n': 0, 'reviewer': 'independent nonblind AI',
    'scientific_primary_all_four_F1_zero_preserved': True,
    'limits': ['One separate N1 source cohort; never pool with prior source cohorts or original483 performance.',
        'Saved native/SQL results are audited without a new execution.',
        'Shared underlying graph facts do not establish equal interfaces, complete retrieval, equal cost, or causal superiority.',
        'Conditional whole eligible pool is497 four-column records/494distinct IDs; final selected ID set is10.',
        'The three large frozen source files are not rehashed or opened here; root freeze and earlier actual all-fact/source receipts bind them.'],
    'actions': {'model_API': 0, 'network': 0, 'native': 0, 'SQLite': 0, 'FTS': 0, 'external_process': 0,
        'source_runtime_or_scientific_output_mutations': 0, 'blocked_attempts': blocked},
    'saved_trial_inputs': list(start_pins.values()), 'frozen_small_input_pins': small_verified,
    'independent_pre_call_receipt': pin(O / 'RAN2_RAN5/source_lane13/CQ024_final_configuration_independent_precall_audit_v1/actual_final_configuration_runtime_and_budget_independent_precall_audit.json'),
    'audit_script': pin(Path(__file__))}
target = OUT / 'actual_independent_saved_first_five_result_audit.json'
with target.open('x') as f: json.dump(receipt, f, ensure_ascii=False, indent=2); f.write('\n')
print(json.dumps(pin(target), ensure_ascii=False))
