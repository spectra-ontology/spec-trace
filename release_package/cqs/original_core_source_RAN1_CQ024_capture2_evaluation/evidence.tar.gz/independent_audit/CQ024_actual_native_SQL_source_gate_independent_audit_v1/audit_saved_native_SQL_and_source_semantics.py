#!/usr/bin/env python3
"""Independently compare saved CQ024 proofs. Never opens TTL/SQLite/FTS or container/API."""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib,json

O=Path(__file__).resolve().parents[3]
N=O/'root_RAN1_CQ024_capture2_native_v1'
P=O/'priority71_fast_closure/CQ024_original_frozen_plus_generic_capture2_v1'
D=O/'RAN1_RAN3_RAN4/loop139_CQ024_two_reference_edges_calendar_repair_semantic_proposal_NOT_ADMITTED'
S=O/'RAN2_RAN5/source_lane13/RAN1_CQ024_independent_secondary_semantic_and_raw_source_review_v1'
OUT=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def pin(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def check_pin(rec):
 p=Path(rec['path']);assert sha(p)==rec['sha256'];assert p.stat().st_size==rec['bytes'];return p
m=load(N/'actual_native_manifest.json')
assert sha(N/'actual_native_manifest.json')=='cfa433af117dcee3ffccb3b63dddaca1711faee8dbb1be14d1ca4fac4ffa0c37'
assert m['status']=='ACTUAL_NATIVE_FULL165418_848230_AND_EXACT_CALENDAR_REFERENCE_EQUAL_SQL'
assert m['owned_container_stopped'] is True
assert m['new_model_calls']==m['question_admissions']==m['expert_validation_n']==0
assert m['selected_rows']==10 and m['whole_matching_pool_rows']==497
assert (m['parse_inventory']['nodes'],m['parse_inventory']['relationships'])==(165418,848230)
assert m['measured_counts']['total_nodes']==m['parse_inventory']['nodes']
assert m['measured_counts']['label_counts']==m['parse_inventory']['labels']
assert m['measured_counts']['rel_counts']==m['parse_inventory']['relations']
assert sum(m['measured_counts']['rel_counts'].values())==848230
capture=load(check_pin(m['capture']))
check_pin(m['loader']);check_pin(m['helper']);check_pin(m['wrapper'])
definition=load(D/'prospective_definition.json')
repair=hashlib.sha256(canonical(definition).encode()).hexdigest()
assert repair=='7c0122437095d695d0b13dd316463dd2df31f63c8dd41b88e64e090507c796b2'
sql=load(N/'actual_immutable_SQL_four_column_reference.json')
check_pin(sql['definition'])
independent_sql=load(P/'actual_new_full_SQL_calendar_reference.json')
assert sql['SQL']==independent_sql['SQL']
assert sql['queries']['selected']==definition['reference_query']==independent_sql['reference_query']
assert sql['queries']['whole_matching_pool']==definition['reference_query'].removesuffix(' LIMIT 10')
expected_columns=['agr.resolutionId','content','m.meetingNumber','m.meetingNumberInt']
for kind,n in [('selected',10),('whole_matching_pool',497)]:
 v=capture[kind]
 assert v['literal_query']==sql['queries'][kind]
 assert v['columns']==expected_columns
 assert len(v['rows'])==v['row_n']==n
 assert v['rows']==sql['rows'][kind]
 assert v['EXPLAIN_query_type']==v['actual_query_type']=='r'
 assert v['contains_updates'] is False
 assert v['complete'] is True and v['truncated'] is False and v['transaction_rolled_back'] is True
 assert all(len(r)==4 and all(isinstance(x,str) for x in r[:3]) and type(r[3]) is int for r in v['rows'])
assert independent_sql['rows']==capture['selected']['rows']
assert independent_sql['complete_pool_rows']==capture['whole_matching_pool']['rows']
whole=capture['whole_matching_pool']['rows'];selected=capture['selected']['rows']
sorted_whole=sorted(whole,key=lambda r:r[0])
sorted_whole.sort(key=lambda r:r[2],reverse=True)
sorted_whole.sort(key=lambda r:r[3],reverse=True)
assert whole==sorted_whole and selected==sorted_whole[:10]
assert len(set(map(lambda r:canonical(r),whole)))==497
assert len({r[0] for r in selected})==10
groups=defaultdict(list)
for rank,row in enumerate(whole,1):groups[row[0]].append({'rank':rank,'meetingNumber':row[2],'meetingNumberInt':row[3]})
duplicate={key:rows for key,rows in groups.items() if len(rows)>1}
assert len(groups)==494 and len(duplicate)==3
assert all(all(row['rank']>10 for row in rows)for rows in duplicate.values())
reference=[json.loads(line)for line in (N/'requested_resolutionId_records.jsonl').read_text().splitlines()]
assert reference==[{'resolutionId':r[0]}for r in selected]==independent_sql['required_ID_records']
source_prefix=load(P/'actual_source_valid11_calendar_prefix_independent_comparison.json')
source_sorted=sorted(source_prefix['source_valid11'],key=lambda r:r['resolutionId'])
source_sorted.sort(key=lambda r:r['meetingNumber'],reverse=True)
source_sorted.sort(key=lambda r:r['meetingNumberInt'],reverse=True)
three_roles=[{'resolutionId':r[0],'meetingNumber':r[2],'meetingNumberInt':r[3]}for r in selected]
assert three_roles==source_sorted[:10]==source_prefix['exact_calendar_source_prefix10']
assert Counter(r[2]for r in selected)==Counter({'RAN1#123':2,'RAN1#122b':8})
assert whole[10][0]=='AGR-122b-UNKNOWN-020'
material=load(P/'actual_materialization_manifest.json')
for name in ['source_delta_manifest','allfact_proof','new_SQL_reference','reference_query']:check_pin(material[name])
assert material['source_TTL']==m['source'] and material['source_SQL']==m['db']
assert material['no_common3176_used'] is True
assert material['full_all869_XML_windows_replayed']==869 and material['all21_capture_candidates_reproduced']==21
assert material['accepted38_links']==38 and material['existing36_links_retained']==36
assert {(x['src_id'],x['dst_id'])for x in material['derived_new_edges']}=={(13604,157359),(13604,157360)}
facts=load(P/'actual_all89_tables_and_full_graph_fact_equivalence.json')
assert facts['status']=='PASS' and len(facts['all89_original_storage_schemas_and_typed_rows'])==89
assert all(x['typed_original_rows_preserved']for x in facts['all89_original_storage_schemas_and_typed_rows'])
assert facts['new_edges']==[[848229,13604,'REFERENCES',157359],[848230,13604,'REFERENCES',157360]]
assert facts['all_node_labels_properties_unchanged']==165418 and facts['whole_directed_edges']==848230
assert facts['old_TTL_exact_byte_prefix'] is True
root_facts=load(N/'actual_root_full_public_parse_vs_SQL_all_facts.json')
assert root_facts['status']=='PASS' and root_facts['full_native_property_dictionaries_and_labels_equal'] is True
assert root_facts['nodes']==165418 and root_facts['directed_edges']==848230
assert root_facts['new_directed_REFERENCES']==2 and root_facts['old_node_properties_unchanged'] is True
check_pin(root_facts['code'])
primary=load(D/'prospective_primary_exact_seven_unit_review.json')
secondary=load(S/'independent_secondary_exact_seven_unit_source_context_review.json')
for name,v in [('primary',primary),('secondary',secondary)]:
 assert v['status']=='pass' and v['repair_sha256']==repair
 units=v['semantic_evidence'];assert len(units)==7 and len({u['unit']for u in units})==7
 assert all(u['status']=='pass'for u in units)
 assert v['expert_validation_n']==0
assert primary['original_question_sha256']==hashlib.sha256(definition['question_en'].encode()).hexdigest()
assert primary['original_query_sha256']==hashlib.sha256(definition['original_query'].encode()).hexdigest()
assert primary['definition_file_sha256']==sha(D/'prospective_definition.json')
assert primary['reviewer_kind']!=secondary.get('reviewer_kind')
raw_path=check_pin(secondary['fresh_source_replay'])
assert sha(raw_path)=='cef5b78e65659947a8dc3025d582621d1cab7db7dd032470530e8a2808c30ab8'
host=load(N/'actual_host_resource_guard.json')
assert host==m['host_guard']
assert min(host['linux_available_bytes'],host['windows_available_bytes'])>=host['minimum_available_bytes']==26*1024**3
interpreter=load(N/'actual_real_interpreter_dependency_preflight.json')
assert interpreter['status']=='PASS' and interpreter['interpreter']=='/usr/bin/python3' and interpreter['isolated']==0
files=[*sorted(N.glob('*.json')),*sorted(N.glob('*.jsonl')),
 P/'actual_materialization_manifest.json',P/'actual_all89_tables_and_full_graph_fact_equivalence.json',
 P/'actual_source_valid11_calendar_prefix_independent_comparison.json',P/'actual_new_full_SQL_calendar_reference.json',
 D/'prospective_definition.json',D/'prospective_primary_exact_seven_unit_review.json',
 S/'independent_secondary_exact_seven_unit_source_context_review.json',raw_path,Path(m['wrapper']['path'])]
receipt={
 'status':'PASS_INDEPENDENT_SAVED_NATIVE_SQL_SOURCE_SEMANTIC_GATE_AUDIT',
 'original560_admission_delta':0,'human_expert_validation_n':0,
 'attribution':'Secondary nonblind AI, source/definition reviewed before model outputs. Root executed native/SQL; this reviewer independently re-read saved JSON, scripts and prior raw-source evidence.',
 'native_manifest_sha256':sha(N/'actual_native_manifest.json'),
 'exact_native_SQL_four_column_order_and_values':True,
 'full_pool':{'four_column_distinct_rows':497,'distinct_resolutionIds':494,'duplicate_ID_groups_below_cutoff':duplicate},
 'requested_selection':{'records':10,'unique_IDs':10,'meeting_counts':dict(Counter(r[2]for r in selected)),
 'IDs':reference,'saved_fullpool_sort_independently_recomputed':True,'source_valid11_prefix_exact':True,
 'foreign_reference_preserved_at_rank11':whole[10][0]},
 'source_and_graph':{'whole_nodes':165418,'whole_directed_edges':848230,'original_tables':89,
 'new_REFERENCES_only':2,'all_old_properties_retained_per_saved_direct_replay':True,'common3176_augmentation_used':False},
 'two_source_semantic_reviews':{'primary':pin(D/'prospective_primary_exact_seven_unit_review.json'),
 'secondary':pin(S/'independent_secondary_exact_seven_unit_source_context_review.json'),'seven_units_each_pass':True,
 'scope':'Recorded CR-reference to requested Spec, calendar-consistent recent membership, ID-only set10. Not every technical effect/approval/incorporation; no original frozen admission.'},
 'actual_native_execution_evidence':{'read_EXPLAIN_execution_fullconsumption_rollback':True,'root_saved_container_stopped':True,
 'same_real_interpreter_preflight':True,'host26GiB_start_guard':True},
 'reviewer_execution_scope':{'SQL_execution':0,'TTL_parse':0,'FTS_reads':0,'native_calls':0,'API_calls':0,
 'public_central_or_source_mutations':0,'large_TTL_SQL_FTS_not_reopened':True},
 'limits':['Graph/source fidelity claims here are linked to root and materializer saved whole-fact replay; this audit does not independently rerun the large parse/DB proof.',
 '497 four-column rows are not497 distinct Agreement IDs; the3 old multi-meeting IDs are strictly below this cutoff.',
 'Known foreign source boundaries remain preserved in the base; rank11 is outside this answer.',
 'The captured content columns are compared byte-for-value between interfaces, not newly certified complete body/equation transcriptions.',
 'Final config, common FTS bytes, scorer controls, freeze and paid calls remain separate ROOT gates.'],
 'inputs':[pin(p)for p in files],'audit_script':pin(Path(__file__))}
out=OUT/'actual_saved_native_SQL_source_and_two_reviews_audit.json'
with out.open('x')as f:json.dump(receipt,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(pin(out),ensure_ascii=False))

