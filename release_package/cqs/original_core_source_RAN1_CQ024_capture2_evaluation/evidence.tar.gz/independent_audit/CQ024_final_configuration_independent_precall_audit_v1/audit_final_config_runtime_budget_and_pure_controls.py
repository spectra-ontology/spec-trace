#!/usr/bin/env python3
"""Local static/pure audit. Audithook forbids SQLite, sockets, subprocess and provider calls."""
import ast,copy,hashlib,importlib.util,json,math,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parents[3]
E=O/'root_RAN1_CQ024_capture2_prepared_evaluation_v1'
D=O/'RAN1_RAN3_RAN4/loop151_CQ024_separate_capture2_runtime_preparation'
P=O/'priority71_fast_closure/CQ024_original_frozen_plus_generic_capture2_v1'
OUT=Path(__file__).resolve().parent
ROOT=next(p for p in O.parents if (p/'CLAUDE.md').exists())
blocked=[]
def hook(event,args):
 if event.startswith(('socket.','subprocess.','sqlite3.connect')) or event in {'os.system','os.exec','os.posix_spawn','os.fork'}:
  blocked.append(event);raise RuntimeError('Audit forbids DB/network/process:'+event)
sys.addaudithook(hook)
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canon(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def pin(p):p=Path(p);return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def check(rec):
 p=Path(rec['path']).resolve(strict=True)
 assert p.stat().st_size < 8*1024**2,('unexpected large evidence',p)
 assert sha(p)==rec['sha256'],p
 if 'bytes'in rec:assert p.stat().st_size==rec['bytes']
 return p
def module(p,name):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

config_path=E/'root_configuration_final.json'
assert sha(config_path)=='fd2a7f7d6ee4bc07fd56c87d098e0f8de9bde74502cc451b5e4ab0bb710bd7f1'
cfg=load(config_path)
assert cfg['ready_for_root_review'] is True and cfg['original560_admission_delta']==0
assert cfg['budget_usd']==3.0 and cfg['execution_interpreter']==sys.executable=='/usr/bin/python3'
assert list(cfg['cases'])==['RAN1_P3_CQ024']
assert not Path(cfg['trial_directory']).exists() and not (E/'precall_freeze.json').exists()
expected_classes={'whole_native_reference_capture','whole_independent_SQL_agreement','independent_second_seven_unit_semantics','generic_and_boundary_scoring_controls','whole_source_and_FTS_equivalence'}
assert set(cfg['gate_receipts'])==expected_classes
small_pins=[]
for rec in [cfg['native_manifest'],cfg['read_query_guard'],*cfg['scoring_files'],*cfg['additional_evidence_files']]:
 small_pins.append(check(rec))
for case in cfg['cases'].values():
 small_pins.extend([check(case['definition']),check(case['actual_reference_rows'])])
for kind,rec in cfg['gate_receipts'].items():
 p=check(rec);value=load(p);assert rec['assertions']
 for assertion in rec['assertions']:
  actual=value
  for key in assertion['key_path']:actual=actual[key]
  assert actual==assertion['equals'],(kind,assertion)
 small_pins.append(p)
prep=load(E/'prospective_preparation.json')
for key in ['TTL_input','SQL_input','FTS_input']:
 assert prep[key]==cfg[key]
 assert Path(cfg[key]['path']).is_file()
assert (E/'run_separate_CQ024_experiment.py').read_bytes()==(D/'run_separate_CQ024_experiment.py').read_bytes()
for sub in ['public_tasks.json','graph_schema.json','sql_schema.json',*[str(p.relative_to(E))for p in (E/'runtime').glob('*.py')],*[str(p.relative_to(E))for p in (E/'scoring').glob('*')if p.is_file()]]:
 assert (E/sub).read_bytes()==(D/sub).read_bytes(),sub
all_native=load(cfg['native_manifest']['path'])
assert all_native['source']==load(P/'actual_materialization_manifest.json')['source_TTL']
assert cfg['TTL_input']['sha256']==all_native['source']['sha256']
assert cfg['SQL_input']['sha256']==all_native['db']['sha256']
target=cfg['native_container']
assert target['name']==all_native['target']['container'] and target['bolt']==all_native['target']['bolt']
assert target['port']==57916 and target['run_uuid']==all_native['run_uuid'] and target['image_id']==all_native['image_id']
assert target['source_sha256']==cfg['TTL_input']['sha256']
assert cfg['native_lock_path']==str(O.parent.parent/'native_capture.lock')
runner=module(E/'run_separate_CQ024_experiment.py','audit_CQ024_runner')
assert runner.config(config_path)==cfg
interpreter=runner.interpreter_preflight(cfg)
assert interpreter['native_or_network_calls']==0
structured,retrieval=runner.adapters()
physical=module(E/'runtime/physical_schema.py','audit_CQ024_physical_shape')
schema=load(E/'sql_schema.json');physical.require_shape(schema)
assert len(schema['tables'])==88
rel_tables=[x for x in schema['tables']if x['name'].startswith('rel_')]
assert len(rel_tables)==55 and all(not x['name'].startswith('_')for x in schema['tables'])
build=load(E/'actual_complete_physical_SQL_schema_build.json')
assert build['database_sha256']==cfg['SQL_input']['sha256']
assert build['schema_sha256']==hashlib.sha256(canon(schema).encode()).hexdigest()
assert build['table_n']==88 and build['data_rows_read_from_source']==0
inventory=load(E/'actual_root_gates/actual_inventory/retrieval_corpus_inventory.json')
assert len(inventory['shards'])==1
shard=inventory['shards'][0]
assert shard['WG']=='RAN1' and shard['sha256']==cfg['FTS_input']['sha256']
shard_path=Path(shard['path']);shard_path=shard_path if shard_path.is_absolute()else ROOT/shard_path
assert shard_path.resolve()==Path(cfg['FTS_input']['path']).resolve()
assert Path(cfg['FTS_input']['path']).stat().st_size==shard['bytes']
assert hashlib.sha256(canon(retrieval.PROTOCOL).encode()).hexdigest()==inventory['protocol_sha256']
assert retrieval.CORPUS_DIR.resolve()==shard_path.resolve().parent
assert sum(x['stored_rows']for x in shard['collections'])==257130
facts=load(cfg['gate_receipts']['whole_source_and_FTS_equivalence']['path'])
assert facts['immutable_database_sha256']==cfg['FTS_input']['sha256']
assert facts['fact_source_sha256']==cfg['TTL_input']['sha256']
assert facts['nodes_reconstructed']==165418 and facts['edges_reconstructed']==848230
for name in ['guarded_build_receipt.json','guarded_verify_receipt.json']:
 v=load(P/name);assert v['status']=='PASS' and v['returncode']==0 and v['source_inputs_unchanged'] is True
 assert v['source_TTL_sha256_before_and_after']==cfg['TTL_input']['sha256']
assert load(P/'actual_corpus/build_receipt.json')['immutable_database_sha256']==cfg['FTS_input']['sha256']
tasks=load(E/'public_tasks.json');task=tasks[0]
assert len(tasks)==1
definition=load(cfg['cases'][task['id']]['definition']['path'])
assert hashlib.sha256(canon(definition).encode()).hexdigest()==task['repair_sha256']=='7c0122437095d695d0b13dd316463dd2df31f63c8dd41b88e64e090507c796b2'
assert task['question_en']==definition['question_en']
assert 'AGR-'not in canon(task)
mock_messages=load(E/'actual_common_contract_and_ID_set_controls_v2/actual_mock_five_stage_messages.json')
assert len(mock_messages)==5
rebuilt={}
for method in ['Text2Cypher','Text2SQL']:
 current=runner.task(task['id'],method)
 msgs=structured.messages_for(current,method)
 record=next(x for x in mock_messages if x['id']==task['id']+'_'+method)
 assert msgs==record['messages']
 rebuilt[record['id']]=msgs
public=retrieval.public_contract(task)
for suffix,system in [('C_answer',retrieval.ANSWER_INSTRUCTION),('D_followup',retrieval.QUERY_INSTRUCTION),('D_answer',retrieval.ANSWER_INSTRUCTION)]:
 messages=[{'role':'system','content':system},{'role':'user','content':canon({'question':task['question_en'],'contract':public})+'\nSOURCE PASSAGES:\n'}]
 r=next(x for x in mock_messages if x['id']==task['id']+'_'+suffix)
 assert messages==r['messages']
 rebuilt[r['id']]=messages
for record in mock_messages:
 payload=record['messages'][1]['content'].split('\nSOURCE PASSAGES:\n')[0]
 obj=json.loads(payload)
 contract=obj.get('contract',obj)
 assert contract['selection_policy']==task['selection_policy']
 assert obj.get('output_format',contract)['required_fields']==task['required_fields']
 assert definition['reference_query']not in payload and definition['original_query']not in payload and 'AGR-'not in payload
for bad in ['prose {"records":[],"abstain":true,"complete":false}','\x60\x60\x60json\n{"records":[],"abstain":true,"complete":false}\n\x60\x60\x60',
 '{"records":[{"resolutionId":"X"}],"abstain":true,"complete":false}','{"records":[],"abstain":false,"complete":false,"x":NaN}']:
 try:retrieval.parse_answer(bad)
 except (ValueError,TypeError,KeyError):pass
 else:raise AssertionError('strict retrieval parser accepted adversary')
assert retrieval.parse_answer('{"records":[],"abstain":true,"complete":false}')['abstain'] is True
sys.path.insert(0,str(E/'scoring'))
scorer=module(E/'scoring/original_scorer.py','audit_CQ024_scorer')
gold=[json.loads(x)for x in Path(cfg['cases'][task['id']]['actual_reference_rows']['path']).read_text().splitlines()]
assert len(gold)==len({r['resolutionId']for r in gold})==10
controls=[('self',gold,True),('reordered',list(reversed(gold)),True),('one_missing',gold[:-1],False),
 ('duplicate_for_missing',gold[:-1]+[gold[0]],False),('set_duplicate_existing',gold+[gold[0]],True),
 ('foreign',gold[:-1]+[{'resolutionId':'AUDIT-NONMEMBER'}],False),('numeric',[{'resolutionId':i}for i in range(10)],False),
 ('null',[{'resolutionId':None}for _ in gold],False),('missing_field',[{}for _ in gold],False),
 ('no_records',[],False),('extra_foreign',gold+[{'resolutionId':'AUDIT-NONMEMBER'}],False),
 ('extra_incidental_fields',[dict(r,content='AUDIT-INCIDENTAL')for r in gold],True)]
actual_controls=[]
for name,pred,exact in controls:
 score=scorer.score(definition,gold,pred,diagnostic=True)
 assert score['exact']is exact
 actual_controls.append({'case':name,'exact':score['exact'],'f1':score['f1']})
transport=module(E/'runtime/openrouter_client.py','audit_CQ024_transport_constants')
reservation=[]
for r in mock_messages:
 chars=sum(len(m['content'])for m in r['messages'])
 max_context=retrieval.PROTOCOL['total_context_characters']if r['id'].endswith(('C_answer','D_followup','D_answer'))else 0
 estimate=((chars+max_context)/3.0*transport.PROMPT_USD_PER_TOKEN+r['max_tokens']*transport.COMPLETION_USD_PER_TOKEN)*2
 reservation.append({'request_id':r['id'],'base_prompt_characters':chars,'max_added_passage_characters':max_context,'max_tokens':r['max_tokens'],'maximum_two_attempt_reservation_estimate_usd':estimate})
estimate_sum=sum(r['maximum_two_attempt_reservation_estimate_usd']for r in reservation)
assert estimate_sum<cfg['budget_usd']
root_budget=load(E/'actual_root_gates/actual_static_budget_reservation_check.json')
runner_source=(E/'run_separate_CQ024_experiment.py').read_text();tree=ast.parse(runner_source)
functions={x.name:x for x in tree.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
execute_source=ast.get_source_segment(runner_source,functions['execute_cypher'])
assert execute_source.index('inspect(False)')<execute_source.index("command('docker', 'start'")<execute_source.index('inspect(True)')
assert "assert clean == query" in execute_source and "READ_ACCESS" in execute_source
assert "host_available()"in execute_source and "26 * GIB"in execute_source and "16 * GIB"in execute_source
assert "max_transaction_retry_time=0"in execute_source and "require_read_plan"in execute_source
assert "tx.rollback()"in execute_source and "finally:\n                    command('docker', 'stop'"in execute_source
assert "inspect(False)"in execute_source[execute_source.index("command('docker', 'stop'"):]
freeze_source=ast.get_source_segment(runner_source,functions['freeze'])
assert "interpreter_preflight(cfg)"in freeze_source and "physical.validate"in freeze_source
assert "cfg['additional_evidence_files']"in freeze_source and "cfg['scoring_files']"in freeze_source
assert "not out.exists()"in freeze_source
calls_source=ast.get_source_segment(runner_source,functions['calls'])
assert "verify_freeze(cfg, config_path)"in calls_source and "ThreadPoolExecutor(max_workers=4)"in calls_source
assert "assert not trial.exists()"in calls_source and "credentials.secret" in calls_source
guard=(E/'runtime/container_stage_guard.py').read_text()
assert "MemorySwap') != 2 * 1024**3"in guard and "expected_running" in guard
assert not blocked
files=sorted(set(small_pins+[config_path,E/'run_separate_CQ024_experiment.py',E/'public_tasks.json',E/'sql_schema.json',
 E/'graph_schema.json',E/'prospective_preparation.json',E/'actual_complete_physical_SQL_schema_build.json',
 E/'actual_root_gates/actual_static_budget_reservation_check.json',*sorted((E/'runtime').glob('*.py'))]))
receipt={
 'status':'PASS_INDEPENDENT_FINAL_PRECALL_AUDIT_NO_BLOCKER_IDENTIFIED',
 'cohort':cfg['cohort'],'configuration':pin(config_path),
 'scope':'Final root copy/config pins and small saved gates statically checked; actual current code prompt builders, strict parser and pure scorer run. No model/DB/FTS/native operations.',
 'N_per_method':1,'maximum_normal_request_stages':5,'methods':['Text2Cypher','Text2SQL','C','D'],
 'stage_branch_limit':'D answer is reached only after a successful strictly parsed followup; failures remain in the four-item denominator. One identical transport retry is not a quality retry.',
 'five_gate_classes_all_pins_and_assertions_verified':True,'distinct_small_input_files_checked':len(files),
 'native_source_SQL_review_receipt':pin(O/'RAN2_RAN5/source_lane13/CQ024_actual_native_SQL_source_gate_independent_audit_v1/actual_saved_native_SQL_source_and_two_reviews_audit.json'),
 'whole_source_link':{'TTL_sha256':cfg['TTL_input']['sha256'],'SQL_sha256':cfg['SQL_input']['sha256'],'FTS_sha256':cfg['FTS_input']['sha256'],'nodes':165418,'edges':848230,'FTS_chunks':257130,
 'root_saved_generic_full_reconstruction_and_source_hashes_match':True,
 'large_file_bytes_rehashed_by_this_audit':False,'root_freeze_will_revalidate_large_pins':True},
 'common_contract':{'all5_prompt_builds_exact_match_recorded_mock':True,'original_EN_preserved':True,'one_typed_resolutionId_field':True,
 'selection':task['selection_policy'],'no_reference_query_gold_ID_prefix_or_review_in_prompts':True,
 'physical_DDL_visible_tables':88,'physical_relationship_tables':55,'DDL_shape_and_saved_DB_hash_interface_consistent':True},
 'execution_controls':{'same_real_interpreter_preflight':interpreter,'native_owned_identity_and_source_bindings_match_capture':True,
 'stopped_before_start_running_after_start_stop_finally_and_stopped_after':True,'MemorySwap_2GiB_CPU1_loopback':True,
 'host_start26GiB_running16GiB':True,'query_unchanged_readplan_fullconsume_rollback':True,
 'first_trial_only_noquality_regeneration_and_freeze_revalidation':True,'unknown_cost_global_halt_preserved':True},
 'strict_parser_adversarial_checks':4,'pure_ID_set_scorer_controls':actual_controls,
 'budget':{'guard_usd':cfg['budget_usd'],'maximum_two_attempt_estimate_usd':estimate_sum,'by_stage':reservation,
 'all_five_stage_max_passages_fit_approximate_guard':True,
 'root_observation':pin(E/'actual_root_gates/actual_static_budget_reservation_check.json'),
 'not_actual_cost_not_provider_billing_cap_not_current_account_balance':True},
 'original560_admission_delta':0,'human_expert_validation_n':0,'reviewer':'independent secondary nonblind AI',
 'actions':{'paid_model_calls':0,'native_calls':0,'SQL_connections':0,'FTS_reads':0,'network_or_process_calls':0,
 'central_public_runtime_or_source_mutations':0,'audit_hook_denied_events':blocked},
 'limits':['Saved root wholegraph/SQL/FTS executions are pin-checked, not rerun by this reviewer.',
 'All497 native four-column rows/494unique IDs and below-cutoff multiplicity were audited separately.',
 'Shared facts do not establish equal interface exposure, complete retrieval, or causal superiority.',
 'This is a separate prospective N1 cohort and changes original560 admissions by0.',
 'Freeze and first paid calls remain ROOT actions after this audit; later evidence-only pin additions require ROOT final configuration/hash verification.'],
 'pinned_small_inputs':[pin(p)for p in files],'audit_script':pin(Path(__file__))}
out=OUT/'actual_final_configuration_runtime_and_budget_independent_precall_audit.json'
with out.open('x')as f:json.dump(receipt,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(pin(out),ensure_ascii=False))

