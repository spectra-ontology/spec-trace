# CQ024 saved first-five evaluation replay

This separate source-enriched one-question cohort adds zero original560 admissions. Each method has N=1. All four methods have complete-record F1=0 and exact=0: Text2Cypher returns one incorrect ID, Text2SQL returns zero rows, and both retrieval methods fail the unchanged strict whole-response JSON parser. A true abstain value inside D's unaccepted JSON suffix is not a valid model abstention. Every failure stays in its denominator; no prose/fenced recovery or answer replacement is scored.

Five first-attempt HTTP200 calls cost provider-reported Decimal $0.463310, with zero quality or transport retries. Expert validation N=0. No new provider calls are made by this replay, and this cohort is not pooled with original560 or other source cohorts.

```sh
python3 -B -I verify_saved_outputs.py --source-evidence ../original_core_source_RAN1_CQ024_capture2
```

The verifier checks a closed immutable inventory, the exact external source-v4 manifest and all53 listed files (54 including its manifest), 54 relocated pre-call pins (12 shared+42 evaluation-only), all5 exact prompts, saved request/response/usage identities and Decimal cost, unchanged generated query bytes, strict parsers, ten saved reference ID records and all four actual scores. The original pre-call freeze has57 entries; exactly3 large derived TTL/SQL/FTS files remain omitted with their pins. Historical paths are provenance only, with no host fallback.

The full matching pool consists of497 four-column records and494 unique resolution IDs, while the selected ten IDs are unique. These are not497 distinct agreements. Source checks and finite prefix/ownership/negation-recognizer limitations are documented separately in the source package. This replay checks saved execution outcomes without opening a database, executing queries/retrieval, starting containers or using the network. Native raw plan/query_type objects were not separately saved; frozen read guards and saved rollback/start-stop evidence are retained without claiming the missing objects exist. Original failed mock-harness outputs and their corrected successor are both preserved.

Shared underlying facts do not establish equal model exposure, complete retrieval or causal superiority. Recorded CR references identify requested specification targets rather than proving actual technical effects, approval or normative incorporation.
