#!/usr/bin/env python3
"""Mock five-stage contract wiring and synthetic ID-set controls; no real source answers."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
OUT=H/'actual_common_contract_and_ID_set_controls';OUT.mkdir()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def save(n,x):(OUT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
s=load(H/'runtime/structured_adapter.py','CQ024_controls_structured');r=load(H/'runtime/retrieval_adapter.py','CQ024_controls_retrieval');run=load(H/'run_separate_CQ024_experiment.py','CQ024_controls_runner')
task=json.loads((H/'public_tasks.json').read_text())[0];prep=json.loads((H/'prospective_preparation.json').read_text())
assert [f['name']for f in task['required_fields']]==['resolutionId'];assert task['collection']=={'kind':'set'}
class Caller:
 def __init__(self):self.calls=[]
 def call(self,ident,messages,max_tokens):
  self.calls.append({'id':ident,'messages':copy.deepcopy(messages),'max_tokens':max_tokens})
  content='{"query":"CONTROL GENERIC FOLLOWUP"}'if ident.endswith('_D_followup')else('{"query":"","abstain":true}'if ident.endswith(('Text2SQL','Text2Cypher'))else'{"records":[],"abstain":true,"complete":false}')
  return {'ok':True,'finish_reason':'stop','content':content,'usage':{},'provider':'MOCK_NO_NETWORK','model':'MOCK'}
caller=Caller()
for method in ['Text2Cypher','Text2SQL']:
 result=s.evaluate(run.task(task['id'],method),method,caller,OUT/'mock_five_stages',sql_input=prep['SQL_input']);assert result['status']=='ABSTAIN'
# Corpus unavailable until the source builder completes. These mocks assert prompt
# wiring only and do not imply an existing FTS inventory or source search result.
r.prepare_corpus_inventory=lambda *a,**kw:{'status':'MOCK_EMPTY_INVENTORY_NOT_ACTUAL_FTS','shards':[]}
r.retrieve=lambda *a,**kw:{'status':'MOCK_EMPTY_RETRIEVAL','context_candidate_truncated':False,'hits':[]}
r.contexts=lambda *a,**kw:([],{'document_selection_truncated':False,'characters':0,'utf8_bytes':0,'whitespace_terms':0})
for method in ['C','D']:
 result=r.evaluate(task,method,caller,OUT/'mock_five_stages');assert result['status']=='abstained'
assert len(caller.calls)==5
for call in caller.calls:
 payload=json.loads(call['messages'][1]['content'].split('\nSOURCE PASSAGES:\n',1)[0]);contract=payload.get('contract',payload.get('output_format'));policy=payload.get('selection_policy',contract.get('selection_policy'))
 assert payload['question']==task['question_en'];assert contract['required_fields']==task['required_fields'];assert policy==task['selection_policy']
 for forbidden in ['reference_query','gold','native_rows','primary_review','secondary_review','raw_source']:
  assert forbidden not in payload
save('actual_mock_five_stage_messages.json',caller.calls)
private_rejections=[]
for key in sorted(s.FORBIDDEN_INPUT):
 rejected=False
 try:s.messages_for(dict(run.task(task['id'],'Text2Cypher'),**{key:'CONTROL_FORBIDDEN'}),'Text2Cypher')
 except ValueError:rejected=True
 assert rejected,key;private_rejections.append(key)
sys.path.insert(0,str(H/'scoring'));sc=load(H/'scoring/original_scorer.py','CQ024_IDset_scoring')
definition=json.loads(Path(prep['definition']['path']).read_text());truth=[{'resolutionId':f'CONTROL-AGR-{i:02d}'}for i in range(10)]
fixtures=[('exact',truth,True),('reverse_set_serialization',list(reversed(truth)),True),('missing_one',truth[:-1],False),('wrong_ID',truth[:-1]+[{'resolutionId':'CONTROL-WRONG'}],False),('duplicate_instead_of_missing',truth[:-1]+[truth[0]],False),('numeric_ID',[dict(x,resolutionId=i)for i,x in enumerate(truth)],False),('null_ID',[dict(x,resolutionId=None)for x in truth],False),('missing_ID_field',[{}for x in truth],False),('empty',[],False),('extra_nonmember',truth+[{'resolutionId':'CONTROL-EXTRA'}],False),('incidental_extra_fields',[dict(x,content='CONTROL-NOT-REQUESTED')for x in truth],True)]
scores=[]
for title,pred,exact in fixtures:
 value=sc.score(definition,truth,pred,diagnostic=True);assert value['exact'] is exact,(title,value)
 if title in ['numeric_ID','null_ID','missing_ID_field','empty']:assert value['f1']==0
 scores.append({'case':title,'expected_exact':exact,'score':value})
save('actual_synthetic_ID_set_scoring_controls.json',{'status':'PASS','controls':scores,'synthetic_values_only':True,'actual_reference_or_answers_read':False})
configpath=H/'root_configuration_TEMPLATE_INCOMPLETE_DO_NOT_EXECUTE.json';blocked=False
try:run.config(configpath)
except AssertionError:blocked=True
assert blocked
cfg=json.loads(configpath.read_text());assert run.interpreter_preflight(cfg)['GraphDatabase_import_available'];wrong=False
try:run.interpreter_preflight(dict(cfg,execution_interpreter='/NOT_CURRENT_INTERPRETER'))
except AssertionError:wrong=True
assert wrong
save('receipt.json',{'status':'PASS_MOCK_SELECTION_AND_SYNTHETIC_IDSET_ONLY','common_selection_contract_all_five_mock_stages':True,'mock_transport_stages':5,'synthetic_ID_set_scoring_controls':len(scores),'private_generator_field_rejections':private_rejections,'incomplete_root_configuration_rejected':True,'mismatched_interpreter_rejected':True,'actual_FTS_inventory_tested':False,'actual_reference_rows_read':False,'paid_calls':0,'native_calls':0,'source_SQL_reads':'read-only physical DDL validation only','human_experts':0,'original560_admission_delta':0})
print(json.dumps({'status':'PASS_MOCK_SELECTION_AND_SYNTHETIC_IDSET_ONLY','stages':5,'synthetic_controls':len(scores),'private_field_rejections':len(private_rejections),'paid_calls':0,'native_calls':0}))
