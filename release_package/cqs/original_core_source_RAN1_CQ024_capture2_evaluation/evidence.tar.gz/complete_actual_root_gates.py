#!/usr/bin/env python3
"""Bind actual saved source, native and SQL results before the first paid trial."""
from pathlib import Path
from datetime import datetime, timezone
import copy
import hashlib
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
O = HERE.parent
Q = O / 'priority71_fast_closure/CQ024_original_frozen_plus_generic_capture2_v1'
N = O / 'root_RAN1_CQ024_capture2_native_v1'
OUT = HERE / 'actual_root_gates'


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def pin(path):
    path = Path(path).resolve(strict=True)
    return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def gate(path, values):
    return dict(pin(path), assertions=[{'key_path': list(keys), 'equals': value} for keys, value in values])


def main():
    OUT.mkdir()
    cfg = read(HERE / 'root_configuration_TEMPLATE_INCOMPLETE_DO_NOT_EXECUTE.json')
    native_path = N / 'actual_native_manifest.json'
    native = read(native_path)
    assert native['status'] == 'ACTUAL_NATIVE_FULL165418_848230_AND_EXACT_CALENDAR_REFERENCE_EQUAL_SQL'
    assert native['owned_container_stopped'] is True
    capture_path = N / 'actual_native_four_column_source_capture.json'
    assert sha(capture_path) == native['capture']['sha256']
    capture = read(capture_path)
    sql_path = N / 'actual_immutable_SQL_four_column_reference.json'
    sql = read(sql_path)
    for kind, count in [('selected', 10), ('whole_matching_pool', 497)]:
        actual = capture[kind]
        assert actual['rows'] == sql['rows'][kind]
        assert len(actual['rows']) == actual['row_n'] == count
        assert actual['complete'] is True and actual['truncated'] is False
        assert actual['contains_updates'] is False and actual['transaction_rolled_back'] is True
        assert actual['actual_query_type'] == actual['EXPLAIN_query_type'] == 'r'
        assert actual['columns'] == ['agr.resolutionId', 'content', 'm.meetingNumber', 'm.meetingNumberInt']
    rows_path = N / 'requested_resolutionId_records.jsonl'
    records = [json.loads(line) for line in rows_path.read_text().splitlines() if line]
    assert len(records) == 10
    assert records == [{'resolutionId': row[0]} for row in capture['selected']['rows']]
    save(OUT / 'actual_independent_SQL_ordered_comparison.json', {
        'status': 'PASS', 'native_capture': pin(capture_path), 'independent_SQL_reference': pin(sql_path),
        'all_four_columns_and_order_equal': True, 'selected_rows': 10, 'whole_matching_pool_rows': 497,
        'whole_matching_pool_unique_resolutionIds': len({row[0] for row in capture['whole_matching_pool']['rows']}),
        'pool_units': 'Returned four-column records; multiple meeting labels can repeat one Agreement ID below the selected prefix.',
        'all_native_read_transactions_rolled_back': True, 'requested_JSONL_exact_native_projection': True,
        'new_native_calls': 0, 'model_API_calls': 0,
    })
    sys.path.insert(0, str(HERE / 'scoring'))
    scorer = module(HERE / 'scoring/original_scorer.py', 'CQ024_actual_root_scoring')
    definition = read(cfg['cases']['RAN1_P3_CQ024']['definition']['path'])
    gold = copy.deepcopy(records)
    assert len({r['resolutionId'] for r in gold}) == 10
    fixtures = [
        ('exact_native', gold, True),
        ('reverse_set_serialization', list(reversed(gold)), True),
        ('missing_one', gold[:-1], False),
        ('wrong_ID', gold[:-1] + [{'resolutionId': 'CONTROL-NONMEMBER'}], False),
        ('duplicate_instead_of_missing', gold[:-1] + [gold[0]], False),
        ('numeric_ID', [{'resolutionId': i} for i in range(10)], False),
        ('null_ID', [{'resolutionId': None} for _ in gold], False),
        ('missing_ID_field', [{} for _ in gold], False),
        ('empty_failure', [], False),
        ('extra_nonmember', gold + [{'resolutionId': 'CONTROL-NONMEMBER'}], False),
        ('incidental_extra_fields', [dict(row, content='CONTROL-NOT-REQUESTED') for row in gold], True),
    ]
    results = []
    for name, prediction, expected in fixtures:
        value = scorer.score(definition, gold, prediction, diagnostic=True)
        assert value['exact'] is expected, (name, value)
        if name in {'numeric_ID', 'null_ID', 'missing_ID_field', 'empty_failure'}:
            assert value['f1'] == 0
        results.append({'case': name, 'expected_exact': expected, 'score': value})
    fields = [{'name': 'left', 'type': 'string', 'nullable': False},
              {'name': 'right', 'type': 'integer', 'nullable': False}]
    generic = {'required_fields': fields, 'collection': {'kind': 'set'}, 'cardinality_policy': {'mode': 'all'}}
    generic_cases = [
        ('required_value', generic, [{'left': 'A', 'right': 1}], [{'left': 'A', 'right': 2}], False),
        ('required_field', generic, [{'left': 'A', 'right': 1}], [{'left': 'A'}], False),
        ('numeric_string', generic, [{'left': 'A', 'right': 1}], [{'left': 'A', 'right': '1'}], False),
        ('boolean_not_integer', generic, [{'left': 'A', 'right': 1}], [{'left': 'A', 'right': True}], False),
        ('multiset_multiplicity', dict(generic, collection={'kind': 'multiset'}),
         [{'left': 'A', 'right': 1}] * 2, [{'left': 'A', 'right': 1}], False),
        ('set_duplicates', generic, [{'left': 'A', 'right': 1}], [{'left': 'A', 'right': 1}] * 2, True),
        ('field_roles', dict(generic, required_fields=[dict(f, type='string') for f in fields]),
         [{'left': 'A', 'right': 'B'}], [{'left': 'B', 'right': 'A'}], False),
    ]
    generic_results = []
    for name, contract, truth, pred, expected in generic_cases:
        value = scorer.score(contract, truth, pred, diagnostic=True)
        assert value['exact'] is expected, (name, value)
        generic_results.append({'case': name, 'expected_exact': expected, 'score': value})
    mock_path = HERE / 'actual_common_contract_and_ID_set_controls_v2/receipt.json'
    mock = read(mock_path)
    assert mock['common_selection_contract_all_five_mock_stages'] is True
    assert mock['mock_transport_stages'] == 5 and mock['paid_calls'] == 0
    retrieval = module(HERE / 'runtime/retrieval_adapter.py', 'CQ024_actual_root_inventory')
    inventory = retrieval.prepare_corpus_inventory(OUT / 'actual_inventory')
    assert len(inventory['shards']) == 1
    shard = inventory['shards'][0]
    assert shard['WG'] == 'RAN1'
    assert shard['sha256'] == '467b991e41b9889e42cca631b0daba1c4ac5bcc5beec1df8fcda2700dad9d047'
    save(OUT / 'actual_scoring_and_common_contract_controls.json', {
        'status': 'PASS', 'actual_native_ID_set_controls': results,
        'actual_native_ID_set_control_count': len(results), 'generic_typed_controls': generic_results,
        'generic_typed_control_count': len(generic_results), 'upstream_actual_five_mock_stage_receipt': pin(mock_path),
        'common_selection_contract_all_five_mock_stages': True, 'mock_transport_stages': 5,
        'actual_FTS_inventory_hash_verified': True, 'actual_FTS_inventory': pin(OUT / 'actual_inventory/retrieval_corpus_inventory.json'),
        'paid_calls': 0, 'new_native_calls': 0, 'human_experts': 0, 'original560_admission_delta': 0,
    })
    fact_path = Q / 'actual_corpus/all_fact_reconstruction_receipt.json'
    facts = read(fact_path)
    assert facts['status'] == 'PASS'
    assert facts['every_TTL_node_label_property_equal'] and facts['every_directed_TTL_edge_equal']
    assert (facts['nodes_reconstructed'], facts['edges_reconstructed'], facts['chunks_reconstructed']) == (165418, 848230, 257130)
    assert facts['immutable_database_sha256'] == shard['sha256']
    assert facts['fact_source_sha256'] == cfg['TTL_input']['sha256']
    cfg['ready_for_root_review'] = True
    cfg['budget_usd'] = 3.0
    cfg['trial_directory'] = str(HERE / 'actual_call_trial_v1')
    cfg['FTS_input']['sha256'] = shard['sha256']
    cfg['cases']['RAN1_P3_CQ024']['actual_reference_rows'] = dict(pin(rows_path), provenance='actual_owned_native_capture')
    secondary = next(Path(p['path']) for p in cfg['additional_evidence_files'] if Path(p['path']).name == 'independent_secondary_exact_seven_unit_source_context_review.json')
    cfg['gate_receipts'] = {
        'whole_native_reference_capture': gate(native_path, [(('status',), native['status']), (('selected_rows',), 10), (('whole_matching_pool_rows',), 497), (('owned_container_stopped',), True)]),
        'whole_independent_SQL_agreement': gate(OUT / 'actual_independent_SQL_ordered_comparison.json', [(('status',), 'PASS'), (('all_four_columns_and_order_equal',), True), (('whole_matching_pool_rows',), 497)]),
        'independent_second_seven_unit_semantics': gate(secondary, [(('status',), 'pass'), (('repair_sha256',), '7c0122437095d695d0b13dd316463dd2df31f63c8dd41b88e64e090507c796b2'), (('original560_admissions',), 0), (('expert_validation_n',), 0)]),
        'generic_and_boundary_scoring_controls': gate(OUT / 'actual_scoring_and_common_contract_controls.json', [(('status',), 'PASS'), (('actual_native_ID_set_control_count',), 11), (('generic_typed_control_count',), 7), (('actual_FTS_inventory_hash_verified',), True), (('paid_calls',), 0)]),
        'whole_source_and_FTS_equivalence': gate(fact_path, [(('status',), 'PASS'), (('every_TTL_node_label_property_equal',), True), (('every_directed_TTL_edge_equal',), True), (('nodes_reconstructed',), 165418), (('edges_reconstructed',), 848230), (('chunks_reconstructed',), 257130)]),
    }
    cfg['native_manifest'] = pin(native_path)
    cfg['native_container'] = {'name': native['target']['container'], 'port': 57916,
        'bolt': native['target']['bolt'], 'run_uuid': native['run_uuid'],
        'source_sha256': native['source']['sha256'], 'image_id': native['image_id']}
    cfg['scoring_files'] = [pin(HERE / 'scoring' / Path(item['path']).name) for item in cfg['scoring_files']]
    additional = [Path(item['path']) for item in cfg['additional_evidence_files']]
    additional.extend([capture_path, sql_path, Q / 'final_materialization_and_FTS_handoff_manifest.json',
        Q / 'actual_source_valid11_calendar_prefix_independent_comparison.json', Q / 'guarded_build_receipt.json',
        Q / 'guarded_verify_receipt.json', Q / 'root_native_CQ024_capture2_prepared_v3.py',
        HERE / 'upstream_preparation_manifest.json', Path(__file__)])
    additional.extend(p for p in (HERE / 'actual_common_contract_and_ID_set_controls_v2').rglob('*') if p.is_file())
    additional.extend(p for p in OUT.rglob('*') if p.is_file())
    cfg['additional_evidence_files'] = [pin(path) for path in sorted(set(additional))]
    prep_path = HERE / 'prospective_preparation.json'
    prep = read(prep_path)
    original_prep = prep_path.read_bytes()
    with (HERE / 'prospective_preparation.upstream.json').open('xb') as stream:
        stream.write(original_prep)
    prep['FTS_input']['sha256'] = shard['sha256']
    prep['status'] = 'ROOT_ACTUAL_GATES_COMPLETED_NOT_YET_FROZEN_NO_NEW_CALLS'
    prep['outstanding_root_gates'] = ['independent final root configuration audit', 'pre-call freeze']
    prep_path.write_text(json.dumps(prep, ensure_ascii=False, indent=2) + '\n')
    save(HERE / 'root_preparation_amendment_receipt.json', {
        'status': 'ROOT_CONFIG_AND_ACTUAL_GATE_BINDINGS_ONLY_BEFORE_FIRST_API',
        'utc': datetime.now(timezone.utc).isoformat(), 'upstream_preparation': pin(HERE / 'prospective_preparation.upstream.json'),
        'completed_preparation': pin(prep_path), 'no_changes_to_definition_reviews_questions_adapters_or_scorers': True,
        'paid_calls': 0, 'original560_admission_delta': 0,
    })
    cfg['additional_evidence_files'].extend([pin(HERE / 'prospective_preparation.upstream.json'), pin(HERE / 'root_preparation_amendment_receipt.json')])
    save(HERE / 'root_configuration_final.json', cfg)
    print(json.dumps({'status': 'ACTUAL_ROOT_GATES_AND_CONFIG_READY_FOR_INDEPENDENT_REVIEW',
                      'configuration': pin(HERE / 'root_configuration_final.json'), 'paid_calls': 0}))


if __name__ == '__main__':
    main()
