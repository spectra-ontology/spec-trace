#!/usr/bin/env python3
"""ROOT-EXECUTION-ONLY draft: full original frozen RAN1 plus generic source2 edge restoration and literal four-column query capture."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import fcntl
import hashlib
import importlib.util
import json
import os
import resource
import socket
import sqlite3
import subprocess
import time
import uuid

HERE = Path(__file__).resolve().parent
O = HERE.parent.parent
BASE = O.parent.parent
ROOT = next(p for p in HERE.parents if (p / 'CLAUDE.md').exists())
PREP = HERE
FULL = PREP
SQLITE = PREP
PROOF = O / 'RAN1_RAN3_RAN4/loop140_generic_three_report_reference_capture_rule_NOT_ADMITTED'
WORK = O / 'root_RAN1_CQ024_capture2_native_v1'
LOADER = Path('/home/sihyeon/workspace/spectra-public/spec-trace/release_package/pipeline/load_released_kg.py')
HELPER = BASE.parent / 'pending_recheck/RAN2_pack110_enriched/load_enriched_ttl_neo4j.py'
NAME, PORT = 'kdd-db-source-ran1-cq024-audit-v1', 57916
GIB = 1024 ** 3


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def pin(path):
    return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}


def save(path, value):
    temp = path.with_suffix(path.suffix + '.pending')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temp.replace(path)


def command(*args):
    return subprocess.check_output(list(args), text=True).strip()


def inspect():
    return json.loads(command('docker', 'inspect', NAME))[0]


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def verify_manifest(folder, digest):
    assert sha(folder / 'manifest.json') == digest
    m = json.loads((folder / 'manifest.json').read_text())
    for name, expected in m['artifacts'].items():
        assert sha(folder / name) == expected, name


def main():
    assert not WORK.exists(), 'Preserve all prior attempts; never adopt an existing run'
    WORK.mkdir()
    assert sha(PREP/'actual_materialization_manifest.json')=='d64f1a83321a59d8b9c08fe6bf917aea591c27a20afd37eacff942184738f175'
    material=json.loads((PREP/'actual_materialization_manifest.json').read_text())
    assert material['status']=='PASS_ISOLATED_FULL_FROZEN_PLUS_SOURCE_GENERIC2_ONLY'
    assert (material['whole_nodes'],material['whole_directed_edges'])==(165418,848230)
    for name in ['source_TTL','source_SQL','base_TTL','base_SQL','source_delta_manifest','allfact_proof','new_SQL_reference','reference_query']:
        expected_pin=material[name];assert sha(Path(expected_pin['path']))==expected_pin['sha256'],name
    assert sha(PROOF/'generic_source_delta_manifest.json')=='f0fe4f4465bfd2d79d4eb8d93bc8dde95a334834549c4dca7a0f8411e131b239'
    assert sha(LOADER)=='9499ac120ea4fcf1c2707f6e3151e399530d9b4f43f5aec9d2d93040792d6e25'
    assert sha(HELPER)=='81713cdbdbd38ffe2a957b7d8f466f63483224c76f091f082abaf98c64c21c9b'
    semantics=O/'RAN1_RAN3_RAN4/loop139_CQ024_two_reference_edges_calendar_repair_semantic_proposal_NOT_ADMITTED'
    definition_path=semantics/'prospective_definition.json'
    assert sha(definition_path)=='2d563b6159f8ae2ae21e1cceefa154ba56ea4d9b5c60ed4e79591d133c7e3cbd'
    assert sha(semantics/'prospective_primary_exact_seven_unit_review.json')=='21551c521043d9d7ab0aab5f457c74109d8c0cdd44228ed545080c616c19de6f'
    secondary=O/'RAN2_RAN5/source_lane13/RAN1_CQ024_independent_secondary_semantic_and_raw_source_review_v1/independent_secondary_exact_seven_unit_source_context_review.json'
    assert sha(secondary)=='509cf51859eaf436e89f6501212a78103f0bbe92663adca50abb4da62c2450cd'
    assert sha(PREP/'actual_source_valid11_calendar_prefix_independent_comparison.json')=='37dd0d0f5aaa4507510e2db4dec85cb346b6312d5bd379511b725e22c266be05'
    from neo4j import GraphDatabase
    import neo4j
    save(WORK/'actual_real_interpreter_dependency_preflight.json',{'status':'PASS','interpreter':os.sys.executable,'isolated':os.sys.flags.isolated,'neo4j_version':neo4j.__version__,'neo4j_module_sha256':sha(Path(neo4j.__file__)),'driver_import_exercised':True})
    definition=json.loads(definition_path.read_text())
    snapshot=PREP/'RAN1-capture2-body.ttl';db=PREP/'RAN1-capture2.sqlite'
    assert sha(snapshot)==material['source_TTL']['sha256'] and sha(db)==material['source_SQL']['sha256']
    readonly=sqlite3.connect(db.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
    readonly.execute('PRAGMA query_only=ON')
    sql=(PREP/'reference_query.sql').read_text();q=definition['reference_query']
    assert q==(PREP/'reference_query.cypher').read_text() and q.endswith(' LIMIT 10') and sql.endswith(' LIMIT 10')
    queries={'selected':q,'whole_matching_pool':q.removesuffix(' LIMIT 10')}
    expected={name:[list(row)for row in readonly.execute(sql if name=='selected'else sql.removesuffix(' LIMIT 10'))]for name in queries}
    readonly.close()
    assert len(expected['selected'])==len({r[0]for r in expected['selected']})==10
    assert len(expected['whole_matching_pool'])==497
    independent=json.loads((PREP/'actual_new_full_SQL_calendar_reference.json').read_text())
    assert expected['selected']==independent['rows'] and expected['whole_matching_pool']==independent['complete_pool_rows']
    source_prefix=json.loads((PREP/'actual_source_valid11_calendar_prefix_independent_comparison.json').read_text())
    assert [{'resolutionId':r[0],'meetingNumber':r[2],'meetingNumberInt':r[3]}for r in expected['selected']]==source_prefix['exact_calendar_source_prefix10']
    save(WORK/'actual_immutable_SQL_four_column_reference.json',{'queries':queries,'SQL':sql,'rows':expected,'definition':pin(definition_path),'meaning':'Whole frozen graph plus exactly two generic source capture references; requested CR target path and source calendar recency, not normative incorporation or fresh acceptance.'})
    with (BASE / 'native_capture.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        windows = int(command('powershell.exe', '-NoProfile', '-Command', '(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory')) * 1024
        available = next(int(x.split()[1]) * 1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
        guard = {'linux_available_bytes': available, 'windows_available_bytes': windows,
                 'minimum_available_bytes': 26 * GIB, 'parser_budget_bytes': 8 * GIB,
                 'container_budget_bytes': 2 * GIB, 'reserve_bytes': 16 * GIB}
        save(WORK / 'actual_host_resource_guard.json', guard)
        assert min(windows, available) >= 26 * GIB, 'Preserved 26GiB host resource guard'
        active = command('docker', 'ps', '--format', '{{.Names}}').splitlines()
        assert not any(n.startswith('kdd-db-') for n in active), 'Another audit database is active'
        assert NAME not in command('docker', 'ps', '-a', '--format', '{{.Names}}').splitlines()
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', PORT))
        image_id = json.loads(command('docker', 'image', 'inspect', 'neo4j:5.26.0'))[0]['Id']
        run_id = str(uuid.uuid4())
        bolt = f'bolt://127.0.0.1:{PORT}'
        manifest = {'status': 'starting', 'created_utc': datetime.now(timezone.utc).isoformat(),
                    'run_uuid': run_id, 'snapshot_kind': 'Separate whole original frozen RAN1 plus exactly two source-derived generic REFERENCES; every old fact and property unchanged; original560 admissions0',
                    'source': pin(snapshot), 'db': pin(db), 'loader': pin(LOADER), 'helper': pin(HELPER),
                    'wrapper': pin(Path(__file__)), 'image_id': image_id, 'host_guard': guard,
                    'target': {'container': NAME, 'bolt': bolt, 'cpu': 1, 'memory_bytes': 2 * GIB, 'loopback_only': True},
                    'question_admissions': 0, 'new_model_calls': 0, 'expert_validation_n': 0}
        target_manifest = WORK / 'actual_native_manifest.json'
        save(target_manifest, manifest)
        helper = module(HELPER, 'root_RAN1_preserved_container_guard')
        started, created = time.monotonic(), False
        try:
            data = WORK / 'data'
            data.mkdir()
            command('docker', 'run', '--detach', '--pull=never', '--name', NAME, '--cpus=1', '--memory=2g', '--memory-swap=2g',
                    '--publish', f'127.0.0.1:{PORT}:7687', '--label', 'spectra.frozen.owner=contract_repair_v1',
                    '--label', f'spectra.frozen.run_uuid={run_id}', '--label', f"spectra.frozen.source_sha256={manifest['source']['sha256']}",
                    '--env', 'NEO4J_AUTH=none', '--env', 'NEO4J_server_memory_heap_initial__size=512m',
                    '--env', 'NEO4J_server_memory_heap_max__size=512m', '--env', 'NEO4J_server_memory_pagecache_size=256m',
                    '--volume', f'{data.resolve()}:/data', image_id)
            created = True
            helper.guard_container(inspect(), NAME, PORT, run_id, manifest['source']['sha256'])
            helper.wait_empty_database(bolt)
            resource.setrlimit(resource.RLIMIT_AS, (8 * GIB, 8 * GIB))
            os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
            loader = module(LOADER, 'root_RAN1_exact_public_loader')
            nodes, relations, stats = loader.parse_ttl(snapshot)
            assert len(nodes) == 165418 and len(relations) == 848230 and not stats['prop_conflicts']
            readonly=sqlite3.connect(db.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
            try:
                node_keys={}
                for node_id,source_iri,labels_json,properties_json in readonly.execute('SELECT node_id,source_iri,labels_json,properties_json FROM _node_record'):
                    match=loader.INST_RE.match(source_iri);assert match,source_iri
                    key=(match.group('cls'),match.group('nid'));node_keys[node_id]=key
                    assert nodes[key]['labels']==set(json.loads(labels_json)),source_iri
                    assert json.dumps(nodes[key]['props'],sort_keys=True,ensure_ascii=False,separators=(',',':'))==json.dumps(json.loads(properties_json),sort_keys=True,ensure_ascii=False,separators=(',',':')),source_iri
                assert len(node_keys)==len(nodes)==165418
                sql_edges={(node_keys[a],r,node_keys[b]) for a,r,b in readonly.execute('SELECT src_id,rel_type,dst_id FROM edge')}
                assert sql_edges==relations
                save(WORK/'actual_root_full_public_parse_vs_SQL_all_facts.json',{'status':'PASS','nodes':len(nodes),'directed_edges':len(relations),'full_native_property_dictionaries_and_labels_equal':True,'raw_source_IRI_used':True,'new_directed_REFERENCES':2,'old_node_properties_unchanged':True,'code':pin(Path(__file__))})
                del node_keys,sql_edges
            finally:readonly.close()
            inventory = {'nodes': len(nodes), 'relationships': len(relations), 'labels': dict(stats['class_subjects']),
                         'relations': {loader.decode_rel_type(k): v for k, v in stats['rel_pred_camel'].items()}}
            manifest['parse_inventory'] = inventory
            manifest['status'] = 'loading'
            save(target_manifest, manifest)
            helper.guard_container(inspect(), NAME, PORT, run_id, manifest['source']['sha256'])
            helper.wait_empty_database(bolt)
            counts = loader.load_neo4j(bolt, 'neo4j', '', nodes, relations, 2000)
            assert counts['total_nodes'] == inventory['nodes']
            assert counts['label_counts'] == inventory['labels'] and counts['rel_counts'] == inventory['relations']
            manifest['measured_counts'] = counts
            from neo4j import GraphDatabase
            driver = GraphDatabase.driver(bolt, auth=None, connection_timeout=10)
            captures = {}
            try:
                for name, q in queries.items():
                    helper.guard_container(inspect(), NAME, PORT, run_id, manifest['source']['sha256'])
                    with driver.session(default_access_mode='READ') as session:
                        tx = session.begin_transaction(timeout=90)
                        try:
                            plan_summary = tx.run('EXPLAIN ' + q).consume()
                            assert plan_summary.query_type == 'r' and not plan_summary.counters.contains_updates
                            result = tx.run(q)
                            columns = list(result.keys())
                            rows = [list(record.values()) for record in result]
                            summary = result.consume()
                            assert summary.query_type == 'r' and not summary.counters.contains_updates
                            assert columns == ['agr.resolutionId','content','m.meetingNumber','m.meetingNumberInt']
                            assert rows==expected[name], 'Native/SQL ordered all-four-column mismatch'
                            if name=='selected':assert len(rows)==len({r[0]for r in rows})==10
                            captures[name] = {'literal_query': q, 'columns': columns, 'rows': rows,
                                              'row_n': len(rows), 'EXPLAIN_query_type': plan_summary.query_type,
                                              'actual_query_type': summary.query_type, 'contains_updates': False,
                                              'complete': True, 'truncated': False, 'transaction_rolled_back': True}
                        finally:
                            tx.rollback()
            finally:
                driver.close()
            save(WORK / 'actual_native_four_column_source_capture.json', captures)
            assert sha(snapshot) == manifest['source']['sha256'] and sha(db) == manifest['db']['sha256']
            assert sha(ROOT / 'release_package/kg/per_wg/RAN1-body.ttl') == '9540683df5407bb3f8978ad4d05ddc7f7880f10c94f21273f588d737f145e231'
            manifest['status'] = 'ACTUAL_NATIVE_FULL165418_848230_AND_EXACT_CALENDAR_REFERENCE_EQUAL_SQL'
            manifest['selected_rows']=len(captures['selected']['rows'])
            manifest['whole_matching_pool_rows']=len(captures['whole_matching_pool']['rows'])
            manifest['capture']=pin(WORK/'actual_native_four_column_source_capture.json')
            with (WORK/'requested_resolutionId_records.jsonl').open('x') as stream:
                stream.write(''.join(json.dumps({'resolutionId':r[0]},ensure_ascii=False)+'\n' for r in captures['selected']['rows']))
            print(json.dumps({'status':manifest['status'],'selected':manifest['selected_rows'],'whole':manifest['whole_matching_pool_rows']}),flush=True)

        except BaseException as exc:
            manifest['status'] = 'FAILED_PRESERVED_FOR_DIAGNOSIS'
            manifest['error_type'], manifest['error'] = type(exc).__name__, str(exc)[:1000]
            raise
        finally:
            if created:
                helper.guard_container(inspect(), NAME, PORT, run_id, manifest['source']['sha256'])
                command('docker', 'stop', '--time', '20', NAME)
                assert not inspect()['State']['Running']
                manifest['owned_container_stopped'] = True
            manifest['elapsed_seconds'] = time.monotonic() - started
            manifest['max_rss_kib'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            manifest['updated_utc'] = datetime.now(timezone.utc).isoformat()
            save(target_manifest, manifest)


if __name__ == '__main__':
    main()
