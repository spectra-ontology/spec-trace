#!/usr/bin/env python3
"""Prospectively frozen N=1 common-graph-source experiment; no original admission."""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse
import fcntl
import hashlib
import importlib.util
import json
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
O = HERE.parent
B = O.parent.parent
ROOT = next(p for p in HERE.parents if (p / 'CLAUDE.md').exists())
PUBLIC = Path('/home/sihyeon/workspace/spectra-public/spec-trace/release_package/cqs')
P = O / 'priority71_fast_closure/RAN3_incoming38473_original10_tail_source_route_v1/full_base_clone_preparer_v1'
CG = O / 'priority71_fast_closure/RAN3_generic_fullgraph_retrieval_corpus_v1'
G = O / 'root_RAN3_source_variant_gate'
N = O / 'root_RAN3_source_variant_native_v1'
DB = P / 'root_actual_SQLite_v1/RAN3-source-enriched-full.sqlite'
TTL = P / 'actual_full_TTL_v4/RAN3-source-enriched-full.ttl'
CORPUS = CG / 'actual_corpus/ran3.sqlite3'
DEFINITION = P / 'exact_separate_source_variant_definition_NOT_ADMITTED.json'
HELPER = B.parent / 'pending_recheck/RAN2_pack110_enriched/load_enriched_ttl_neo4j.py'
READ_GUARD = PUBLIC / 'contract_repair_v1/replay_generated_read_queries.py'
AUDIT = O / 'priority71_fast_closure/RAN3_common_graph_source_pre_call_independent_audit_v1'
TRIAL = HERE / 'actual_call_trial_v1'
FREEZE = HERE / 'precall_freeze.json'
METHODS = ('Text2Cypher', 'Text2SQL', 'C', 'D')
BUDGET_USD = 2.0
GIB = 1024 ** 3


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as f:
        f.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def adapters():
    return (module(HERE / 'runtime/structured_adapter.py', 'R3_common_structured'),
            module(HERE / 'runtime/retrieval_adapter.py', 'R3_common_retrieval'))


def task(method):
    t = read(HERE / 'public_task.json')
    if method in METHODS[:2]:
        field = 'graph_schema' if method == 'Text2Cypher' else 'sql_schema'
        t[field] = read(HERE / (field + '.json'))
    return t


def verify_freeze():
    freeze = read(FREEZE)
    for item in freeze['pinned_files']:
        assert sha(item['path']) == item['sha256'], item['path']
    assert freeze['budget_guard_usd'] == BUDGET_USD
    assert freeze['source_controls_passed'] and freeze['original_public_count'] == 483
    return freeze


def freeze():
    assert not FREEZE.exists() and not TRIAL.exists()
    assert read(G / 'actual_root_fullgraph_FTS_SQL_independent_fact_equivalence.json')['nodes'] == 87980
    assert read(G / 'actual_root_fullgraph_FTS_SQL_independent_fact_equivalence.json')['directed_edges'] == 481500
    assert read(CG / 'actual_generic_controls/receipt.json')['controls_n'] == 13
    assert read(CG / 'actual_negative_fact_controls/receipt.json')['all_rejected']
    assert read(G / 'actual_root_identity_scorer_controls.json')['status'].startswith('PASS')
    audit = read(AUDIT / 'receipt_v4.json')
    assert audit['status'] == 'PASS' and all(row['passed'] for row in audit['checks'])
    for path, digest in audit['source_files_sha256'].items():
        assert sha(path) == digest, 'Independent precall audit input changed: ' + path
    d = read(DEFINITION)
    t = task('C')
    assert t['question_en'] == d['question_en'] and t['repair_sha256'] == d['repair_sha256']
    assert d['original_query'] == d['reference_query']
    assert sha(TTL) == '5fac3bb2adf9f8ea5ac632700a9bebaf9c753c90e388783f82ad10c6dface589'
    assert sha(DB) == '23efce9d74979e878679a685250279f05591db6b45dcec73175845b34add3bbe'
    assert sha(CORPUS) == '8be02dac296166639b0da96c0d3f7c965f02308613f691beca74bffd7ff90caf'
    s, r = adapters()
    prompt_checks = []
    for method in METHODS[:2]:
        messages = s.messages_for(task(method), method)
        user = json.loads(messages[1]['content'])
        assert user['question'] == t['question_en']
        assert user['selection_policy'] == t['selection_policy']
        assert user['output_format']['cardinality_policy']['value'] == 10
        prompt_checks.append({'method': method, 'messages_sha256': hashlib.sha256(canonical(messages).encode()).hexdigest()})
    contract = r.public_contract(t)
    assert contract['selection_policy'] == t['selection_policy'] and contract['cardinality_policy']['value'] == 10
    blocked = False
    try:
        s.messages_for(dict(task('Text2Cypher'), gold=[]), 'Text2Cypher')
    except ValueError:
        blocked = True
    assert blocked
    parser_cases = []
    for payload, valid in [
        ('{"records":[],"abstain":true,"complete":false}', True),
        ('{"records":[{"tdocNumber":"CONTROL"}],"abstain":false,"complete":false}', True),
        ('{"records":[],"abstain":true}', False),
        ('{"records":[{"tdocNumber":"CONTROL"}],"abstain":true,"complete":true}', False),
        ('{"records":[null],"abstain":false,"complete":true}', False),
        ('{"records":[],"abstain":false,"complete":NaN}', False),
    ]:
        ok = True
        try:
            r.parse_answer(payload)
        except (ValueError, TypeError):
            ok = False
        assert ok == valid
        parser_cases.append({'payload': payload, 'accepted': ok})
    save(HERE / 'actual_precall_prompt_and_parser_controls.json', {
        'utc': utc(), 'status': 'PASS', 'structured_prompts': prompt_checks,
        'retrieval_contract_same_selection': True, 'private_gold_input_rejected': blocked,
        'parser_cases': parser_cases, 'model_calls': 0,
        'source_pipeline_controls': '13 boundary cases and 4 internally repinned corruptions; independently reconstructed all87980 nodes/481500 edges/147393 chunks versus SQL.'})
    paths = [Path(__file__), DEFINITION, TTL, DB, CORPUS, HELPER, READ_GUARD,
             AUDIT / 'receipt_v4.json', AUDIT / 'independent_pre_call_audit.py',
             HERE / 'final_runtime_amendment_before_freeze.json',
             HERE / 'public_task.json', HERE / 'graph_schema.json', HERE / 'sql_schema.json',
             HERE / 'prospective_input_policy_and_preparation.json',
             HERE / 'actual_precall_prompt_and_parser_controls.json',
             P / 'primary_exact_separate_source_variant_seven_unit_review.json',
             G / 'actual_root_second_exact_seven_unit_source_variant_review.json',
             G / 'actual_root_identity_scorer_controls.json',
             G / 'actual_root_fullgraph_FTS_SQL_independent_fact_equivalence.json',
             N / 'actual_native_manifest.json', N / 'actual_native_original_two_column_capture.json',
             O / 'root_RAN3_affected_source_independent_review/actual_root_source_review.json',
             O / 'root_RAN3_affected_source_independent_review/actual_root_complete_universe_and_SQL_prefix_review.json',
             CG / 'manifest.json', CG / 'actual_generic_controls/receipt.json',
             CG / 'actual_negative_fact_controls/receipt.json',
             G / 'actual_public_OpenRouter_catalog_before_new_evaluation.json',
             PUBLIC / 'original_core_source_enriched_repair/scorer.py',
             PUBLIC / 'original_core_source_enriched_repair/typed_values.py',
             PUBLIC / 'original_core_source_enriched_repair/source_pins.json',
             PUBLIC / 'original_core_source_enriched_repair/criteria.json',
             PUBLIC / 'original_core_source_enriched_repair/review_schema.py']
    paths.extend(sorted((HERE / 'runtime').glob('*.py')))
    save(FREEZE, {
        'utc': utc(), 'status': 'FROZEN_BEFORE_ALL_NEW_PAID_CALLS',
        'experiment': 'Separate RAN3 one-question common-graph-source evaluation',
        'original_public_count': 483, 'original_public_admissions': 0,
        'source_enriched_question_id': t['id'], 'repair_sha256': t['repair_sha256'],
        'source_controls_passed': True, 'budget_guard_usd': BUDGET_USD,
        'estimated_continuation_credit_remaining_before_run_usd': 23.878525,
        'live_account_balance_verified': False,
        'methods': list(METHODS), 'expected_model_request_stages': 5,
        'retries': 'Only identical transport retry for429/5xx/network, at most1. Quality retry0. Do not regenerate partial/abstained/error results.',
        'model': 'anthropic/claude-opus-4.8', 'provider_only': 'Anthropic',
        'structured_max_tokens': 4096, 'retrieval_answer_max_tokens': 8192, 'followup_max_tokens': 1024,
        'input_change_from_historical_cohorts': 'Generic complete graph-source corpus; original authored value-free lexical DESC/LIMIT10 selection explicit in every method prompt. New protocol; never pooled with historical cohorts.',
        'interpretation_limits': 'Shared source facts do not imply equal exposure/cost/retrieval reach or causal database advantage. N=1; no human/expert validation. Not an original frozen-graph repair admission.',
        'scoring': 'Original required identity set, diagnostic=True for local not-admitted source variant. All four methods retained in denominator. Generation/execution/parse/truncation failures and abstentions score0; nonempty supported partial outputs retain set F1.',
        'pinned_files': [{'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size} for p in paths]})
    print(json.dumps({'status': 'FROZEN', 'sha256': sha(FREEZE), 'pinned_files': len(paths)}), flush=True)


def calls():
    verify_freeze()
    assert not TRIAL.exists(), 'No second trial or scientific regeneration'
    TRIAL.mkdir()
    s, r = adapters()
    r.prepare_corpus_inventory(TRIAL)
    sys.path.insert(0, str(ROOT / 'scripts/common/common'))
    import credentials
    client = module(HERE / 'runtime/openrouter_client.py', 'R3_common_transport')
    caller = client.OpenRouterCaller(TRIAL, api_key=credentials.secret('OPENROUTER_API_KEY'), budget_usd=BUDGET_USD)
    results = {}
    def work(method):
        return s.evaluate(task(method), method, caller, TRIAL) if method in METHODS[:2] else r.evaluate(task(method), method, caller, TRIAL)
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(work, m): m for m in METHODS}
        for future in as_completed(futures):
            method = futures[future]
            try:
                results[method] = future.result()
            except Exception as exc:
                # Preserve transport outcomes even if one adapter fails. No regeneration.
                results[method] = {'id': task(method)['id'], 'method': method, 'status': 'ADAPTER_EXCEPTION',
                                   'error_class': type(exc).__name__, 'records': [], 'abstain': True}
            print(json.dumps({'method': method, 'status': results[method]['status']}), flush=True)
    save(TRIAL / 'generated_before_execution.json', {'utc': utc(), 'freeze_sha256': sha(FREEZE), 'results': results,
        'usage': caller.summary_unlocked(), 'no_database_execution_during_generation': True})
    verify_freeze()
    print(json.dumps(caller.summary_unlocked()), flush=True)


def command(*args):
    return subprocess.check_output(list(args), text=True).strip()


def execute_cypher(query):
    """Use only the previously loaded, exactly owned source-variant container."""
    from neo4j import GraphDatabase, READ_ACCESS
    manifest = read(N / 'actual_native_manifest.json')
    name, port = manifest['target']['container'], 57913
    assert name == 'kdd-db-source-ran3-role2-audit-v1'
    assert manifest['image_id'] == 'sha256:3b9cf65b6cae8b166d5091969e80a5600028aa2e8676a45a925dcc15c379024e'
    helper = module(HELPER, 'R3_common_container_guard')
    guard = module(READ_GUARD, 'R3_common_query_guard')
    def inspect():
        info = json.loads(command('docker', 'inspect', name))[0]
        helper.guard_container(info, name, port, manifest['run_uuid'], manifest['source']['sha256'])
        assert info['Image'] == manifest['image_id']
        return info
    started = time.monotonic()
    rows, columns, size, phase = [], [], 0, 'query_screen'
    result = {'status': 'ERROR', 'rows': [], 'complete': False, 'truncated': False,
              'plan_query_type': None, 'execution_query_type': None, 'rollback_completed': False}
    clean = guard.screen_query(query)
    assert clean == query, 'Never rewrite generated query'
    with (B / 'native_capture.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        linux = next(int(x.split()[1]) * 1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
        windows = int(command('powershell.exe', '-NoProfile', '-Command', '(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory')) * 1024
        save(TRIAL / 'actual_generated_query_host_guard.json', {'utc': utc(), 'linux_available_bytes': linux,
             'windows_available_bytes': windows, 'minimum_available_bytes': 26 * GIB, 'reserve_bytes': 16 * GIB})
        assert min(linux, windows) >= 26 * GIB
        assert not any(n.startswith('kdd-db-') for n in command('docker', 'ps', '--format', '{{.Names}}').splitlines())
        assert not inspect()['State']['Running']
        begun = False
        try:
            command('docker', 'start', name)
            begun = True
            inspect()
            driver = GraphDatabase.driver(manifest['target']['bolt'], auth=None, connection_timeout=5, max_transaction_retry_time=0)
            try:
                deadline = time.monotonic() + 90
                while True:
                    try:
                        driver.verify_connectivity()
                        break
                    except Exception:
                        if time.monotonic() > deadline:
                            raise
                        time.sleep(1)
                with driver.session(database='neo4j', default_access_mode=READ_ACCESS, fetch_size=100) as session:
                    tx = session.begin_transaction(timeout=60)
                    try:
                        phase = 'inventory'
                        n = tx.run('MATCH (n) RETURN count(n) AS n').single()['n']
                        e = tx.run('MATCH ()-[r]->() RETURN count(r) AS n').single()['n']
                        assert (n, e) == (87980, 481500)
                        result['inventory_before'] = {'nodes': n, 'relationships': e}
                        phase = 'EXPLAIN'
                        plan = tx.run('EXPLAIN ' + clean).consume()
                        guard.require_read_plan(plan)
                        result['plan_query_type'] = plan.query_type
                        phase = 'execute'
                        cur = tx.run(clean)
                        columns = list(cur.keys())
                        assert len(columns) == len(set(columns)), 'Duplicate aliases'
                        status = 'OK'
                        for row in cur:
                            record = row.data()
                            added = len(canonical(record).encode()) + 1
                            if len(rows) == 100000:
                                status = 'ROW_CAP'
                                break
                            if size + added > 256 * 1024 * 1024:
                                status = 'BYTE_CAP'
                                break
                            rows.append(record)
                            size += added
                        if status == 'OK':
                            summary = cur.consume()
                            assert summary.query_type == 'r' and not summary.counters.contains_updates and not summary.counters.contains_system_updates
                            result.update(execution_query_type=summary.query_type, execution_summary_complete=True,
                                          contains_updates=False, contains_system_updates=False)
                        result.update(status=status, complete=status == 'OK', truncated=status in {'ROW_CAP', 'BYTE_CAP'})
                    finally:
                        tx.rollback()
                        result['rollback_completed'] = True
            finally:
                driver.close()
        except Exception as exc:
            result.update(status='ERROR', complete=False, error_class=type(exc).__name__, error_phase=phase)
        finally:
            if begun:
                inspect()
                command('docker', 'stop', '--time', '20', name)
                assert not inspect()['State']['Running']
                result['owned_container_stopped'] = True
    result.update(rows=rows, columns=columns, retained_json_bytes=size, elapsed_s=time.monotonic() - started,
                  row_cap=100000, byte_cap=256 * 1024 * 1024, timeout_s=60, source_variant_only=True)
    return result


def execute():
    verify_freeze()
    generated = read(TRIAL / 'generated_before_execution.json')
    assert not (TRIAL / 'executed_predictions.json').exists()
    save(TRIAL / 'before_execution_queries_frozen.json', {'utc': utc(),
         'generated_record_sha256': sha(TRIAL / 'generated_before_execution.json'),
         'queries': {m: generated['results'][m].get('query_sha256') for m in METHODS[:2]},
         'freeze_sha256': sha(FREEZE)})
    s, _ = adapters()
    results = generated['results']
    for method in METHODS[:2]:
        record = results[method]
        if record['status'] != 'QUERY_READY':
            continue
        query = record['generated_query']
        assert hashlib.sha256(query.encode()).hexdigest() == record['query_sha256']
        try:
            execution = execute_cypher(query) if method == 'Text2Cypher' else s.run_sql_query(
                DB, query, task(method)['required_fields'], expected_db_sha=sha(DB))
        except Exception as exc:
            execution = {'status': 'ERROR', 'complete': False, 'rows': [], 'error_class': type(exc).__name__}
        record.update(execution=execution, records=execution['rows'] if execution['complete'] else [],
                      abstain=not execution['complete'], status='OK' if execution['complete'] else 'EXECUTION_' + execution['status'])
    save(TRIAL / 'executed_predictions.json', {'utc': utc(), 'freeze_sha256': sha(FREEZE), 'results': results})
    verify_freeze()
    print(json.dumps({'status': 'EXECUTED', 'methods': {k: v['status'] for k, v in results.items()}}), flush=True)


def score():
    verify_freeze()
    data = read(TRIAL / 'executed_predictions.json')
    d = read(DEFINITION)
    captures = read(N / 'actual_native_original_two_column_capture.json')
    gold = [{'tdocNumber': row[0]} for row in captures['selected']['rows']]
    scorer = module(PUBLIC / 'original_core_source_enriched_repair/scorer.py', 'R3_common_diagnostic_scorer')
    results = []
    for method in METHODS:
        record = data['results'][method]
        valid = record['status'] in {'OK', 'ok', 'partial'} and not record.get('abstain', False)
        prediction = record.get('records', []) if valid else []
        raw = scorer.score(d, gold, prediction, diagnostic=True)
        if not valid:
            assert raw['f1'] == 0 and not raw['exact']
        results.append({'method': method, 'N': 1, 'status': record['status'], 'valid_answer': valid,
                        'self_reported_complete': record.get('self_reported_complete'), 'score': raw,
                        'answer_parse_error': record['status'] in {'GENERATION_FORMAT_ERROR', 'answer_parse_error', 'followup_parse_error'},
                        'abstention': bool(record.get('abstain')) or record['status'] in {'ABSTAIN', 'abstained'}})
    summary = {'utc': utc(), 'status': 'ACTUAL_N1_SEPARATE_SOURCE_EXPERIMENT_NOT_ORIGINAL_ADMISSION',
               'freeze_sha256': sha(FREEZE), 'definition_sha256': sha(DEFINITION), 'repair_sha256': d['repair_sha256'],
               'gold_rows': gold, 'methods': results, 'usage': read(TRIAL / 'usage.json'),
               'original_public_counts': {'verified': 483, 'clarification': 14, 'pending': 63, 'total': 560},
               'original_public_admissions': 0, 'new_separate_source_experiment_N': 1,
               'expert_validation_n': 0, 'independent_saved_output_review': 'PENDING',
               'interpretation': 'New graph-source corpus and explicit bounded-list selection protocol; do not pool with historical methods or original frozen-graph483. Shared facts do not establish equal exposure, equal costs, complete retrieval or causality.'}
    save(TRIAL / 'actual_results_summary.json', summary)
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=['freeze', 'calls', 'execute', 'score'])
    args = parser.parse_args()
    globals()[args.phase]()
