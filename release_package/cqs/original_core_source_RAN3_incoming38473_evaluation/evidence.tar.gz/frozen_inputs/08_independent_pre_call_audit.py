#!/usr/bin/env python3
"""Network-free audit of the new source experiment; never executes its phases."""
from pathlib import Path
from unittest.mock import patch
from datetime import datetime, timezone
import argparse
import ast
import hashlib
import importlib.util
import io
import json
import tempfile
import urllib.error

HERE = Path(__file__).resolve().parent
O = HERE.parent.parent
SOURCE = O / 'RAN3_common_graph_source_evaluation_v1'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Response:
    status = 200
    def __init__(self, obj=None, body=None):
        self.body = body if body is not None else json.dumps(obj).encode()
    def __enter__(self):
        return self
    def __exit__(self, *_):
        return False
    def read(self):
        return self.body


def good(cost=0.123):
    return {'model': 'anthropic/claude-opus-4.8', 'provider': 'Anthropic',
            'usage': {'cost': cost}, 'choices': [{'message': {'content': '{}'}, 'finish_reason': 'stop'}]}


def http(code, obj):
    return urllib.error.HTTPError('https://mock.invalid', code, 'mock', {}, io.BytesIO(json.dumps(obj).encode()))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--receipt', required=True)
    args = ap.parse_args()
    paths = [SOURCE / 'run_separate_source_experiment.py', SOURCE / 'public_task.json',
             SOURCE / 'graph_schema.json', SOURCE / 'sql_schema.json',
             *sorted((SOURCE / 'runtime').glob('*.py'))]
    before = {str(p): sha(p) for p in paths}
    checks = []
    def check(name, fn):
        try:
            detail = fn()
            checks.append({'name': name, 'passed': True, 'detail': detail})
        except Exception as exc:
            checks.append({'name': name, 'passed': False, 'error_class': type(exc).__name__, 'error': str(exc)})
    for p in paths:
        if p.suffix == '.py':
            ast.parse(p.read_text())
    client = load(SOURCE / 'runtime/openrouter_client.py', 'independent_mock_client')
    s = load(SOURCE / 'runtime/structured_adapter.py', 'independent_mock_structured')
    r = load(SOURCE / 'runtime/retrieval_adapter.py', 'independent_mock_retrieval')
    task = json.loads((SOURCE / 'public_task.json').read_text())
    def prompts():
        messages = []
        for method, schema_name in [('Text2Cypher', 'graph_schema'), ('Text2SQL', 'sql_schema')]:
            t = dict(task, **{schema_name: json.loads((SOURCE / (schema_name + '.json')).read_text())})
            m = s.messages_for(t, method)
            user = json.loads(m[1]['content'])
            assert set(user) == {'question', 'output_format', 'selection_policy', 'schema'}
            assert user['question'] == task['question_en'] and user['selection_policy'] == task['selection_policy']
            assert user['output_format']['required_fields'] == [{'name': 'tdocNumber', 'type': 'string', 'nullable': False}]
            assert user['output_format']['cardinality_policy'] == {'mode': 'exact', 'value': 10}
            assert not ({'reference_query','gold_rows','repair_sha256','repair_notes'} & set(user))
            messages.append({'stage': method, 'sha256': hashlib.sha256(json.dumps(m, sort_keys=True).encode()).hexdigest()})
        contract = r.public_contract(task)
        assert contract['selection_policy'] == task['selection_policy']
        assert contract['cardinality_policy'] == {'mode': 'exact', 'value': 10}
        assert contract['required_fields'] == [{'name': 'tdocNumber', 'type': 'string', 'nullable': False}]
        return {'structured': messages, 'retrieval_followup_and_both_answers_use_this_contract': contract}
    check('five_stage_public_contract_same_selection_no_private_fields', prompts)
    def transport(name, effects, expected_known, expected_unknown, expected_attempts, *, expect_ok=False):
        seen = []
        def fake(req, **kwargs):
            seen.append(req.data)
            value = effects[len(seen) - 1]
            if isinstance(value, Exception):
                raise value
            return value
        with tempfile.TemporaryDirectory(prefix='mock-only-', dir=HERE) as td:
            caller = client.OpenRouterCaller(td, api_key='independent_mock_key', budget_usd=100)
            with patch.object(client.urllib.request, 'urlopen', side_effect=fake), patch.object(client.time, 'sleep'):
                outcome = caller.call('mock_' + name, [{'role': 'user', 'content': 'CONTROL'}], max_tokens=10)
            summary = caller.summary_unlocked()
            assert len(seen) == expected_attempts, (len(seen), expected_attempts)
            assert len(set(seen)) <= 1, 'transport retry payload changed'
            assert abs(summary['known_actual_cost_usd'] - expected_known) < 1e-12, summary
            assert summary['unknown_cost_attempts'] == expected_unknown, summary
            assert summary['all_actual_costs_known'] == (expected_unknown == 0), summary
            assert outcome['ok'] == expect_ok, outcome
            assert len(list((Path(td) / 'calls').glob('*.outcome.json'))) == 1
            return {'summary': summary, 'attempts': len(seen), 'identical_transport_payloads': True,
                    'outcome_error': outcome.get('error')}
    cases = [
        ('known_http500_then_success', [http(500, {'usage': {'cost': .0123}}), Response(good(.123))], .1353, 0, 2, True),
        ('unknown_http500_then_success', [http(500, {'error': 'mock'}), Response(good(.123))], .123, 1, 2, True),
        ('two_network_failures', [OSError('mock'), OSError('mock')], 0, 2, 2, False),
        ('known_nonretry_http401', [http(401, {'usage': {'cost': .004}})], .004, 0, 1, False),
        ('malformed_choices_cost_retained', [Response(dict(good(.234), choices=[None]))], .234, 0, 1, False),
        ('malformed_message_cost_retained', [Response(dict(good(.345), choices=[{'message': None, 'finish_reason': 'stop'}]))], .345, 0, 1, False),
        ('raw_HTTP200_list_unknown_cost_retained', [Response([])], 0, 1, 1, False),
        ('choices_object_known_cost_retained', [Response(dict(good(.456), choices={'message': {'content': '{}'}}))], .456, 0, 1, False),
        ('invalid_usage_shape_recorded_unknown', [Response(dict(good(), usage=['not-a-usage-object']))], 0, 1, 1, True),
        ('invalid_json_one_response_unknown', [Response(body=b'not-json')], 0, 1, 1, False),
        ('negative_cost_unknown', [Response(good(-1))], 0, 1, 1, True),
        ('boolean_cost_unknown', [Response(good(True))], 0, 1, 1, True),
        ('nonfinite_cost_unknown', [Response(good(float('nan')))], 0, 1, 1, True),
    ]
    for name, effects, known, unknown, attempts, ok in cases:
        check(name, lambda n=name, e=effects, k=known, u=unknown, a=attempts, o=ok: transport(n,e,k,u,a,expect_ok=o))
    def unusual_finish():
        class Caller:
            def __init__(self, reason): self.reason = reason
            def call(self, *a, **kw):
                return {'ok': True, 'finish_reason': self.reason, 'content': '{"query":"RETURN 1 AS tdocNumber","abstain":false}'}
        states = {}
        for i, reason in enumerate([None, 'content_filter', 'error', 'length', 'max_tokens', 'stop']):
            with tempfile.TemporaryDirectory(prefix='mock-structured-', dir=HERE) as td:
                t = dict(task, graph_schema=json.loads((SOURCE / 'graph_schema.json').read_text()))
                state = s.evaluate(t, 'Text2Cypher', Caller(reason), td)['status']
                states[str(reason)] = state
                assert (state == 'QUERY_READY') == (reason == 'stop'), states
        return states
    check('structured_only_normal_stop_executes', unusual_finish)
    def budget():
        with tempfile.TemporaryDirectory(prefix='mock-budget-', dir=HERE) as td:
            caller = client.OpenRouterCaller(td, api_key='independent_mock_key', budget_usd=.000001)
            with patch.object(client.urllib.request, 'urlopen', side_effect=AssertionError('must not call')):
                outcome = caller.call('mock_budget', [{'role':'user','content':'CONTROL'}], max_tokens=10)
            assert not outcome['ok'] and outcome['error'] == 'frozen_budget_guard'
            return {'attempts': 0, 'rejected_before_request': True}
    check('budget_rejected_before_any_network_attempt', budget)
    after = {str(p): sha(p) for p in paths}
    check('audited_source_bytes_stable', lambda: (_ for _ in ()).throw(AssertionError('source changed during audit')) if after != before else True)
    runner = (SOURCE / 'run_separate_source_experiment.py').read_text()
    check('scorer_dynamic_dependencies_frozen', lambda: (_ for _ in ()).throw(AssertionError('typed_values/source_pins missing')) if not all(x in runner for x in ['typed_values.py','source_pins.json']) else True)
    result = {'utc': datetime.now(timezone.utc).isoformat(), 'status': 'PASS' if all(c['passed'] for c in checks) else 'ISSUES_REPORTED_TO_ROOT',
              'scope': 'Independent static code read plus network-free mocks only; no source corpus search, database execution, real API, freeze or public mutation.',
              'source_files_sha256': before, 'checks': checks, 'checks_n': len(checks),
              'real_model_calls': 0, 'real_database_executions': 0, 'expert_validation_n': 0,
              'original_graph_admissions': 0,
              'static_findings': {'private_query_or_gold_prompt_injection_observed': False,
                 'all_four_methods_kept_in_denominator': True,
                 'separate_N1_not_pooled_with_original483': True,
                 'native_READ_EXPLAIN_actual_query_type_rollback_owned_container_stop': 'present in directly read code; not executed by this audit',
                 'SQL_readonly_immutable_authorizer_and_caps': 'present in directly read code; not executed by this audit',
                 'actual_provider_cost_is_distinct_from_approximate_reservation': True}}
    target = Path(args.receipt)
    with target.open('x') as f:
        json.dump(result, f, ensure_ascii=False, indent=2, allow_nan=False); f.write('\n')
    print(json.dumps({'status': result['status'], 'checks_n': len(checks), 'failed': [c['name'] for c in checks if not c['passed']], 'receipt': str(target), 'sha256': sha(target)}))


if __name__ == '__main__':
    main()
