"""Offline saved-output replay; no API, source DB, native database or retrieval."""
import argparse
import ast
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

FREEZE = '2bd4c18378ef0c06a7db69b7eac293c6f5d1b3d9f253e36d5661c50dcad13f64'
PRIMARY = '1770549ecaa417af018de5df5121ce010508fa91aa46a126dc0ec2fc8081e6a5'
INVENTORY = 'df56249561190fe2977b05ef8df4a5e0ef5021b27a7bbc1e76e3bbe322e7c5ef'
sys.dont_write_bytecode = True


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def read(p):
    return json.loads(Path(p).read_text())


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False)


def module(path, name, offline_retrieval=False):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    if offline_retrieval:
        # The frozen module discovers a checkout and contains an old host path.
        # Skip only these unused environment assignments for saved-output replay.
        tree = ast.parse(Path(path).read_text(), filename=str(path))
        skipped = []
        kept = []
        for node in tree.body:
            names = [x.id for x in node.targets if isinstance(x, ast.Name)] if isinstance(node, ast.Assign) else []
            if names in (['ROOT'], ['CORPUS_DIR']):
                skipped.extend(names)
            else:
                kept.append(node)
        assert skipped == ['ROOT', 'CORPUS_DIR']
        tree.body = kept
        exec(compile(tree, str(path), 'exec'), result.__dict__)
    else:
        spec.loader.exec_module(result)
    return result


def verify(home):
    home = Path(home).resolve(strict=True)
    inventory_path = home/'frozen_evidence_inventory.json'
    assert sha(inventory_path) == INVENTORY
    inventory = read(inventory_path)
    assert inventory['scope'] == 'All included frozen evidence; portable verifier and this inventory excluded'
    seen = set()
    for entry in inventory['files']:
        relative = entry['path']
        assert relative not in seen
        seen.add(relative)
        path = (home/relative).resolve(strict=True)
        assert path.is_relative_to(home) and not (home/relative).is_symlink()
        assert path.stat().st_size == entry['bytes'] and sha(path) == entry['sha256']
    assert seen == {str(p.relative_to(home)) for p in home.rglob('*') if p.is_file()
                    and p.name not in {'verify_saved_outputs.py', 'frozen_evidence_inventory.json', 'README.md', 'manifest.json'}}
    freeze = read(home/'precall_freeze.json')
    assert sha(home/'precall_freeze.json') == FREEZE
    bridge = read(home/'frozen_path_bridge.json')
    assert bridge['original_freeze_sha256'] == FREEZE
    assert [{k: e[k] for k in ('path', 'sha256', 'bytes')} for e in bridge['entries']] == freeze['pinned_files']
    relocated = {}
    omitted = []
    for item in bridge['entries']:
        if not item['included']:
            omitted.append(item)
            continue
        path = (home/item['bundle_relative_path']).resolve(strict=True)
        assert path.is_relative_to(home)
        assert sha(path) == item['sha256'] and path.stat().st_size == item['bytes']
        relocated[item['path']] = path
    assert len(relocated) == 32 and len(omitted) == 3
    assert {Path(x['path']).name for x in omitted} == {
        'RAN3-source-enriched-full.ttl', 'RAN3-source-enriched-full.sqlite', 'ran3.sqlite3'}

    def locate(name):
        matches = [v for k, v in relocated.items() if Path(k).name == name]
        assert len(matches) == 1, name
        return matches[0]

    trial = home/'actual_call_trial_v1'
    assert sha(trial/'actual_results_summary.json') == PRIMARY
    summary = read(trial/'actual_results_summary.json')
    generated = read(trial/'generated_before_execution.json')
    executed = read(trial/'executed_predictions.json')
    queries = read(trial/'before_execution_queries_frozen.json')
    assert queries['generated_record_sha256'] == sha(trial/'generated_before_execution.json')
    assert generated['freeze_sha256'] == executed['freeze_sha256'] == queries['freeze_sha256'] == FREEZE
    structured = module(home/'runtime/structured_adapter.py', 'portable_frozen_structured')
    retrieval = module(home/'runtime/retrieval_adapter.py', 'portable_frozen_retrieval', offline_retrieval=True)
    scorer = module(home/'scorer/scorer.py', 'portable_frozen_scorer')
    task = read(home/'public_task.json')
    stages = ['Text2Cypher', 'Text2SQL', 'C_answer', 'D_followup', 'D_answer']
    assert len(list((trial/'calls').glob('*.request.json'))) == 5
    assert len(list((trial/'calls').glob('*.attempt*.response.json'))) == 5
    original_audit = read(home/'independent_first5_saved_output_readonly_audit_v1/actual_independent_first5_saved_output_audit.json')
    audit_calls = {x['stage']: x for x in original_audit['calls']}
    total = Decimal('0')
    for stage in stages:
        prefix = 'RAN3_P4_CQ2-3_'+stage
        req_path = trial/'calls'/(prefix+'.request.json')
        res_path = trial/'calls'/(prefix+'.attempt0.response.json')
        out_path = trial/'calls'/(prefix+'.outcome.json')
        req, res, out = read(req_path), read(res_path), read(out_path)
        for kind, path in [('request', req_path), ('response', res_path), ('outcome', out_path)]:
            assert sha(path) == audit_calls[stage][kind+'_sha256']
        payload, raw = req['payload'], res['response']
        choice = raw['choices'][0]
        content = choice['message']['content']
        assert req['authorization_header_omitted'] is True
        assert req['payload_sha256'] == hashlib.sha256(json.dumps(payload, ensure_ascii=False).encode()).hexdigest()
        assert res['attempt'] == 0 and res['http_status'] == 200 and out['ok']
        assert len(out['attempts']) == 1 and out['unknown_cost_attempts'] == 0
        assert content == out['content'] and raw['usage'] == out['usage']
        assert choice['finish_reason'] == out['finish_reason'] == 'stop'
        assert choice['native_finish_reason'] == 'end_turn'
        assert raw['model'] == payload['model'] == freeze['model']
        assert raw['provider'] == freeze['provider_only'] == 'Anthropic'
        assert payload['provider'] == {'only': ['Anthropic'], 'allow_fallbacks': False, 'require_parameters': True}
        assert payload['response_format'] == {'type': 'json_object'} and payload['reasoning']['enabled'] is False
        cost = json.loads(res_path.read_text(), parse_float=Decimal)['response']['usage']['cost']
        assert Decimal(str(out['known_actual_cost_usd'])) == cost
        total += cost
        if stage in stages[:2]:
            public = dict(task)
            key = 'graph_schema' if stage == 'Text2Cypher' else 'sql_schema'
            public[key] = read(home/(key+'.json'))
            assert payload['messages'] == structured.messages_for(public, stage)
            obj = json.loads(content)
            assert set(obj) == {'query', 'abstain'} and obj['abstain'] is False
            assert obj['query'] == generated['results'][stage]['generated_query'] == executed['results'][stage]['generated_query']
            assert hashlib.sha256(obj['query'].encode()).hexdigest() == queries['queries'][stage]
            assert generated['results'][stage]['abstain'] is False
        else:
            method = stage[0]
            name = 'initial_context.json' if stage == 'D_followup' else 'final_context.json'
            context = read(trial/'retrieval'/method/task['id']/name)
            for document in context['documents']:
                assert hashlib.sha256(document['formatted'].encode()).hexdigest() == document['formatted_sha256']
            passages = '\n\n'.join(x['formatted'] for x in context['documents'])
            instruction = retrieval.QUERY_INSTRUCTION if stage == 'D_followup' else retrieval.ANSWER_INSTRUCTION
            expected = [{'role': 'system', 'content': instruction}, {'role': 'user',
                'content': canonical({'question': task['question_en'], 'contract': retrieval.public_contract(task)})+'\nSOURCE PASSAGES:\n'+passages}]
            assert payload['messages'] == expected
            if stage == 'D_followup':
                assert json.loads(content) == {'query': 'AFFECTS_CORE_SPEC 38.473 CR'}
            else:
                try:
                    retrieval.parse_answer(content)
                except json.JSONDecodeError as exc:
                    assert exc.pos == 0
                else:
                    raise AssertionError('Frozen whole-content JSON parser must reject the saved prose/fenced answer')
    assert total == Decimal('0.383310')
    assert Decimal(str(read(trial/'usage.json')['known_actual_cost_usd'])) == total
    definition = read(locate('exact_separate_source_variant_definition_NOT_ADMITTED.json'))
    assert definition['repair_sha256'] == task['repair_sha256'] == summary['repair_sha256']
    native = read(home/'native/actual_native_original_two_column_capture.json')
    gold = [{'tdocNumber': row[0]} for row in native['selected']['rows']]
    assert gold == summary['gold_rows'] and len(gold) == 10
    for result in summary['methods']:
        prediction = executed['results'][result['method']]
        assert prediction['records'] == []
        assert scorer.score(definition, gold, [], diagnostic=True) == result['score']
        assert result['score']['f1'] == 0 and not result['valid_answer']
    for method, error_class in [('Text2Cypher', 'RuntimeError'), ('Text2SQL', 'OperationalError')]:
        prediction = executed['results'][method]
        assert prediction['status'] == 'EXECUTION_ERROR' and prediction['abstain'] is True
        assert prediction['execution']['status'] == 'ERROR' and prediction['execution']['complete'] is False
        assert prediction['execution']['rows'] == [] and prediction['execution']['error_class'] == error_class
    for method in ['C', 'D']:
        assert executed['results'][method]['status'] == 'answer_parse_error'
    infrastructure = read(home/'infrastructure_diagnostic/actual_replay_and_scores.json')
    assert infrastructure['primary_first_attempt_sha256'] == PRIMARY
    assert infrastructure['query'] == generated['results']['Text2Cypher']['generated_query']
    assert infrastructure['model_calls'] == infrastructure['query_changes'] == infrastructure['original_admissions'] == 0
    assert infrastructure['execution']['status'] == 'OK' and infrastructure['execution']['owned_container_stopped']
    assert infrastructure['score'] == scorer.score(definition, gold, infrastructure['execution']['rows'], diagnostic=True)
    assert infrastructure['score']['exact'] and infrastructure['score']['f1'] == 1
    physical = read(home/'posthoc_physical_interface/RAN3_actual_physical_value_free_schema.json')
    names = {x['name'] for x in physical['tables']}
    keys = read(home/'sql_schema.json')['relationship_tables']
    assert len(keys) == 45 and all(k not in names and 'rel_'+k in names for k in keys)
    assert scorer.score(definition, gold, gold, diagnostic=True)['exact']
    assert scorer.score(definition, gold, [{'tdocNumber': 260801}], diagnostic=True)['type_errors']
    return {'status': 'PASS_OFFLINE_INCLUDED_EVIDENCE_FIVE_PROMPTS_PRIMARY_AND_POSTHOC_DIAGNOSTIC',
            'included_pre_call_files_rehashed': len(relocated), 'large_derived_sources_not_opened': len(omitted),
            'saved_calls': 5, 'known_actual_cost_USD': str(total), 'primary_F1': [0, 0, 0, 0],
            'posthoc_infrastructure_only_Cypher_F1': 1, 'model_declared_abstentions': 0,
            'SQL_input_interface_contradiction': True, 'actual_model_calls': 0,
            'actual_native_operations': 0, 'generated_query_executions': 0,
            'included_frozen_evidence_files_rehashed': len(seen),
            'frozen_retrieval_environment_adaptation': 'AST skips only unused ROOT/CORPUS_DIR assignments; original source bytes preserved',
            'source_fact_reconstruction': 'Separate source recipe; not executed by this saved-output verifier',
            'original560_admissions': 0, 'human_expert_reviews': 0}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, default=Path(__file__).resolve().parent)
    print(json.dumps(verify(parser.parse_args().bundle), ensure_ascii=False, sort_keys=True))
