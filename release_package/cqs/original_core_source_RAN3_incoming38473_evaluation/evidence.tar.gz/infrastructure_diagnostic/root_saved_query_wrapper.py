#!/usr/bin/env python3
"""Posthoc infrastructure-only replay of exactly saved output; no new model calls."""
from pathlib import Path
import copy, fcntl, hashlib, importlib.util, json, subprocess, sys, time, argparse
HERE=Path(__file__).resolve().parent
E=HERE/'RAN3_common_graph_source_evaluation_v1'
OUT=HERE/'root_RAN3_saved_query_infrastructure_only_replay'
FROZEN=E/'run_separate_source_experiment.py'
spec=importlib.util.spec_from_file_location('frozen_R3_runner',FROZEN)
original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
N,HELPER,READ_GUARD,GIB,B=original.N,original.HELPER,original.READ_GUARD,original.GIB,original.B
read,save,sha,canonical,module,utc,command=(getattr(original,n) for n in ('read','save','sha','canonical','module','utc','command'))

def validate_owned_state(info, manifest, expected_running):
    assert info['Name']=='/'+manifest['target']['container']
    labels=info['Config'].get('Labels') or {}
    assert all(labels.get(k)==v for k,v in {
        'spectra.frozen.owner':'contract_repair_v1',
        'spectra.frozen.run_uuid':manifest['run_uuid'],
        'spectra.frozen.source_sha256':manifest['source']['sha256']}.items())
    assert info['Image']==manifest['image_id']
    host=info['HostConfig']
    assert host.get('Memory')==2*GIB and host.get('MemorySwap')==2*GIB
    assert host.get('NanoCpus')==10**9
    assert host.get('PortBindings')=={'7687/tcp':[{'HostIp':'127.0.0.1','HostPort':'57913'}]}
    assert info['State']['Running'] is expected_running
    assert not info['State'].get('Paused',False) and not info['State'].get('Restarting',False)

def controls():
    m=read(N/'actual_native_manifest.json')
    info=json.loads(command('docker','inspect',m['target']['container']))[0]
    validate_owned_state(info,m,False)
    cases=[]
    for field,value in [('running',True),('owner','OTHER'),('image','OTHER'),('memory',GIB),('swap',-1),('cpu',2*10**9),('port','0.0.0.0'),('paused',True)]:
        bad=copy.deepcopy(info)
        if field=='running': bad['State']['Running']=value
        elif field=='owner': bad['Config']['Labels']['spectra.frozen.owner']=value
        elif field=='image': bad['Image']=value
        elif field=='memory': bad['HostConfig']['Memory']=value
        elif field=='swap': bad['HostConfig']['MemorySwap']=value
        elif field=='cpu': bad['HostConfig']['NanoCpus']=value
        elif field=='port': bad['HostConfig']['PortBindings']['7687/tcp'][0]['HostIp']=value
        elif field=='paused': bad['State']['Paused']=value
        rejected=False
        try: validate_owned_state(bad,m,False)
        except AssertionError: rejected=True
        assert rejected,field
        cases.append({'corruption':field,'rejected':True})
    running=copy.deepcopy(info);running['State']['Running']=True
    validate_owned_state(running,m,True)
    return {'actual_stopped_owned_target_passed':True,'running_fixture_passed':True,'negative_cases':cases}

def execute_cypher(query):
    """Use only the previously loaded, exactly owned source-variant container."""
    from neo4j import GraphDatabase, READ_ACCESS
    manifest = read(N / 'actual_native_manifest.json')
    name, port = manifest['target']['container'], 57913
    assert name == 'kdd-db-source-ran3-role2-audit-v1'
    assert manifest['image_id'] == 'sha256:3b9cf65b6cae8b166d5091969e80a5600028aa2e8676a45a925dcc15c379024e'
    helper = module(HELPER, 'R3_common_container_guard')
    guard = module(READ_GUARD, 'R3_common_query_guard')
    def inspect(expected_running):
        info = json.loads(command('docker', 'inspect', name))[0]
        validate_owned_state(info, manifest, expected_running)
        if expected_running:
            helper.guard_container(info, name, port, manifest['run_uuid'], manifest['source']['sha256'])
        return info
    started = time.monotonic()
    rows, columns, size, phase = [], [], 0, 'query_screen'
    result = {'status': 'ERROR', 'rows': [], 'complete': False, 'truncated': False,
              'plan_query_type': None, 'execution_query_type': None, 'rollback_completed': False}
    clean = guard.screen_query(query)
    assert clean == query, 'Never rewrite generated query'
    with (B / 'native_capture.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        linux = next(int(x.split()[1]) * 1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
        windows = int(command('powershell.exe', '-NoProfile', '-Command', '(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory')) * 1024
        save(OUT / 'actual_generated_query_host_guard.json', {'utc': utc(), 'linux_available_bytes': linux,
             'windows_available_bytes': windows, 'minimum_available_bytes': 26 * GIB, 'reserve_bytes': 16 * GIB})
        assert min(linux, windows) >= 26 * GIB
        assert not any(n.startswith('kdd-db-') for n in command('docker', 'ps', '--format', '{{.Names}}').splitlines())
        assert not inspect(False)['State']['Running']
        begun = False
        try:
            command('docker', 'start', name)
            begun = True
            inspect(True)
            driver = GraphDatabase.driver(manifest['target']['bolt'], auth=None, connection_timeout=5, max_transaction_retry_time=0)
            try:
                deadline = time.monotonic() + 90
                while True:
                    try:
                        driver.verify_connectivity()
                        break
                    except Exception:
                        if time.monotonic() > deadline:
                            raise
                        time.sleep(1)
                with driver.session(database='neo4j', default_access_mode=READ_ACCESS, fetch_size=100) as session:
                    tx = session.begin_transaction(timeout=60)
                    try:
                        phase = 'inventory'
                        n = tx.run('MATCH (n) RETURN count(n) AS n').single()['n']
                        e = tx.run('MATCH ()-[r]->() RETURN count(r) AS n').single()['n']
                        assert (n, e) == (87980, 481500)
                        result['inventory_before'] = {'nodes': n, 'relationships': e}
                        phase = 'EXPLAIN'
                        plan = tx.run('EXPLAIN ' + clean).consume()
                        guard.require_read_plan(plan)
                        result['plan_query_type'] = plan.query_type
                        phase = 'execute'
                        cur = tx.run(clean)
                        columns = list(cur.keys())
                        assert len(columns) == len(set(columns)), 'Duplicate aliases'
                        status = 'OK'
                        for row in cur:
                            record = row.data()
                            added = len(canonical(record).encode()) + 1
                            if len(rows) == 100000:
                                status = 'ROW_CAP'
                                break
                            if size + added > 256 * 1024 * 1024:
                                status = 'BYTE_CAP'
                                break
                            rows.append(record)
                            size += added
                        if status == 'OK':
                            summary = cur.consume()
                            assert summary.query_type == 'r' and not summary.counters.contains_updates and not summary.counters.contains_system_updates
                            result.update(execution_query_type=summary.query_type, execution_summary_complete=True,
                                          contains_updates=False, contains_system_updates=False)
                        result.update(status=status, complete=status == 'OK', truncated=status in {'ROW_CAP', 'BYTE_CAP'})
                    finally:
                        tx.rollback()
                        result['rollback_completed'] = True
            finally:
                driver.close()
        except Exception as exc:
            result.update(status='ERROR', complete=False, error_class=type(exc).__name__, error_phase=phase)
        finally:
            if begun:
                inspect(True)
                command('docker', 'stop', '--time', '20', name)
                assert not inspect(False)['State']['Running']
                result['owned_container_stopped'] = True
    result.update(rows=rows, columns=columns, retained_json_bytes=size, elapsed_s=time.monotonic() - started,
                  row_cap=100000, byte_cap=256 * 1024 * 1024, timeout_s=60, source_variant_only=True)
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['prepare','execute']);args=p.parse_args()
    original.verify_freeze()
    generated=E/'actual_call_trial_v1/generated_before_execution.json'
    primary=E/'actual_call_trial_v1/actual_results_summary.json'
    if args.phase=='prepare':
        assert not OUT.exists();OUT.mkdir()
        save(OUT/'plan_and_guard_controls.json',{
            'utc':utc(),'status':'POSTHOC_INFRASTRUCTURE_ONLY_SAVED_QUERY_REPLAY_PREPARED',
            'reason':'Frozen runner applied a running-only guard to the stopped owned container before start. No generated Cypher reached Neo4j.',
            'primary_preserved':True,'model_calls':0,'query_changes':0,'original_admissions':0,
            'primary_result_replacement':False,'changes':'Stopped/running ownership validation and separate receipt destination only; original native query/EXPLAIN/read guard/caps/timeouts/rollback unchanged.',
            'guard_controls':controls(),
            'pins':[{'path':str(f),'sha256':sha(f)} for f in (Path(__file__),FROZEN,generated,primary,original.DEFINITION)]})
        return
    plan=read(OUT/'plan_and_guard_controls.json')
    for f in plan['pins']: assert sha(f['path'])==f['sha256']
    assert not (OUT/'actual_replay_and_scores.json').exists()
    record=read(generated)['results']['Text2Cypher'];query=record['generated_query']
    assert hashlib.sha256(query.encode()).hexdigest()==record['query_sha256']
    result=execute_cypher(query)
    gold=[{'tdocNumber':r[0]} for r in read(N/'actual_native_original_two_column_capture.json')['selected']['rows']]
    scorer=module(original.PUBLIC/'original_core_source_enriched_repair/scorer.py','R3_infra_replay_scorer')
    score=scorer.score(read(original.DEFINITION),gold,result['rows'] if result.get('complete') else [],diagnostic=True)
    save(OUT/'actual_replay_and_scores.json',{
        'utc':utc(),'status':'POSTHOC_INFRASTRUCTURE_REPLAY_NOT_PRIMARY_REPLACEMENT',
        'query':query,'query_sha256':record['query_sha256'],'execution':result,'score':score,
        'gold':gold,'primary_first_attempt_sha256':sha(primary),'plan_sha256':sha(OUT/'plan_and_guard_controls.json'),
        'model_calls':0,'query_changes':0,'original_admissions':0,'expert_validation_n':0})
    original.verify_freeze()
    for f in plan['pins']: assert sha(f['path'])==f['sha256']
    print(json.dumps({'status':result['status'],'complete':result.get('complete'),'rows':len(result['rows']),'score':score,'owned_container_stopped':result.get('owned_container_stopped')}),flush=True)

if __name__=='__main__':main()
