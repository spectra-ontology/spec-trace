#!/usr/bin/env python3
"""Read source/receipts and exercise an AST-extracted pure state guard only."""
import ast
import copy
import difflib
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
E = HERE.parent
O = E.parent

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read(p):
    return json.loads(Path(p).read_text())

def function(text, name):
    return next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == name)

def main():
    original = E / 'run_separate_source_experiment.py'
    replay = O / 'root_RAN3_saved_query_infrastructure_only_replay.py'
    plan_path = replay.with_suffix('') / 'plan_and_guard_controls.json'
    plan = read(plan_path)
    for pin in plan['pins']:
        assert sha(pin['path']) == pin['sha256']
    before = ast.get_source_segment(original.read_text(), function(original.read_text(), 'execute_cypher'))
    after = ast.get_source_segment(replay.read_text(), function(replay.read_text(), 'execute_cypher'))
    replacements = [
        ('def inspect():', 'def inspect(expected_running):', 1),
        ("        helper.guard_container(info, name, port, manifest['run_uuid'], manifest['source']['sha256'])\n        assert info['Image'] == manifest['image_id']",
         "        validate_owned_state(info, manifest, expected_running)\n        if expected_running:\n            helper.guard_container(info, name, port, manifest['run_uuid'], manifest['source']['sha256'])", 1),
        ("save(TRIAL / 'actual_generated_query_host_guard.json'", "save(OUT / 'actual_generated_query_host_guard.json'", 1),
        ("assert not inspect()['State']['Running']", "assert not inspect(False)['State']['Running']", 2),
        ('            inspect()\n', '            inspect(True)\n', 2),
    ]
    expected = before
    changes = []
    for old, new, count in replacements:
        actual = expected.count(old)
        assert actual == count, (old, actual, count)
        expected = expected.replace(old, new)
        changes.append({'old': old, 'new': new, 'occurrences': count})
    assert ast.dump(ast.parse(expected), include_attributes=False) == ast.dump(ast.parse(after), include_attributes=False)
    diff = ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='frozen_execute_cypher', tofile='infra_only_execute_cypher'))
    (HERE / 'reviewed_execute_cypher_exact_diff.patch').write_text(diff)
    manifest_path = O / 'root_RAN3_source_variant_native_v1/actual_native_manifest.json'
    m = read(manifest_path)
    guard = function(replay.read_text(), 'validate_owned_state')
    environment = {'GIB': 1024**3}
    exec(compile(ast.Module(body=[guard], type_ignores=[]), str(replay) + ':pure_guard_only', 'exec'), environment)
    validate = environment['validate_owned_state']
    fixture = {'Name': '/' + m['target']['container'], 'Image': m['image_id'],
        'Config': {'Labels': {'spectra.frozen.owner': 'contract_repair_v1', 'spectra.frozen.run_uuid': m['run_uuid'], 'spectra.frozen.source_sha256': m['source']['sha256']}},
        'HostConfig': {'Memory': 2*1024**3, 'MemorySwap': 2*1024**3, 'NanoCpus': 10**9,
            'PortBindings': {'7687/tcp': [{'HostIp': '127.0.0.1', 'HostPort': '57913'}]}},
        'State': {'Running': False, 'Paused': False, 'Restarting': False}}
    validate(fixture, m, False)
    running = copy.deepcopy(fixture); running['State']['Running'] = True
    validate(running, m, True)
    mutations = [
        ('name', ['Name'], '/other'), ('owner', ['Config', 'Labels', 'spectra.frozen.owner'], 'other'),
        ('run_uuid', ['Config', 'Labels', 'spectra.frozen.run_uuid'], 'other'),
        ('source_sha', ['Config', 'Labels', 'spectra.frozen.source_sha256'], 'other'),
        ('image', ['Image'], 'other'), ('memory', ['HostConfig', 'Memory'], 1024**3),
        ('swap', ['HostConfig', 'MemorySwap'], -1), ('cpu', ['HostConfig', 'NanoCpus'], 2*10**9),
        ('port', ['HostConfig', 'PortBindings'], {'7687/tcp': [{'HostIp': '0.0.0.0', 'HostPort': '57913'}]}),
        ('running', ['State', 'Running'], True), ('paused', ['State', 'Paused'], True),
        ('restarting', ['State', 'Restarting'], True)]
    negatives = []
    for name, path, value in mutations:
        bad = copy.deepcopy(fixture)
        at = bad
        for key in path[:-1]: at = at[key]
        at[path[-1]] = value
        try:
            validate(bad, m, False)
        except AssertionError:
            negatives.append({'case': name, 'rejected': True})
        else: raise AssertionError(name)
    primary = E / 'actual_call_trial_v1/actual_results_summary.json'
    generated = read(E / 'actual_call_trial_v1/generated_before_execution.json')['results']['Text2Cypher']
    assert hashlib.sha256(generated['generated_query'].encode()).hexdigest() == generated['query_sha256']
    tree = ast.parse(replay.read_text())
    main_text = ast.get_source_segment(replay.read_text(), function(replay.read_text(), 'main'))
    assert "record=read(generated)['results']['Text2Cypher'];query=record['generated_query']" in main_text
    assert "result=execute_cypher(query)" in main_text
    assert 'primary_result_replacement' in main_text and 'POSTHOC_INFRASTRUCTURE_REPLAY_NOT_PRIMARY_REPLACEMENT' in main_text
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'call' for n in ast.walk(tree))
    root_controls = plan['guard_controls']
    assert root_controls['actual_stopped_owned_target_passed'] and root_controls['running_fixture_passed']
    assert len(root_controls['negative_cases']) == 8 and all(x['rejected'] for x in root_controls['negative_cases'])
    output = {'utc': datetime.now(timezone.utc).isoformat(), 'status': 'PASS_READ_ONLY_INFRASTRUCTURE_WRAPPER_REVIEW',
        'scope': 'Review only; root owns actual container replay and future result receipt.',
        'native_execution': 0, 'API_calls': 0, 'model_retries': 0, 'query_changes': 0, 'primary_result_mutations': 0,
        'exact_native_function_AST_diff_matches_declared_state_and_destination_changes': True,
        'allowed_replacements': changes,
        'retained_guards': ['exclusive nonblocking native_capture.lock', '26GiB host minimum', '16GiB reserve observation',
            'no other running kdd-db container', '2GiB memory/swap and 1CPU target', 'loopback 57913 only',
            'frozen owner/run/source/image', 'query screen equality', 'EXPLAIN read plan', 'READ_ACCESS',
            '60s transaction/100000row/256MiB output caps', 'no native driver retries', 'explicit rollback', 'owned start/stop'],
        'direct_pure_guard_tests': {'synthetic_stopped': True, 'synthetic_running': True, 'negative_cases': negatives},
        'root_existing_actual_receipt_not_reexecuted_by_child': {'path': str(plan_path), 'sha256': sha(plan_path), 'controls': root_controls},
        'query_sha256': generated['query_sha256'], 'primary_first_all_zero_sha256': sha(primary),
        'interpretation': 'Posthoc infrastructure-only execution of identical saved Cypher may measure query correctness; it must remain separate from frozen primary all-zero outcome. No SQL rewrite or retrieval parser relaxation is authorized by this review.',
        'inputs': [{'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size} for p in (original, replay, plan_path, manifest_path, primary, Path(__file__))]}
    target = HERE / 'actual_infrastructure_wrapper_readonly_review.json'
    with target.open('x') as f: json.dump(output, f, ensure_ascii=False, indent=2); f.write('\n')
    print(json.dumps({'status': output['status'], 'path': str(target), 'sha256': sha(target), 'negative_controls': len(negatives)}))

if __name__ == '__main__': main()
