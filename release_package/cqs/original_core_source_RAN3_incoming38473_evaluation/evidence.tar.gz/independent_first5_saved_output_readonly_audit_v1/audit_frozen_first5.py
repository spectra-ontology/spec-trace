#!/usr/bin/env python3
"""Audit immutable saved calls; no API, native container, retrieval or generated query execution."""
import ast
from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sqlite3
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
E = HERE.parent
O = E.parent
T = E / 'actual_call_trial_v1'

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1024**2), b''): h.update(b)
    return h.hexdigest()

def read(p): return json.loads(Path(p).read_text())
def canonical(x): return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
def digest(x): return hashlib.sha256(canonical(x).encode()).hexdigest()

def module(p, name):
    spec = importlib.util.spec_from_file_location(name, p)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m

def main():
    freeze = read(E / 'precall_freeze.json')
    pins = freeze['pinned_files']
    before = {}
    for p in pins:
        actual = sha(p['path'])
        assert actual == p['sha256'] and Path(p['path']).stat().st_size == p['bytes'], p['path']
        before[p['path']] = actual
    summary_path = T / 'actual_results_summary.json'
    summary = read(summary_path)
    generated_path = T / 'generated_before_execution.json'
    generated = read(generated_path)
    executed = read(T / 'executed_predictions.json')
    queries = read(T / 'before_execution_queries_frozen.json')
    assert queries['generated_record_sha256'] == sha(generated_path)
    assert generated['freeze_sha256'] == executed['freeze_sha256'] == queries['freeze_sha256'] == sha(E / 'precall_freeze.json')
    immutable_files = list(T.rglob('*.json'))
    immutable_before = {str(p): sha(p) for p in immutable_files}
    structured = module(E / 'runtime/structured_adapter.py', 'audit_frozen_structured_no_evaluate')
    retrieval = module(E / 'runtime/retrieval_adapter.py', 'audit_frozen_retrieval_no_evaluate')
    task = read(E / 'public_task.json')
    assert task['id'] == 'RAN3_P4_CQ2-3'
    schema = read(E / 'sql_schema.json')
    db_path = Path(next(p['path'] for p in pins if p['path'].endswith('RAN3-source-enriched-full.sqlite')))
    with sqlite3.connect(db_path.as_uri() + '?mode=ro&immutable=1', uri=True) as con:
        # Inspect physical names only: never execute or rewrite a generated SQL query.
        con.execute('PRAGMA query_only=ON')
        physical_tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    schema_keys = list(schema['relationship_tables'])
    mapping = [{'prompt_key': k, 'physical_table_same_name_exists': k in physical_tables,
                'physical_rel_prefixed_table': 'rel_' + k, 'physical_rel_prefixed_table_exists': 'rel_' + k in physical_tables}
               for k in schema_keys]
    assert len(mapping) == 45 and all(not x['physical_table_same_name_exists'] and x['physical_rel_prefixed_table_exists'] for x in mapping)
    stages = ['Text2Cypher', 'Text2SQL', 'C_answer', 'D_followup', 'D_answer']
    request_files = sorted((T / 'calls').glob('*.request.json'))
    response_files = sorted((T / 'calls').glob('*.attempt*.response.json'))
    assert len(request_files) == len(response_files) == 5
    assert all('.attempt0.response.json' in p.name for p in response_files)
    calls, total = [], Decimal('0')
    response_content = {}
    for stage in stages:
        prefix = T / 'calls' / ('RAN3_P4_CQ2-3_' + stage)
        req_path = Path(str(prefix) + '.request.json')
        res_path = Path(str(prefix) + '.attempt0.response.json')
        out_path = Path(str(prefix) + '.outcome.json')
        req, res, out = read(req_path), read(res_path), read(out_path)
        raw_decimal = json.loads(res_path.read_text(), parse_float=Decimal)
        payload = req['payload']; raw = res['response']; choice = raw['choices'][0]
        content = choice['message']['content']; response_content[stage] = content
        assert req['authorization_header_omitted'] is True
        assert req['payload_sha256'] == hashlib.sha256(json.dumps(payload, ensure_ascii=False).encode()).hexdigest()
        assert res['attempt'] == 0 and res['http_status'] == 200 and out['ok']
        assert len(out['attempts']) == 1 and out['attempts'][0]['attempt'] == 0 and not out['attempts'][0]['retryable']
        assert content == out['content'] and raw['usage'] == out['usage']
        assert choice['finish_reason'] == out['finish_reason'] == 'stop'
        assert choice['native_finish_reason'] == 'end_turn'
        assert raw['model'] == payload['model'] == freeze['model']
        assert raw['provider'] == freeze['provider_only'] == 'Anthropic'
        assert payload['provider'] == {'only': ['Anthropic'], 'allow_fallbacks': False, 'require_parameters': True}
        assert payload['response_format'] == {'type': 'json_object'} and not payload['reasoning']['enabled']
        assert datetime.fromisoformat(req['created_utc']) > datetime.fromisoformat(freeze['utc'])
        assert datetime.fromisoformat(res['received_utc']) < datetime.fromisoformat(queries['utc'])
        u = raw['usage']; cost = raw_decimal['response']['usage']['cost']; total += cost
        assert u['prompt_tokens'] + u['completion_tokens'] == u['total_tokens']
        assert Decimal(str(out['known_actual_cost_usd'])) == cost and out['unknown_cost_attempts'] == 0
        assert choice['message'].get('refusal') is None
        if stage in stages[:2]:
            t = dict(task); key = 'graph_schema' if stage == 'Text2Cypher' else 'sql_schema'
            t[key] = read(E / (key + '.json'))
            expected_messages = structured.messages_for(t, stage)
            assert payload['messages'] == expected_messages
            g = generated['results'][stage]
            parsed = json.loads(content)
            assert set(parsed) == {'query', 'abstain'} and parsed['abstain'] is False
            assert parsed['query'] == g['generated_query'] == executed['results'][stage]['generated_query']
            assert hashlib.sha256(parsed['query'].encode()).hexdigest() == g['query_sha256'] == queries['queries'][stage]
            assert g['status'] == 'QUERY_READY' and not g['abstain']
            assert digest(payload['messages']) == g['prompt_sha256']
            model_abstain = False
        else:
            method = stage[0]
            context_name = 'initial_context.json' if stage == 'D_followup' else 'final_context.json'
            context = read(T / 'retrieval' / method / task['id'] / context_name)
            passages = '\n\n'.join(d['formatted'] for d in context['documents'])
            for d in context['documents']:
                assert hashlib.sha256(d['formatted'].encode()).hexdigest() == d['formatted_sha256']
            instruction = retrieval.QUERY_INSTRUCTION if stage == 'D_followup' else retrieval.ANSWER_INSTRUCTION
            expected_messages = [{'role': 'system', 'content': instruction}, {'role': 'user',
                'content': canonical({'question': task['question_en'], 'contract': retrieval.public_contract(task)}) + '\nSOURCE PASSAGES:\n' + passages}]
            assert payload['messages'] == expected_messages
            if stage == 'D_followup':
                obj = json.loads(content)
                assert set(obj) == {'query'} and obj['query'] == 'AFFECTS_CORE_SPEC 38.473 CR'
                model_abstain = None
            else:
                try: retrieval.parse_answer(content)
                except json.JSONDecodeError as exc:
                    assert exc.pos == 0
                else: raise AssertionError('Strict parser must reject prose/fenced answer')
                # Forensic declaration only; never fed to scorer or accepted as an answer.
                fence = re.search(r'```json\s*(.*?)\s*```', content, re.S)
                obj = json.loads(fence.group(1))
                assert obj['abstain'] is False and obj['complete'] is False
                assert len(obj['records']) == (4 if stage == 'C_answer' else 6)
                model_abstain = False
        calls.append({'stage': stage, 'request_sha256': sha(req_path), 'response_sha256': sha(res_path),
            'outcome_sha256': sha(out_path), 'payload_sha256': req['payload_sha256'], 'prompt_sha256': digest(payload['messages']),
            'prompt_reconstruction_exact': True, 'attempt': 0, 'HTTP': 200,
            'finish_reason': choice['finish_reason'], 'native_finish_reason': choice['native_finish_reason'],
            'max_tokens': payload['max_tokens'], 'usage': u, 'cost_decimal_USD': str(cost),
            'model_declared_abstain': model_abstain,
            'raw_content_sha256': hashlib.sha256(content.encode()).hexdigest(),
            'forensic_fenced_record_count_not_accepted_or_scored': (len(obj['records']) if stage in ['C_answer', 'D_answer'] else None)})
    assert total == Decimal('0.383310')
    usage = read(T / 'usage.json')
    assert Decimal(str(usage['known_actual_cost_usd'])) == total and usage['received_response_calls'] == 5
    assert summary['usage'] == usage and usage['unknown_cost_attempts'] == 0
    definition_path = Path(next(p['path'] for p in pins if p['path'].endswith('exact_separate_source_variant_definition_NOT_ADMITTED.json')))
    definition = read(definition_path)
    assert definition['repair_sha256'] == task['repair_sha256'] == summary['repair_sha256']
    native_capture = read(O / 'root_RAN3_source_variant_native_v1/actual_native_original_two_column_capture.json')
    gold = [{'tdocNumber': r[0]} for r in native_capture['selected']['rows']]
    assert summary['gold_rows'] == gold and len(gold) == len({r['tdocNumber'] for r in gold}) == 10
    scorer_path = Path(next(p['path'] for p in pins if p['path'].endswith('/scorer.py')))
    scorer = module(scorer_path, 'frozen_first5_audit_scorer')
    methods = []
    for s in summary['methods']:
        m = s['method']; r = executed['results'][m]
        valid = r['status'] in {'OK', 'ok', 'partial'} and not r.get('abstain', False)
        prediction = r.get('records', []) if valid else []
        actual_score = scorer.score(definition, gold, prediction, diagnostic=True)
        assert actual_score == s['score'] and not valid and actual_score['f1'] == 0
        assert r['records'] == [] and s['valid_answer'] is False
        if m in stages[:2]:
            assert r['abstain'] is True and r['status'] == 'EXECUTION_ERROR'
            assert r['execution']['error_class'] == ('RuntimeError' if m == 'Text2Cypher' else 'OperationalError')
            classification = 'preexecution_wrapper_state_guard_failure' if m == 'Text2Cypher' else 'execution_table_name_failure_with_contradictory_supplied_schema'
        else:
            assert r['status'] == 'answer_parse_error' and s['answer_parse_error'] is True
            assert r.get('abstain') is None and s['abstention'] is False
            classification = 'strict_json_answer_format_failure_not_model_declared_abstention'
        methods.append({'method': m, 'saved_primary_status': r['status'], 'classification': classification,
            'score_replayed_exactly': actual_score, 'model_declared_abstain': False,
            'execution_wrapper_abstain': r.get('abstain') if m in stages[:2] else None,
            'summary_abstention_flag_is_not_model_declaration': m in stages[:2],
            'retrieval_context_stats': r.get('context_stats'),
            'requested_population_completeness_verified': r.get('requested_population_completeness_verified')})
    assert scorer.score(definition, gold, gold, diagnostic=True)['exact'] is True
    assert scorer.score(definition, gold, [], diagnostic=True)['f1'] == 0
    assert scorer.score(definition, gold, [{'tdocNumber': 260801}], diagnostic=True)['type_errors']
    helper_path = Path(next(p['path'] for p in pins if p['path'].endswith('load_enriched_ttl_neo4j.py')))
    helper_tree = ast.parse(helper_path.read_text())
    guard = next(n for n in helper_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'guard_container')
    env = {}; exec(compile(ast.Module(body=[guard], type_ignores=[]), str(helper_path) + ':pure_guard_only', 'exec'), env)
    manifest = read(O / 'root_RAN3_source_variant_native_v1/actual_native_manifest.json')
    fixture = {'Name': '/' + manifest['target']['container'], 'Config': {'Labels': {
        'spectra.frozen.owner': 'contract_repair_v1', 'spectra.frozen.run_uuid': manifest['run_uuid'],
        'spectra.frozen.source_sha256': manifest['source']['sha256']}},
        'HostConfig': {'Memory': 2*1024**3, 'NanoCpus': 10**9, 'PortBindings': {'7687/tcp': [{'HostIp': '127.0.0.1', 'HostPort': '57913'}]}},
        'State': {'Running': False}}
    try: env['guard_container'](fixture, manifest['target']['container'], 57913, manifest['run_uuid'], manifest['source']['sha256'])
    except RuntimeError as exc: assert str(exc) == 'target container is not running'
    else: raise AssertionError('Frozen guard must reject a stopped owned target')
    source = (E / 'run_separate_source_experiment.py').read_text()
    assert source.index("assert not inspect()['State']['Running']") < source.index("command('docker', 'start', name)")
    sql_system = read(T / 'calls/RAN3_P4_CQ2-3_Text2SQL.request.json')['payload']['messages'][0]['content']
    assert 'directed rel_TYPE tables' in sql_system
    sql_input_defect = {'all_relationship_table_keys': mapping, 'relationship_keys': len(mapping),
        'unprefixed_prompt_keys_absent_as_physical_tables': sum(not x['physical_table_same_name_exists'] for x in mapping),
        'matching_rel_prefixed_physical_tables': sum(x['physical_rel_prefixed_table_exists'] for x in mapping),
        'system_instruction_says_rel_TYPE': True,
        'generated_query_uses_unprefixed_AFFECTS_CORE_SPEC': True,
        'conclusion': 'Supplied relationship_tables dictionary and system naming instruction conflict. The saved SQL fails physically; attributing this solely to the model is unsupported. Schema remains immutable and no rewrite/retry/re-scoring was done.'}
    for p, h in before.items(): assert sha(p) == h
    for p, h in immutable_before.items(): assert sha(p) == h
    receipt = {'utc': datetime.now(timezone.utc).isoformat(), 'status': 'PASS_INDEPENDENT_SAVED_FIRST5_AUDIT_WITH_INFRASTRUCTURE_AND_INPUT_DEFECTS',
        'question_id': task['id'], 'repair_sha256': task['repair_sha256'],
        'API_calls': 0, 'native_container_operations': 0, 'generated_query_executions': 0,
        'gold_or_original_status_modifications': 0, 'original_admissions': 0, 'human_experts': 0,
        'audit_actions': ['All35 precall file hashes/bytes rechecked', 'All5 raw requests/responses/outcomes cross-linked',
            'All5 exact prompt reconstruction from frozen code and saved contexts', 'Strict retrieval parser exercised on raw response',
            'All4 primary scorer outcomes replayed unchanged', 'Pure old stopped-container guard reproduced',
            'Read-only immutable SQLite sqlite_master table-name inspection only'],
        'calls': calls, 'actual_cost_USD_decimal': str(total), 'attempt0_HTTP200_count': 5,
        'actual_transport_retry_count': 0, 'quality_retry_count': 0, 'output_truncation_count': 0,
        'methods': methods, 'SQL_input_schema_defect': sql_input_defect,
        'primary_first_all_zero_preserved': True,
        'primary_all_zero_is_not_four_demonstrated_reasoning_failures': True,
        'native_wrapper_failure': {'pure_guard_error': 'target container is not running',
            'guard_invoked_before_docker_start': True, 'generated_Cypher_execution_correctness_measured_by_primary': False,
            'saved_exception_has_no_message_or_stack': True,
            'causal_evidence_limit': 'RuntimeError is saved without message/stack. Matching pure guard reproduction and exact pre-start call order establish a deterministic wrapper defect; child did not inspect or start the actual container.'},
        'retrieval_parse_policy': 'Frozen whole-content JSON parser rejects both leading-prose/fenced-JSON outputs at char0. Fenced declarations are recorded solely for forensic abstain distinction and never accepted or scored.',
        'scorer_controls': {'gold_identity_exact': True, 'empty_zero': True, 'wrong_scalar_type_rejected': True},
        'interpretation_limits': ['N1 separate enriched-graph-source experiment; original483 admissions unchanged',
            'Shared source facts do not establish equal exposure, equal cost, complete retrieval, or causal method advantage',
            'Infrastructure-only saved-query replay is a separate posthoc measurement, never a replacement primary result',
            'Gold source meaning/completeness not independently re-established by this saved-output audit'],
        'freeze_pins_rechecked': pins, 'immutable_saved_trial_inputs_before_after': immutable_before,
        'audit_script_sha256': sha(__file__), 'freeze_sha256': sha(E / 'precall_freeze.json'),
        'primary_summary_sha256': sha(summary_path)}
    target = HERE / 'actual_independent_first5_saved_output_audit.json'
    with target.open('x') as f: json.dump(receipt, f, ensure_ascii=False, indent=2); f.write('\n')
    print(json.dumps({'status': receipt['status'], 'path': str(target), 'sha256': sha(target), 'cost': str(total)}))

if __name__ == '__main__': main()
