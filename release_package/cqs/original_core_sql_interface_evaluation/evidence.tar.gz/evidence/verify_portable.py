#!/usr/bin/env python3
"""Offline payload, status, strict-score and paired-analysis replay; no DB/API."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--evidence', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--manifest', type=Path)
    args = parser.parse_args()
    base = args.evidence.resolve()
    manifest = args.manifest or base / 'portable_manifest.json'
    package = json.loads(manifest.read_text())
    for relative, expected in package['files'].items():
        target = (base / relative).resolve()
        assert target.is_relative_to(base) and target.is_file()
        assert sha(target) == (expected['sha256'] if isinstance(expected, dict) else expected), relative
    sys.path.insert(0, str(base / 'portable_runtime'))
    import analyze_predictions as analysis
    import structured_adapter as structured
    sys.path.insert(0, str(base / 'input_snapshots/parent371'))
    import score_predictions
    protocols = {name: json.loads((folder / 'protocol.json').read_text()) for name, folder in
                 [('initial', base), ('http402', base / 'recovery_http402'), ('budget20', base / 'recovery_budget20')]}
    tasks = analysis.unique(read(base / 'cohort/tasks.jsonl'))
    public = analysis.unique(read(base / 'public_tasks.jsonl'))
    final = base / 'recovered_complete_union'
    statuses = analysis.unique(read(final / 'text2sql/statuses.jsonl'))
    predictions = analysis.unique(read(final / 'text2sql/predictions.jsonl'))
    assert len(tasks) == 378 and set(tasks) == set(public) == set(statuses) == set(predictions)
    first = set(protocols['http402']['cohort_ids'])
    second = set(protocols['budget20']['cohort_ids'])
    assert len(first) == 129 and len(second) == 20 and second <= first
    folders = {identifier: base / 'recovery_budget20' if identifier in second else
               base / 'recovery_http402' if identifier in first else base for identifier in tasks}
    initial_noanswer, guard_noanswer = 0, 0
    for identifier in first:
        original = json.loads((base / 'arm_outputs/text2sql' / (identifier + '.json')).read_text())
        assert original['status'] == 'GENERATION_ERROR' and original['call']['content'] is None
        assert original['generated_query'] is None and original['call']['provider'] is None
        assert original['call']['error'] == 'http_402'
        denial = json.loads((base / 'calls' / Path(original['call']['response_path']).name).read_text())
        assert denial['http_status'] == 402
        assert denial['response']['error']['metadata']['reason'] == 'in_flight_budget_exhausted'
        assert not denial['response'].get('choices')
        initial_noanswer += 1
    for identifier in second:
        original = json.loads((base / 'recovery_http402/arm_outputs/text2sql' / (identifier + '.json')).read_text())
        assert original['status'] == 'GENERATION_ERROR' and original['call']['error'] == 'frozen_budget_guard'
        assert original['call']['content'] is None and original['generated_query'] is None
        assert not original['call'].get('request_path') and not original['call'].get('response_path')
        guard_noanswer += 1
    counts = Counter()
    received = 0
    for identifier, task in tasks.items():
        folder = folders[identifier]
        executed = json.loads((folder / 'executed/text2sql' / (identifier + '.json')).read_text())
        call = executed['call']
        assert executed['repair_sha256'] == statuses[identifier]['repair_sha256'] == task['repair_sha256']
        assert executed['status'].upper() == statuses[identifier]['status']
        assert executed['records'] == predictions[identifier]['records']
        assert call['ok'] and call['content'] is not None and call['provider'] == 'Anthropic'
        assert executed['private_evidence_read_by_generator'] is False
        request = json.loads((folder / 'calls' / (identifier + '_Text2SQL.request.json')).read_text())
        original_payload = json.loads((base / 'calls' / (identifier + '_Text2SQL.request.json')).read_text())['payload']
        assert request['payload'] == original_payload
        assert request['authorization_header_omitted'] is True
        expected = structured.messages_for(dict(public[identifier], sql_schema=json.loads(
            (base / 'schemas' / (task['id'].split('_')[0] + '_sql.json')).read_text())), 'B')
        assert request['payload']['messages'] == expected
        assert request['payload']['model'] == 'anthropic/claude-opus-4.8'
        assert request['payload']['max_tokens'] == 4096
        response = json.loads((folder / 'calls' / Path(call['response_path']).name).read_text())
        assert response['http_status'] == 200
        assert response['response']['model'] == 'anthropic/claude-opus-4.8'
        assert response['response']['provider'] == 'Anthropic'
        if executed['status'] == 'OK':
            execution = executed['execution']
            assert execution['complete'] and not execution['truncated'] and execution['immutable_read_only']
            assert execution['status'] == 'OK' and execution['source_guard_batch_verified']
        counts[executed['status']] += 1
        received += 1
    raw = score_predictions.run(base / 'cohort/tasks.jsonl', base / 'cohort/reference_gold.jsonl',
                                final / 'text2sql/predictions.jsonl')
    replay = {r['id']: analysis.gated(r, statuses[r['id']]['status']) for r in raw['outcomes']}
    saved = analysis.unique(json.loads((final / 'text2sql/failure_gated_scores.json').read_text()))
    assert replay == saved
    report = json.loads((final / 'analysis.json').read_text())
    assert analysis.summary(list(replay.values())) == report['overall']
    old371 = analysis.unique(json.loads((base / 'input_snapshots/previous371_sql_scores.json').read_text()))
    old7 = analysis.unique(json.loads((base / 'input_snapshots/previous7_sql_scores.json').read_text()))
    assert len(old371) == 371 and len(old7) == 7 and not set(old371) & set(old7)
    assert set(old371) | set(old7) == set(tasks)
    compared = json.loads((base / 'paired_previous_SQL378.json').read_text())['comparisons']
    for name, previous in [('parent371', old371), ('extension7', old7), ('all378', dict(old371, **old7))]:
        after = {identifier: replay[identifier] for identifier in previous}
        assert all(previous[i]['repair_sha256'] == tasks[i]['repair_sha256'] for i in previous)
        assert analysis.summary(list(previous.values())) == compared[name]['previous']
        assert analysis.summary(list(after.values())) == compared[name]['actual_DDL']
        assert [analysis.paired(after, previous, metric) for metric in ['f1', 'exact']] == compared[name]['paired']
    for folder in [base, base / 'recovery_http402', base / 'recovery_budget20']:
        for guard in (folder / 'source_guards').glob('*.json'):
            assert json.loads(guard.read_text())['unchanged'] is True
    print(json.dumps({'status': 'PASS', 'manifest_files_n': len(package['files']), 'cohort_n': len(tasks),
        'received_answers': received, 'received_answer_regeneration_n': 0,
        'operational_http402_unanswered': initial_noanswer, 'operational_guard_unanswered': guard_noanswer,
        'paired_previous_cohorts_replayed': [371, 7, 378],
        'final_status_counts': dict(counts), 'overall': report['overall'],
        'model_calls': 0, 'database_query_executions': 0,
        'scope': 'Manifest integrity plus raw payload/answer/status evidence and typed scorer replay; no new model or SQL execution.'}), flush=True)


if __name__ == '__main__':
    main()
