| SQL interface | N | Complete-record macro F1 | Exact output | Failures |
| --- | ---: | ---: | ---: | ---: |
| Actual DDL v2 | 378 | 0.4046 | 143/378 | 147 |
