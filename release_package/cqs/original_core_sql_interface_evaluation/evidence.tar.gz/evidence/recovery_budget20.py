#!/usr/bin/env python3
"""Registered operational completion of twenty requests denied before a call."""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import structured_adapter as structured
import analyze_predictions as analysis
from openrouter_client import OpenRouterCaller, MODEL, PROVIDER
import run as initial
import recovery as first_recovery
from prepare import ROOT, rows, sha, write, WGS

BASE = HERE / 'recovery_budget20'
FIRST = first_recovery.BASE
UNION = HERE / 'recovered_complete_union'


def freeze():
    original = initial.verify()
    first_recovery.verify()
    if (BASE / 'protocol.json').exists():
        raise ValueError('already frozen')
    if not (FIRST / 'execution_complete.json').exists():
        raise ValueError('previous operational phase is incomplete')
    budget = json.loads((HERE / 'budget_check_recovery20.json').read_text())
    if budget['key']['limit_remaining'] < 2 or budget['credits']['remaining'] < 2:
        raise ValueError('insufficient actual resources for this registered guard')
    original_selection = {r['id']: r for r in rows(FIRST / 'selection.jsonl')}
    tasks = rows(HERE / 'public_tasks.jsonl')
    selected = []
    for task in tasks:
        path = FIRST / 'arm_outputs/text2sql' / (task['id'] + '.json')
        if not path.exists():
            continue
        result = json.loads(path.read_text())
        if result['status'] != 'GENERATION_ERROR':
            continue
        call = result['call']
        if (call.get('error') != 'frozen_budget_guard' or call.get('content') is not None
                or call.get('provider') is not None or call.get('request_path')
                or call.get('response_path') or result.get('generated_query') is not None):
            raise ValueError('selection includes a received answer or actual new request')
        selected.append({'id': task['id'], 'repair_sha256': task['repair_sha256'],
                         'prior_generation_path': str(path), 'prior_generation_sha256': sha(path),
                         'initial_request_path': original_selection[task['id']]['initial_request_path'],
                         'initial_request_sha256': original_selection[task['id']]['initial_request_sha256'],
                         'selection': 'First recovery spending guard denied before request/provider/model answer'})
    if len(selected) != 20:
        raise ValueError('must select all twenty unanswered requests in original cohort order')
    wanted = {r['id'] for r in selected}
    BASE.mkdir(exist_ok=True)
    (BASE / 'selection.jsonl').write_text(''.join(structured.canonical(r) + '\n' for r in selected))
    (BASE / 'public_tasks.jsonl').write_text(''.join(structured.canonical(r) + '\n' for r in tasks if r['id'] in wanted))
    write(BASE / 'protocol.json', {
        'kind': 'Pre-call operational recovery of all twenty budget-guard-unanswered requests',
        'frozen_utc': datetime.now(timezone.utc).isoformat(), 'cohort_n': 20, 'union_n': 378,
        'cohort_ids': [r['id'] for r in selected], 'model': MODEL, 'provider': PROVIDER,
        'provider_fallbacks': False, 'generation_tokens': 4096, 'workers': 1,
        'minimum_between_calls_seconds': 5, 'budget_guard_usd': 2.0,
        'same_payload_required': True, 'retry_policy': original['retry_policy'],
        'received_answer_regeneration_n': 0, 'selection_on_correctness_format_or_abstention': False,
        'prior_phases_unchanged': True, 'code_sha256': sha(__file__),
        'initial_protocol_sha256': sha(HERE / 'protocol.json'),
        'first_recovery_protocol_sha256': sha(FIRST / 'protocol.json'),
        'first_recovery_generation_sha256': sha(FIRST / 'generation_complete.json'),
        'first_recovery_analysis_sha256': sha(HERE / 'recovered_union/analysis.json'),
        'budget_check_sha256': sha(HERE / 'budget_check_recovery20.json'),
        'selection_sha256': sha(BASE / 'selection.jsonl'), 'public_tasks_sha256': sha(BASE / 'public_tasks.jsonl'),
        'interpretation': 'Only requests without any model/provider answer are completed. Retain both prior all378 analyses; do not select on accuracy or reroll received answers.'})
    print(json.dumps({'n': 20, 'protocol_sha256': sha(BASE / 'protocol.json'), 'paid_calls': 0}), flush=True)


def verify():
    initial.verify()
    first_recovery.verify()
    p = json.loads((BASE / 'protocol.json').read_text())
    for path, key in [(Path(__file__), 'code_sha256'), (FIRST / 'generation_complete.json', 'first_recovery_generation_sha256'),
                      (HERE / 'recovered_union/analysis.json', 'first_recovery_analysis_sha256'),
                      (HERE / 'budget_check_recovery20.json', 'budget_check_sha256'),
                      (BASE / 'selection.jsonl', 'selection_sha256'), (BASE / 'public_tasks.jsonl', 'public_tasks_sha256')]:
        if sha(path) != p[key]:
            raise ValueError('frozen operational input changed')
    for row in rows(BASE / 'selection.jsonl'):
        if sha(row['prior_generation_path']) != row['prior_generation_sha256'] or sha(row['initial_request_path']) != row['initial_request_sha256']:
            raise ValueError('pinned prior no-answer evidence changed')
    return p


def generate():
    p = verify()
    if any((BASE / 'calls').glob('*')) or any((BASE / 'arm_outputs/text2sql').glob('*')):
        raise ValueError('existing outcomes: never regenerate received answers')
    sys.path.insert(0, str(ROOT / 'scripts/common/common'))
    import credentials
    caller = OpenRouterCaller(BASE, credentials.secret('OPENROUTER_API_KEY'), p['budget_guard_usd'])
    selected = {r['id']: r for r in rows(BASE / 'selection.jsonl')}
    counts = Counter()
    for task in rows(BASE / 'public_tasks.jsonl'):
        model_task = dict(task, sql_schema=json.loads((HERE / 'schemas' / (task['wg'] + '_sql.json')).read_text()))
        original = json.loads(Path(selected[task['id']]['initial_request_path']).read_text())['payload']
        if structured.messages_for(model_task, 'B') != original['messages'] or original['max_tokens'] != 4096:
            raise ValueError('payload changed')
        result = structured.evaluate(model_task, 'B', caller, BASE)
        request = Path(result['call'].get('request_path', ''))
        if request.is_file() and json.loads(request.read_text())['payload'] != original:
            raise ValueError('complete payload differs')
        write(BASE / 'arm_outputs/text2sql' / (task['id'] + '.json'), result)
        counts[result['status']] += 1
        print(json.dumps({'recovery20_completed': sum(counts.values()), 'statuses': dict(counts),
                          'known_cost_usd': caller.actual_cost}), flush=True)
        time.sleep(p['minimum_between_calls_seconds'])
    pins = {str(path.relative_to(BASE)): sha(path) for folder in ['arm_outputs/text2sql', 'predictions/Text2SQL', 'calls']
            for path in (BASE / folder).glob('*.json')}
    write(BASE / 'generation_complete.json', {'n': 20, 'all_ids_complete': True,
          'status_counts': dict(counts), 'usage': caller.summary_unlocked(),
          'all_payloads_equal_initial': True, 'artifact_pins': pins})


def execute():
    p = verify()
    generation = json.loads((BASE / 'generation_complete.json').read_text())
    for name, expected in generation['artifact_pins'].items():
        if sha(BASE / name) != expected:
            raise ValueError('generation artifact changed')
    if (BASE / 'execution_complete.json').exists():
        raise ValueError('already executed')
    original = initial.verify()
    tasks = rows(BASE / 'public_tasks.jsonl')
    for wg in WGS:
        wanted = [task for task in tasks if task['wg'] == wg]
        if not wanted:
            continue
        db = HERE.parent / 'relational' / (wg + '.sqlite')
        expected = original['sql_sources'][wg]['db_sha256']
        if sha(db) != expected:
            raise ValueError('source changed')
        stat = structured.file_identity(db)
        receipts = []
        for task in wanted:
            result = json.loads((BASE / 'arm_outputs/text2sql' / (task['id'] + '.json')).read_text())
            outcome = structured.execute_generated(result, task, sql_db=db, expected_sql_sha=expected,
                source_guard_batch_verified=True, expected_sql_stat=stat)
            write(BASE / 'executed/text2sql' / (task['id'] + '.json'), outcome)
            receipts.append({'id': task['id'], 'status': outcome['status']})
        if sha(db) != expected or structured.file_identity(db) != stat:
            raise ValueError('source changed')
        write(BASE / 'source_guards' / (wg + '.json'), {'db_sha256': expected, 'unchanged': True, 'items': receipts})
    write(BASE / 'execution_complete.json', {'n': 20, 'all_ids_complete': True, 'sources_unchanged': True})


def analyze():
    p = verify()
    json.loads((BASE / 'execution_complete.json').read_text())
    selected = set(p['cohort_ids'])
    first_selected = set(json.loads((FIRST / 'protocol.json').read_text())['cohort_ids'])
    predictions, statuses = [], []
    for task in rows(HERE / 'public_tasks.jsonl'):
        folder = BASE if task['id'] in selected else FIRST if task['id'] in first_selected else HERE
        path = folder / 'executed/text2sql' / (task['id'] + '.json')
        result = json.loads(path.read_text())
        if result['id'] != task['id'] or result['repair_sha256'] != task['repair_sha256']:
            raise ValueError('identity mismatch')
        predictions.append({'id': result['id'], 'repair_sha256': result['repair_sha256'], 'records': result['records']})
        statuses.append({'id': result['id'], 'repair_sha256': result['repair_sha256'], 'status': result['status'].upper(),
            'phase': 'operational_budget20' if folder == BASE else 'operational_http402' if folder == FIRST else 'initial_received_answer',
            'artifact_path': str(path), 'artifact_sha256': sha(path)})
    (UNION / 'text2sql').mkdir(parents=True, exist_ok=True)
    for name, values in [('predictions.jsonl', predictions), ('statuses.jsonl', statuses)]:
        (UNION / 'text2sql' / name).write_text(''.join(structured.canonical(v) + '\n' for v in values))
    sys.path.insert(0, str(initial.BUNDLE))
    import score_predictions
    raw = score_predictions.run(HERE / 'cohort/tasks.jsonl', HERE / 'cohort/reference_gold.jsonl', UNION / 'text2sql/predictions.jsonl')
    status = analysis.unique(statuses)
    results = {r['id']: analysis.gated(r, status[r['id']]['status']) for r in raw['outcomes']}
    if len(results) != 378:
        raise ValueError('denominator mismatch')
    write(UNION / 'text2sql/raw_scores.json', raw)
    write(UNION / 'text2sql/failure_gated_scores.json', list(results.values()))
    contracts = analysis.unique(rows(HERE / 'cohort/tasks.jsonl'))
    parent = set(json.loads(initial.PREVIOUS_PROTOCOL.read_text())['cohort_ids'])
    parts = defaultdict(list)
    for task_id, result in results.items():
        task = contracts[task_id]
        types = [field['type'] for field in task['required_fields']]
        shape = ('ranked' if task['collection']['kind'] == 'top_k_boundary_ties' else 'boolean' if types == ['boolean'] else
                 'scalar_numeric' if len(types) == 1 and types[0] in {'integer', 'number'} else
                 'grouped_numeric' if any(t in {'integer', 'number'} for t in types) else 'enumeration')
        for key in ['WG:' + task_id.split('_')[0], 'phase:' + task_id.split('_')[1], 'generation_phase:' + status[task_id]['phase'],
                    'cohort_phase:' + ('parent371' if task_id in parent else 'extension7'),
                    'asked_fields:' + ('multiple' if len(types) > 1 else 'single'), 'collection:' + task['collection']['kind'],
                    'contract_output_type:' + shape]:
            parts[key].append(result)
    previous = analysis.unique(json.loads(initial.PREVIOUS_SCORES.read_text()))
    overlap = {task_id: results[task_id] for task_id in previous}
    usages = {name: json.loads((folder / 'usage.json').read_text()) for name, folder in
              [('initial', HERE), ('http402', FIRST), ('budget20', BASE)]}
    output = {'kind': 'All378 actual-DDL SQL, preserving initial and two no-answer-only operational phases',
        'cohort_n': 378, 'overall': analysis.summary(list(results.values())),
        'strata': {key: analysis.summary(values) for key, values in sorted(parts.items())},
        'paired_previous_SQL371': [dict(a='actual_ddl_complete_union', b='previous_sql_interface', **analysis.paired(overlap, previous, metric)) for metric in ['f1', 'exact']],
        'initial_analysis_sha256': sha(HERE / 'analysis.json'), 'first_recovered_analysis_sha256': sha(HERE / 'recovered_union/analysis.json'),
        'protocol_pins': {name: sha(folder / 'protocol.json') for name, folder in [('initial', HERE), ('http402', FIRST), ('budget20', BASE)]},
        'phase_usage': usages, 'known_cost_usd': sum(u['known_actual_cost_usd'] for u in usages.values()),
        'unknown_cost_attempts': sum(u['unknown_cost_attempts'] for u in usages.values()),
        'received_answer_regeneration_n': 0, 'original_previous_outputs_preserved': True,
        'limitations': initial.verify()['limitations']}
    write(UNION / 'analysis.json', output)
    summary = output['overall']
    (UNION / 'performance_table.md').write_text('| SQL actual DDL | N | Complete-record F1 | Exact output | Failures |\n| --- | ---: | ---: | ---: | ---: |\n' +
        f"| Completed operational union | 378 | {summary['requested_complete_record_macro_f1']:.4f} | {summary['exact_outputs']}/378 | {summary['failed_n']} |\n")
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['freeze', 'generate', 'execute', 'analyze'])
    args = parser.parse_args()
    {'freeze': freeze, 'generate': generate, 'execute': execute, 'analyze': analyze}[args.action]()
