#!/usr/bin/env python3
"""Separately registered recovery of model-unanswered HTTP402 resource denials.

Never selects a received answer by correctness, formatting, or abstention.
The initial all378 phase and its metrics remain unchanged.
"""
import argparse
from collections import Counter, defaultdict
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
import structured_adapter as structured
import analyze_predictions as analysis
from openrouter_client import OpenRouterCaller, MODEL, PROVIDER
import run as initial
from prepare import ROOT, rows, sha, write, WGS
BASE=HERE/'recovery_http402'


def freeze():
    p=initial.verify()
    if (BASE/'protocol.json').exists():raise ValueError('already frozen')
    generation=json.loads((HERE/'generation_complete.json').read_text())
    tasks=rows(HERE/'public_tasks.jsonl');selected=[]
    for task in tasks:
        file=HERE/'arm_outputs/text2sql'/(task['id']+'.json')
        r=json.loads(file.read_text())
        if r['status']!='GENERATION_ERROR':continue
        call=r['call'];response=Path(call['response_path']);raw=json.loads(response.read_text())
        provider_response=raw.get('response',{});error=provider_response.get('error',{})
        if (call.get('error')!='http_402' or raw.get('http_status')!=402
            or error.get('metadata',{}).get('reason')!='in_flight_budget_exhausted'
            or call.get('content') is not None or call.get('provider') is not None
            or provider_response.get('choices') or r.get('generated_query') is not None):
            raise ValueError('not an exclusively model-unanswered resource denial')
        request=Path(call['request_path']);payload=json.loads(request.read_text())['payload']
        selected.append({'id':task['id'],'repair_sha256':task['repair_sha256'],
            'original_generation_sha256':sha(file),'initial_request_path':str(request),
            'initial_request_sha256':sha(request),'initial_payload_sha256':hashlib.sha256(json.dumps(payload,ensure_ascii=False).encode()).hexdigest(),
            'initial_response_path':str(response),'initial_response_sha256':sha(response),
            'selection':'HTTP402 in_flight_budget_exhausted before any provider/model answer'})
    if len(selected)!=129:raise ValueError('complete129 unanswered resource cohort required')
    BASE.mkdir(exist_ok=True)
    (BASE/'selection.jsonl').write_text(''.join(structured.canonical(t)+'\n' for t in selected))
    wanted={t['id'] for t in selected}
    (BASE/'public_tasks.jsonl').write_text(''.join(structured.canonical(t)+'\n' for t in tasks if t['id'] in wanted))
    protocol={'kind':'Separate pre-call operational recovery of all129 unanswered HTTP402 requests',
        'frozen_utc':datetime.now(timezone.utc).isoformat(),'cohort_n':129,'union_n':378,
        'cohort_ids':[t['id'] for t in selected],'model':MODEL,'provider':PROVIDER,
        'provider_fallbacks':False,'generation_tokens':4096,'workers':1,'minimum_between_calls_seconds':5,
        'budget_guard_usd':12.0,'original_phase_unchanged':True,'received_answer_regeneration_n':0,
        'selection_on_correctness_format_or_abstention':False,
        'same_payload_required':True,'original_retry_policy_unchanged':p['retry_policy'],
        'source_and_execution_limits_unchanged':True,'initial_protocol_sha256':sha(HERE/'protocol.json'),
        'initial_generation_sha256':sha(HERE/'generation_complete.json'),
        'initial_analysis_sha256':sha(HERE/'analysis.json'),
        'selection_sha256':sha(BASE/'selection.jsonl'),'public_tasks_sha256':sha(BASE/'public_tasks.jsonl'),
        'recovery_code_sha256':sha(__file__),
        'interpretation':'A different resource phase on unanswered requests; preserve initial full-denominator metrics and report recovered union separately, not an answer-quality reroll.'}
    write(BASE/'protocol.json',protocol)
    print(json.dumps({'recovery_n':129,'protocol_sha256':sha(BASE/'protocol.json'),'paid_calls':0}),flush=True)


def verify():
    p=json.loads((BASE/'protocol.json').read_text());initial.verify()
    for path,key in [(BASE/'selection.jsonl','selection_sha256'),(BASE/'public_tasks.jsonl','public_tasks_sha256'),
        (HERE/'generation_complete.json','initial_generation_sha256'),(HERE/'analysis.json','initial_analysis_sha256'),
        (Path(__file__),'recovery_code_sha256')]:
        if sha(path)!=p[key]:raise ValueError('recovery input changed')
    return p


def generate():
    p=verify()
    if any((BASE/'calls').glob('*')) or any((BASE/'arm_outputs/text2sql').glob('*')):
        raise ValueError('existing recovery calls; no quality rerun')
    sys.path.insert(0,str(ROOT/'scripts/common/common'));import credentials
    caller=OpenRouterCaller(BASE,credentials.secret('OPENROUTER_API_KEY'),p['budget_guard_usd'])
    selected={t['id']:t for t in rows(BASE/'selection.jsonl')};counts=Counter()
    for task in rows(BASE/'public_tasks.jsonl'):
        model_task=dict(task,sql_schema=json.loads((HERE/'schemas'/(task['wg']+'_sql.json')).read_text()))
        original=json.loads(Path(selected[task['id']]['initial_request_path']).read_text())['payload']
        messages=structured.messages_for(model_task,'B')
        if messages!=original['messages'] or original['max_tokens']!=4096:
            raise ValueError('operational recovery payload changed')
        result=structured.evaluate(model_task,'B',caller,BASE)
        new_request=Path(result['call'].get('request_path',''))
        if new_request.is_file():
            payload=json.loads(new_request.read_text())['payload']
            if payload!=original:raise ValueError('full request payload changed')
        write(BASE/'arm_outputs/text2sql'/(task['id']+'.json'),result)
        counts[result['status']]+=1
        if sum(counts.values())%5==0:
            print(json.dumps({'recovery_completed':sum(counts.values()),'required':129,
                'statuses':dict(counts),'known_cost_usd':caller.actual_cost}),flush=True)
        time.sleep(p['minimum_between_calls_seconds'])
    pinned={str(f.relative_to(BASE)):sha(f) for folder in ['arm_outputs/text2sql','predictions/Text2SQL','calls']
        for f in (BASE/folder).glob('*.json')}
    write(BASE/'generation_complete.json',{'n':129,'all_ids_complete':True,'status_counts':dict(counts),
        'usage':caller.summary_unlocked(),'all_new_payloads_equal_initial':True,'artifact_pins':pinned})


def execute():
    p=verify();g=json.loads((BASE/'generation_complete.json').read_text())
    for name,h in g['artifact_pins'].items():
        if sha(BASE/name)!=h:raise ValueError('recovery output changed')
    if (BASE/'execution_complete.json').exists():raise ValueError('already executed')
    old=initial.verify();tasks=rows(BASE/'public_tasks.jsonl')
    for wg in WGS:
        selected=[t for t in tasks if t['wg']==wg]
        if not selected:continue
        db=HERE.parent/'relational'/(wg+'.sqlite');expected=old['sql_sources'][wg]['db_sha256']
        if sha(db)!=expected:raise ValueError('source changed')
        stat=structured.file_identity(db);receipts=[]
        for task in selected:
            r=json.loads((BASE/'arm_outputs/text2sql'/(task['id']+'.json')).read_text())
            outcome=structured.execute_generated(r,task,sql_db=db,expected_sql_sha=expected,
                source_guard_batch_verified=True,expected_sql_stat=stat)
            write(BASE/'executed/text2sql'/(task['id']+'.json'),outcome)
            receipts.append({'id':task['id'],'status':outcome['status']})
        if sha(db)!=expected or structured.file_identity(db)!=stat:raise ValueError('source changed')
        write(BASE/'source_guards'/(wg+'.json'),{'db_sha256':expected,'unchanged':True,'items':receipts})
        print(json.dumps({'recovery_execution_wg':wg,'n':len(selected)}),flush=True)
    write(BASE/'execution_complete.json',{'n':129,'all_ids_complete':True,'sources_unchanged':True})


def merge_analyze():
    p=verify();json.loads((BASE/'execution_complete.json').read_text())
    selected=set(p['cohort_ids']);tasks=rows(HERE/'public_tasks.jsonl');predictions=[];statuses=[]
    for task in tasks:
        root=BASE if task['id'] in selected else HERE
        path=root/'executed/text2sql'/(task['id']+'.json');r=json.loads(path.read_text())
        if r['id']!=task['id'] or r['repair_sha256']!=task['repair_sha256']:raise ValueError('identity mismatch')
        predictions.append({'id':r['id'],'repair_sha256':r['repair_sha256'],'records':r['records']})
        statuses.append({'id':r['id'],'repair_sha256':r['repair_sha256'],'status':r['status'].upper(),'phase':'operational_http402_recovery' if task['id'] in selected else 'initial_received_answer','artifact_path':str(path),'artifact_sha256':sha(path)})
    union=HERE/'recovered_union';(union/'text2sql').mkdir(parents=True,exist_ok=True)
    for name,values in [('predictions.jsonl',predictions),('statuses.jsonl',statuses)]:
        (union/'text2sql'/name).write_text(''.join(structured.canonical(v)+'\n' for v in values))
    sys.path.insert(0,str(initial.BUNDLE));import score_predictions
    raw=score_predictions.run(HERE/'cohort/tasks.jsonl',HERE/'cohort/reference_gold.jsonl',union/'text2sql/predictions.jsonl')
    status=analysis.unique(statuses)
    results={r['id']:analysis.gated(r,status[r['id']]['status']) for r in raw['outcomes']}
    if len(results)!=378:raise ValueError('denominator mismatch')
    write(union/'text2sql/raw_scores.json',raw);write(union/'text2sql/failure_gated_scores.json',list(results.values()))
    contract=analysis.unique(rows(HERE/'cohort/tasks.jsonl'));parts=defaultdict(list)
    parent=set(json.loads(initial.PREVIOUS_PROTOCOL.read_text())['cohort_ids'])
    for id,r in results.items():
        t=contract[id];types=[f['type'] for f in t['required_fields']]
        shape=('ranked' if t['collection']['kind']=='top_k_boundary_ties' else 'boolean' if types==['boolean'] else
            'scalar_numeric' if len(types)==1 and types[0] in {'integer','number'} else
            'grouped_numeric' if any(s in {'integer','number'} for s in types) else 'enumeration')
        for key in ['WG:'+id.split('_')[0],'phase:'+id.split('_')[1],'generation_phase:'+status[id]['phase'],
            'cohort_phase:'+('parent371' if id in parent else 'extension7'),
            'asked_fields:'+('multiple' if len(types)>1 else 'single'),'collection:'+t['collection']['kind'],
            'contract_output_type:'+shape]:parts[key].append(r)
    previous=analysis.unique(json.loads(initial.PREVIOUS_SCORES.read_text()));overlap={id:results[id] for id in previous}
    usage_initial=json.loads((HERE/'usage.json').read_text());usage_recovery=json.loads((BASE/'usage.json').read_text())
    output={'kind':'All378 actual-DDL SQL union with separate unanswered HTTP402 operational recovery',
        'cohort_n':378,'overall':analysis.summary(list(results.values())),
        'strata':{k:analysis.summary(v) for k,v in sorted(parts.items())},
        'paired_previous_SQL371':[dict(a='actual_ddl_recovered_union',b='previous_sql_interface',**analysis.paired(overlap,previous,m)) for m in ['f1','exact']],
        'initial_full378_analysis_path':str(HERE/'analysis.json'),'initial_full378_analysis_sha256':sha(HERE/'analysis.json'),
        'initial_protocol_sha256':sha(HERE/'protocol.json'),'recovery_protocol_sha256':sha(BASE/'protocol.json'),
        'known_cost_usd':usage_initial['known_actual_cost_usd']+usage_recovery['known_actual_cost_usd'],
        'unknown_cost_attempts':usage_initial['unknown_cost_attempts']+usage_recovery['unknown_cost_attempts'],
        'initial_phase_usage':usage_initial,'recovery_phase_usage':usage_recovery,
        'received_answer_regeneration_n':0,'original_previous_outputs_preserved':True,
        'limitations':initial.verify()['limitations']}
    write(union/'analysis.json',output)
    r=output['overall'];(union/'performance_table.md').write_text('| SQL actual DDL | N | Complete-record F1 | Exact output | Failures |\n| --- | ---: | ---: | ---: | ---: |\n'+f"| Recovered union | 378 | {r['requested_complete_record_macro_f1']:.4f} | {r['exact_outputs']}/378 | {r['failed_n']} |\n")
    print(json.dumps(r),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['freeze','generate','execute','analyze'])
    args=parser.parse_args();{'freeze':freeze,'generate':generate,'execute':execute,'analyze':merge_analyze}[args.action]()
