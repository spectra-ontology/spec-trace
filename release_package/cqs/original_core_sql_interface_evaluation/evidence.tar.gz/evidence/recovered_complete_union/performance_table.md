| SQL actual DDL | N | Complete-record F1 | Exact output | Failures |
| --- | ---: | ---: | ---: | ---: |
| Completed operational union | 378 | 0.6097 | 215/378 | 32 |
