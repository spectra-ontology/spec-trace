#!/usr/bin/env python3
"""Read-only final audit and fixed-cohort comparison, without model/SQL calls."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
EMP = HERE.parent
sys.path.insert(0, str(EMP))
import analyze_predictions as analysis
import structured_adapter as structured
import run as initial
import recovery
import recovery_budget20 as last
from prepare import ROOT, rows, sha, write


def main():
    for target in ['completion_audit.json', 'paired_previous_SQL378.json', 'sql_failure_diagnostic.json']:
        if (HERE / target).exists():
            raise ValueError('Final audit is immutable; use a separately named audit if necessary')
    initial_protocol = initial.verify()
    recovery.verify()
    last.verify()
    phases = [('initial', HERE), ('http402', recovery.BASE), ('budget20', last.BASE)]
    generation_pins = 0
    phase_counts = {}
    request_n = response_attempt_n = 0
    for name, folder in phases:
        complete = json.loads((folder / 'generation_complete.json').read_text())
        pins = complete.get('prediction_and_raw_call_pins', complete.get('artifact_pins'))
        for relative, expected in pins.items():
            assert sha(folder / relative) == expected, (name, relative)
            generation_pins += 1
        requests = list((folder / 'calls').glob('*.request.json'))
        attempts = list((folder / 'calls').glob('*.response.json'))
        request_n += len(requests)
        response_attempt_n += len(attempts)
        phase_counts[name] = {'generation_statuses': complete['status_counts'],
                             'request_files': len(requests), 'response_attempt_files': len(attempts)}
    tasks = analysis.unique(rows(HERE / 'cohort/tasks.jsonl'))
    public = analysis.unique(rows(HERE / 'public_tasks.jsonl'))
    status = analysis.unique(rows(last.UNION / 'text2sql/statuses.jsonl'))
    new = analysis.unique(json.loads((last.UNION / 'text2sql/failure_gated_scores.json').read_text()))
    assert len(tasks) == 378 and set(tasks) == set(public) == set(status) == set(new)
    model_counts, providers, stops, errors = Counter(), Counter(), Counter(), Counter()
    diagnostics = []
    executed_n = 0
    for identifier, task in tasks.items():
        entry = status[identifier]
        assert entry['repair_sha256'] == new[identifier]['repair_sha256'] == task['repair_sha256']
        path = Path(entry['artifact_path'])
        assert sha(path) == entry['artifact_sha256']
        result = json.loads(path.read_text())
        assert result['private_evidence_read_by_generator'] is False
        call = result['call']
        assert call['ok'] is True and call['content'] is not None
        request = Path(call['request_path'])
        response = Path(call['response_path'])
        payload = json.loads(request.read_text())['payload']
        raw = json.loads(response.read_text())
        assert raw['http_status'] == 200
        model_counts[raw['response']['model']] += 1
        providers[raw['response']['provider']] += 1
        stops[call['finish_reason']] += 1
        schema = json.loads((HERE / 'schemas' / (task['id'].split('_')[0] + '_sql.json')).read_text())
        expected_messages = structured.messages_for(dict(public[identifier], sql_schema=schema), 'B')
        assert payload['messages'] == expected_messages
        assert payload['max_tokens'] == initial_protocol['generation_tokens'] == 4096
        assert payload['model'] == initial_protocol['model']
        initial_request = HERE / 'calls' / (identifier + '_Text2SQL.request.json')
        assert payload == json.loads(initial_request.read_text())['payload']
        assert json.loads(request.read_text())['authorization_header_omitted'] is True
        if entry['status'] == 'OK':
            execution = result['execution']
            assert execution['status'] == 'OK' and execution['complete'] is True
            assert execution['truncated'] is False and execution['immutable_read_only'] is True
            assert execution['source_guard_batch_verified'] is True
            executed_n += 1
        else:
            assert entry['status'] in {'GENERATION_FORMAT_ERROR', 'ABSTAIN'}
            assert new[identifier]['f1'] == 0 and new[identifier]['exact'] is False
            error = result.get('error_class')
            errors[error or entry['status']] += 1
            diagnostics.append({'id': identifier, 'repair_sha256': task['repair_sha256'],
                'status': entry['status'], 'category': 'JSON_envelope_or_format' if entry['status'] == 'GENERATION_FORMAT_ERROR' else 'model_abstention',
                'actual_error_class': error, 'actual_error': result.get('error'),
                'finish_reason': call['finish_reason'], 'artifact_path': str(path), 'artifact_sha256': sha(path),
                'request_path': str(request), 'request_sha256': sha(request),
                'response_path': str(response), 'response_sha256': sha(response)})
    assert model_counts == {initial_protocol['model']: 378}
    assert providers == {'Anthropic': 378}
    assert executed_n == 346 and len(diagnostics) == 32
    # All comparisons require the exact same repair contract, not just matching IDs.
    old371_path = HERE / 'input_snapshots/previous371_sql_scores.json'
    old7_base = EMP / 'runs/pending-recheck-additions'
    old7_path = old7_base / 'text2sql/failure_gated_scores.json'
    old371 = analysis.unique(json.loads(old371_path.read_text()))
    old7 = analysis.unique(json.loads(old7_path.read_text()))
    previous7_protocol = json.loads((old7_base / 'protocol.json').read_text())
    assert len(old371) == 371 and len(old7) == 7 and not set(old371) & set(old7)
    assert set(old371) | set(old7) == set(tasks)
    for identifier, previous in dict(old371, **old7).items():
        assert previous['repair_sha256'] == tasks[identifier]['repair_sha256']
    assert previous7_protocol['tasks_sha256'] == sha(HERE / 'input_snapshots/extension7/tasks.jsonl')
    assert previous7_protocol['gold_sha256'] == sha(HERE / 'input_snapshots/extension7/reference_gold.jsonl')
    old378 = dict(old371, **old7)
    comparisons = {}
    for name, before in [('parent371', old371), ('extension7', old7), ('all378', old378)]:
        after = {identifier: new[identifier] for identifier in before}
        comparisons[name] = {'n': len(before), 'previous': analysis.summary(list(before.values())),
            'actual_DDL': analysis.summary(list(after.values())),
            'paired': [analysis.paired(after, before, metric) for metric in ['f1', 'exact']],
            'exact_transition': dict(Counter(('correct' if before[i]['exact'] else 'incorrect') + '_to_' +
                                             ('correct' if after[i]['exact'] else 'incorrect') for i in before))}
    inputs = {str(p): sha(p) for p in [old371_path, old7_path, old7_base / 'protocol.json',
                                     last.UNION / 'analysis.json', last.UNION / 'text2sql/failure_gated_scores.json']}
    write(HERE / 'paired_previous_SQL378.json', {'kind': 'Post-run fixed-cohort paired comparison, no new predictions',
        'comparisons': comparisons, 'inputs': inputs, 'code_sha256': sha(__file__),
        'limitations': ['Same task/data/model budgets; SQL schema interface changed, with one new generation per task.',
                        'No repeated-seed prompt effect estimate; no storage-medium causal superiority claim.',
                        '378 admitted originals only; not performance on all Core560.']})
    write(HERE / 'sql_failure_diagnostic.json', {'cohort_n': 378,
        'status_counts': dict(Counter(r['status'] for r in status.values())),
        'execution_OK': executed_n, 'execution_error_n': 0,
        'missing_table_or_relation_prefix_n': 0, 'SQL_syntax_execution_error_n': 0,
        'SQL_type_execution_error_n': 0, 'SQL_executor_resource_error_n': 0,
        'generation_error_classes': dict(errors), 'finish_reasons': dict(stops), 'failures': diagnostics,
        'scope': 'Actual final received outcomes, not causal classification of prior SQL failures.',
        'inputs': inputs, 'code_sha256': sha(__file__)})
    # Secret is checked only in memory. Never record its bytes or a reversible derivative.
    sys.path.insert(0, str(ROOT / 'scripts/common/common'))
    import credentials
    secret = credentials.secret('OPENROUTER_API_KEY').encode()
    assert secret
    scanned, matches = 0, []
    for path in HERE.rglob('*'):
        if path.is_file():
            scanned += 1
            if secret in path.read_bytes():
                matches.append(str(path.relative_to(HERE)))
    assert not matches, 'Credential bytes found in owned evidence'
    audit = {'status': 'PASS', 'checked_utc': datetime.now(timezone.utc).isoformat(),
        'cohort_n': 378, 'received_answers_n': 378, 'received_answer_regeneration_n': 0,
        'same_complete_initial_payload_n': 378, 'generation_pins_verified': generation_pins,
        'raw_request_files_n': request_n, 'raw_response_attempt_files_n': response_attempt_n,
        'provider_counts': dict(providers), 'model_counts': dict(model_counts),
        'finish_reasons': dict(stops), 'complete_immutable_read_only_execution_n': executed_n,
        'failed_outcomes_retained_n': len(diagnostics), 'phases': phase_counts,
        'secret_exact_bytes_audit': {'files_scanned': scanned, 'matches_n': 0, 'secret_printed_or_saved': False},
        'summary': analysis.summary(list(new.values())),
        'known_cost_usd': json.loads((last.UNION / 'analysis.json').read_text())['known_cost_usd'],
        'unknown_cost_attempts': json.loads((last.UNION / 'analysis.json').read_text())['unknown_cost_attempts'],
        'code_sha256': sha(__file__), 'input_pins': inputs,
        'output_pins': {name: sha(HERE / name) for name in ['paired_previous_SQL378.json', 'sql_failure_diagnostic.json']},
        'model_calls': 0, 'query_execution_calls': 0, 'public_upload_or_external_verification_completed_by_this_audit': False}
    write(HERE / 'completion_audit.json', audit)
    print(json.dumps({'status': 'PASS', 'cohort_n': 378, 'audit_sha256': sha(HERE / 'completion_audit.json'),
                      'paired_sha256': sha(HERE / 'paired_previous_SQL378.json'), 'summary': audit['summary']}), flush=True)


if __name__ == '__main__':
    main()
