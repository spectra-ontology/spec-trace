#!/usr/bin/env python3
"""Build value-free SQL cards from the actual immutable SQLite catalog.

Only catalog definitions, structural labels and relationship names reach the
schema card. Business values, cardinalities, answers and repair evidence do not.
This file never calls a model or changes a database.
"""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
EMP = BASE.parent
ROOT = next(p for p in BASE.parents if (p / '.git').exists())
BUNDLE = Path('/home/sihyeon/workspace/spectra-public/spec-trace/release_package/cqs/original_core_repair')
EXTENSION = EMP / 'pending_recheck/final_bundle'
WGS = ('RAN1', 'RAN2', 'RAN3', 'RAN4', 'RAN5')
sys.path.insert(0, str(EMP))
import run_evaluation
import structured_adapter as structured


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2,
                               allow_nan=False) + '\n')


def rows(path):
    return [json.loads(s) for s in path.read_text().splitlines() if s.strip()]


def catalog(db, manifest, verify_directions=True):
    """Introspect DDL and independently compare actual stored edge directions."""
    started = time.monotonic()
    con = sqlite3.connect(Path(db).resolve().as_uri() + '?mode=ro&immutable=1', uri=True)
    con.execute('PRAGMA query_only=ON')
    con.execute('PRAGMA cache_size=-32768')
    con.set_progress_handler(lambda: int(time.monotonic() - started > 60), 10000)
    catalog_rows = con.execute("SELECT name,sql FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()
    tables = {name: ddl for name, ddl in catalog_rows
              if not name.startswith(('_', 'sqlite_'))}
    columns = {}
    for table in tables:
        quoted = '"' + table.replace('"', '""') + '"'
        columns[table] = [dict(zip(('cid', 'name', 'type', 'notnull', 'dflt_value', 'pk'), r))
                          for r in con.execute('PRAGMA table_info(' + quoted + ')')]
        if any(c['dflt_value'] is not None for c in columns[table]):
            raise ValueError('unexpected default value in value-free DDL')
    expected = manifest['schema']
    label_tables = set(expected['label_tables'])
    rel_names = {'rel_' + name for name in expected['relationship_tables']}
    generic = {'node', 'node_label', 'node_property', 'edge', 'node_identity'}
    if set(tables) != label_tables | rel_names | generic:
        raise ValueError('catalog table inventory differs from frozen encoding')
    for label, props in expected['label_tables'].items():
        if {c['name'] for c in columns[label]} != set(props):
            raise ValueError('label column inventory mismatch: ' + label)
    for rel in rel_names:
        if [c['name'] for c in columns[rel]] != ['edge_id', 'src_id', 'dst_id']:
            raise ValueError('directed relationship columns differ: ' + rel)
    frozen_triples = {tuple(r) for r in expected['directed_relationships']}
    actual_triples = frozen_triples
    if verify_directions:
        actual_triples = set(con.execute('SELECT DISTINCT s.label,e.rel_type,t.label '
            'FROM edge e JOIN node_label s ON s.node_id=e.src_id '
            'JOIN node_label t ON t.node_id=e.dst_id').fetchall())
        if actual_triples != frozen_triples:
            raise ValueError('actual source/destination label directions differ from frozen manifest')
    # Relationship prefix is emitted on every actual table binding, never just
    # implied by a prose convention. The names are verified against sqlite_master.
    directions = defaultdict(list)
    for source, rel_type, target in sorted(actual_triples):
        table = 'rel_' + rel_type
        if table not in tables or source not in tables or target not in tables:
            raise ValueError('unknown actual relationship/endpoint table')
        directions[table].append([source, target])
    card = {
        'dialect': 'SQLite 3',
        'ddl': '\n'.join(tables[name].rstrip(';') + ';' for name in sorted(tables)),
        'relationship_direction': dict(directions),
        'join_convention': 'For each relationship_direction table, pairs are [source label table,destination label table]. Join source.node_id=relationship.src_id and destination.node_id=relationship.dst_id. All node/label tables share node_id. Use exactly the SQL table names in DDL, including rel_ prefixes; graph relationship names without rel_ are not SQL tables.',
        'value_codec': expected['value_codec'],
        'auxiliary_identity_codec': expected['auxiliary_identity_codec'],
    }
    con.close()
    return card, {'table_name_agreement': True, 'column_name_agreement': True,
                  'direction_agreement': True, 'direction_actual_rows_checked': verify_directions,
                  'public_table_n': len(tables), 'label_table_n': len(label_tables),
                  'relationship_table_n': len(rel_names), 'structural_direction_n': len(actual_triples),
                  'value_free_business_rows_emitted': 0,
                  'schema_characters': len(structured.canonical(card)),
                  'elapsed_s': round(time.monotonic() - started, 3)}


def historical_cost(public, cards):
    """Estimate from all371 previous SQL generations, irrespective of success."""
    chosen = {}
    for name in ('original-core-transport-supplement', 'additional-originals-transport-supplement'):
        for file in (EMP / 'runs' / name / 'arm_outputs/text2sql').glob('*.json'):
            obj = json.loads(file.read_text())
            chosen[obj['id']] = obj
    if len(chosen) != 371 or not set(chosen).issubset({t['id'] for t in public}):
        raise ValueError('historical SQL denominator differs from previous371')
    missing_usage_mean = sum((o['call'].get('usage') or {}).get('prompt_tokens', 0)
                             for o in chosen.values()) / sum(bool(o['call'].get('usage')) for o in chosen.values())
    old_completion_mean = sum((o['call'].get('usage') or {}).get('completion_tokens', 0)
                              for o in chosen.values()) / sum(bool(o['call'].get('usage')) for o in chosen.values())
    old_cost = old_tokens = old_completion = unknown = usage_n = 0
    estimate_prompt_tokens = 0.0
    ratios = []
    max_prompt_reservation = 0.0
    for task in public:
        history = chosen.get(task['id'])
        if history is None:
            wg_history = next(o for o in chosen.values() if o['id'].startswith(task['wg']+'_'))
            call = wg_history['call']
        else:
            call = history['call']
        usage = call.get('usage') or {}
        if history is not None:
            old_cost += call.get('known_actual_cost_usd', 0)
            unknown += call.get('unknown_cost_attempts', 0)
            old_tokens += usage.get('prompt_tokens', 0)
            old_completion += usage.get('completion_tokens', 0)
            usage_n += bool(usage)
        old_request = json.loads(Path(call['request_path']).read_text())['payload']
        old_chars = sum(len(m['content']) for m in old_request['messages'])
        new_task = dict(task, sql_schema=cards[task['wg']])
        new_chars = sum(len(m['content']) for m in structured.messages_for(new_task, 'B'))
        ratio = new_chars / old_chars
        ratios.append(ratio)
        estimate_prompt_tokens += usage.get('prompt_tokens', missing_usage_mean) * ratio
        max_prompt_reservation += new_chars / 3 * .000005
    extension_n = len(public) - len(chosen)
    expected = estimate_prompt_tokens * .000005 + (old_completion + extension_n * old_completion_mean) * .000025
    return {
        'n': len(public), 'historical_n': len(chosen), 'extension_n': extension_n,
        'historical_SQL_known_cost_usd': old_cost,
        'historical_unknown_cost_attempts': unknown, 'historical_usage_available_n': usage_n,
        'historical_prompt_tokens': old_tokens, 'historical_completion_tokens': old_completion,
        'new_prompt_estimated_tokens': estimate_prompt_tokens,
        'new_expected_cost_using_previous_completion_lengths_usd': expected,
        'prompt_character_ratio_min': min(ratios), 'prompt_character_ratio_max': max(ratios),
        'one_attempt_client_chars_div3_max_output_reservation_usd': max_prompt_reservation + len(public) * structured.MAX_GENERATION_TOKENS * .000025,
        'same_payload_transport_retry_attempts_max': 2,
        'not_a_cost_guarantee': 'Old usage scaled by new/old prompt characters is an estimate, not a tokenizer. New completion lengths, provider tokenization and retries may differ; unknown old attempt cost is excluded from historical known amount. No performance-dependent item selection.'}


def prepare():
    if (BASE / 'protocol.json').exists():
        raise ValueError('already frozen; preparation cannot mutate protocol inputs')
    parent_tasks = rows(BUNDLE / 'tasks.jsonl')
    extension_tasks = rows(EXTENSION / 'tasks.jsonl')
    tasks = parent_tasks + extension_tasks
    public = [run_evaluation.public_task(t) for t in tasks]
    union = json.loads((EMP / 'runs/admitted-union/protocol.json').read_text())
    parent_ids = {t['id'] for t in parent_tasks}
    extra_ids = {t['id'] for t in extension_tasks}
    if (len(public) != 378 or len(parent_ids) != 371 or len(extra_ids) != 7
            or parent_ids != set(union['cohort_ids']) or parent_ids & extra_ids):
        raise ValueError('fixed all378 cohort differs')
    gold = rows(BUNDLE / 'reference_gold.jsonl') + rows(EXTENSION / 'reference_gold.jsonl')
    if {t['id'] for t in gold} != {t['id'] for t in tasks} or len(gold) != 378:
        raise ValueError('gold denominator differs from fixed378')
    (BASE / 'cohort').mkdir(exist_ok=True)
    (BASE / 'cohort/tasks.jsonl').write_text(''.join(structured.canonical(t) + '\n' for t in tasks))
    (BASE / 'cohort/reference_gold.jsonl').write_text(''.join(structured.canonical(t) + '\n' for t in gold))
    (BASE / 'public_tasks.jsonl').write_text(''.join(structured.canonical(t) + '\n' for t in public))
    cards = {}; checks = {}
    for wg in WGS:
        db = EMP / 'relational' / (wg + '.sqlite')
        manifest_path = EMP / 'relational' / (wg + '.manifest.json')
        manifest = json.loads(manifest_path.read_text())
        before = sha(db)
        if before != manifest['db_sha256']:
            raise ValueError('SQL frozen source hash differs: ' + wg)
        card, check = catalog(db, manifest)
        if sha(db) != before:
            raise ValueError('immutable source changed during schema preparation')
        cards[wg] = card
        check.update(db_path=str(db), db_sha256=before, db_unchanged=True,
                     manifest_path=str(manifest_path), manifest_sha256=sha(manifest_path))
        checks[wg] = check
        write(BASE / 'schemas' / (wg + '_sql.json'), card)
        print(json.dumps({'WG': wg, 'schema_validation': 'PASS', 'chars': check['schema_characters']}), flush=True)
    write(BASE / 'schema_validation.json', {'status': 'PASS', 'groups': checks,
        'value_free': True, 'gold_reference_or_business_values_in_schema': False,
        'model_calls': 0, 'expert_validation_n': 0})
    estimate = historical_cost(public, cards)
    write(BASE / 'cost_estimate.json', estimate)
    write(BASE / 'preparation.json', {'status': 'PREPARED_NOT_MODEL_EXECUTED',
        'prepared_utc': datetime.now(timezone.utc).isoformat(), 'cohort_n': 378,
        'bundle_path': str(BUNDLE), 'tasks_sha256': sha(BUNDLE / 'tasks.jsonl'),
        'gold_sha256': sha(BUNDLE / 'reference_gold.jsonl'), 'manifest_sha256': sha(BUNDLE / 'manifest.json'),
        'public_tasks_sha256': sha(BASE / 'public_tasks.jsonl'),
        'schema_validation_sha256': sha(BASE / 'schema_validation.json'),
        'extension_bundle_path': str(EXTENSION), 'extension_n': 7,
        'extension_tasks_sha256': sha(EXTENSION / 'tasks.jsonl'),
        'extension_gold_sha256': sha(EXTENSION / 'reference_gold.jsonl'),
        'extension_manifest_sha256': sha(EXTENSION / 'manifest.json'),
        'cohort_tasks_sha256': sha(BASE / 'cohort/tasks.jsonl'),
        'cohort_gold_sha256': sha(BASE / 'cohort/reference_gold.jsonl'),
        'schema_pins': {str(f.relative_to(BASE)): sha(f) for f in (BASE / 'schemas').glob('*.json')},
        'existing_runtime_modified': False, 'new_model_calls': 0})
    print(json.dumps(estimate), flush=True)


if __name__ == '__main__':
    prepare()
