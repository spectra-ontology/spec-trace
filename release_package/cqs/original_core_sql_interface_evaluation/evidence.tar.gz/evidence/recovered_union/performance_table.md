| SQL actual DDL | N | Complete-record F1 | Exact output | Failures |
| --- | ---: | ---: | ---: | ---: |
| Recovered union | 378 | 0.5779 | 203/378 | 50 |
