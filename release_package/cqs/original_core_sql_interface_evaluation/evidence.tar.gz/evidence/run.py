#!/usr/bin/env python3
"""Pre-register and run an all-cohort SQL schema-interface intervention.

The original adapter, caller, database and scoring contracts are reused unchanged.
Only the value-free SQL schema card differs from the previous SQL interface.
"""
import argparse
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
EMP = BASE.parent
sys.path.insert(0, str(EMP))
import analyze_predictions as analysis
import structured_adapter as structured
from openrouter_client import MODEL, PROVIDER, OpenRouterCaller
from prepare import ROOT, WGS, rows, sha, write
BUNDLE=BASE/'input_snapshots/parent371'
EXTENSION=BASE/'input_snapshots/extension7'
PREVIOUS_PROTOCOL=BASE/'input_snapshots/previous371_protocol.json'
PREVIOUS_SCORES=BASE/'input_snapshots/previous371_sql_scores.json'


def freeze(budget):
    if (BASE/'protocol.json').exists():
        raise ValueError('protocol already frozen')
    prepared = json.loads((BASE/'preparation.json').read_text())
    validation = json.loads((BASE/'schema_validation.json').read_text())
    tasks = rows(BASE/'public_tasks.jsonl')
    if validation['status'] != 'PASS' or len(tasks) != 378 or len({t['id'] for t in tasks}) != 378:
        raise ValueError('complete378 validation required before calls')
    frozen_files = {
        str(p): sha(p) for p in [BASE/'prepare.py', BASE/'run.py', BASE/'test_interface.py',
            BASE/'preparation.json', BASE/'schema_validation.json', BASE/'cost_estimate.json',
            BASE/'test_results.json', BASE/'cohort/tasks.jsonl', BASE/'cohort/reference_gold.jsonl',
            BASE/'public_tasks.jsonl']
    }
    for name in ['structured_adapter.py','openrouter_client.py','run_evaluation.py','analyze_predictions.py']:
        frozen_files[str(EMP/name)] = sha(EMP/name)
    for path in [PREVIOUS_PROTOCOL,PREVIOUS_SCORES,BASE/'input_snapshots/provenance.json']:
        frozen_files[str(path)] = sha(path)
    for bundle in [BUNDLE, EXTENSION]:
        for name in ['tasks.jsonl','reference_gold.jsonl','manifest.json','score_predictions.py',
                     'original_scorer.py','scorer.py','typed_values.py']:
            frozen_files[str(bundle/name)] = sha(bundle/name)
    prompt_records = []
    for task in tasks:
        schema_path = BASE/'schemas'/(task['wg']+'_sql.json')
        frozen_files[str(schema_path)] = sha(schema_path)
        model_task = dict(task, sql_schema=json.loads(schema_path.read_text()))
        messages = structured.messages_for(model_task, 'B')
        prompt_records.append({'id':task['id'],'repair_sha256':task['repair_sha256'],
            'prompt_sha256':__import__('hashlib').sha256(structured.canonical(messages).encode()).hexdigest(),
            'prompt_characters':sum(len(m['content']) for m in messages)})
    (BASE/'planned_requests.jsonl').write_text(''.join(structured.canonical(r)+'\n' for r in prompt_records))
    frozen_files[str(BASE/'planned_requests.jsonl')] = sha(BASE/'planned_requests.jsonl')
    test = json.loads((BASE/'test_results.json').read_text())
    if test['status'] != 'PASS' or test['paid_model_calls'] != 0:
        raise ValueError('free synthetic and full prompt checks required')
    protocol = {'kind':'All378 new Text2SQL generation using actual value-free SQLite DDL',
        'frozen_utc':datetime.now(timezone.utc).isoformat(),'cohort_n':378,
        'parent371_n':371,'disjoint_extension_n':7,'cohort_ids':[t['id'] for t in tasks],
        'original_registered_n':560,'nonadmitted_n':182,
        'model':MODEL,'provider':PROVIDER,'provider_fallbacks':False,'model_fallbacks':False,
        'reasoning':{'enabled':False},'response_format':{'type':'json_object'},
        'temperature':'unsupported; omitted','generation_tokens':structured.MAX_GENERATION_TOKENS,
        'generation_workers':4,'execution_workers':2,'budget_guard_usd':float(budget),
        'retry_policy':{'transport_attempts':2,'retry_only':'429,5xx or network error',
            'identical_payload':True,'delay_seconds':2,'answer_quality_retry':False},
        'execution_limits':{'rows':structured.ROW_CAP,'bytes':structured.BYTE_CAP,'timeout_s':structured.TIMEOUT_SECONDS},
        'intervention':'Actual sqlite_master CREATE TABLE statements and actual rel_ prefixed source/destination table bindings replace previous manifest schema representation. All public tables/columns/directions are included; no business values, row counts, query examples, reference queries or repair reasons are supplied.',
        'control':'Same questions, requested contracts, data, model, provider, generation and execution limits; all378 new requests regardless of previous success or failure.',
        'failure_policy':'All378 retained. Execution or generation failure and abstention receive F1=0/exact=false, including empty gold. Operationally truncated records are retained for audit but are not complete answers.',
        'generation_before_execution':True,'performance_before_protocol_change':False,
        'comparison_primary_overlap_n':371,'comparison_extension7_when_available':True,
        'bootstrap':{'seed':20261014,'replicates':2000,'paired_metrics':['f1','exact']},
        'limitations':['One model and nonrepresentative admitted subset.',
            'One new generation per item; no multi-seed estimate of prompt effect.',
            'An interface intervention cannot establish causal superiority of a storage medium.',
            'Known usage excludes unknown transport charges; a cost estimate is not a token guarantee.'],
        'frozen_files':frozen_files,'sql_sources':validation['groups'],
        'preparation_sha256':sha(BASE/'preparation.json')}
    write(BASE/'protocol.json', protocol)
    print(json.dumps({'frozen_n':378,'protocol_sha256':sha(BASE/'protocol.json'),'paid_calls':0}),flush=True)


def verify():
    p = json.loads((BASE/'protocol.json').read_text())
    for name, expected in p['frozen_files'].items():
        if sha(name) != expected:
            raise ValueError('frozen input changed: '+name)
    return p


def generate():
    p = verify()
    if (BASE/'generation_complete.json').exists():
        raise ValueError('generation already complete; no performance-based rerun')
    tasks = rows(BASE/'public_tasks.jsonl')
    if any((BASE/'arm_outputs/text2sql').glob('*.json')) or any((BASE/'calls').glob('*')):
        raise ValueError('existing predictions/calls; completion recovery requires a separately registered phase')
    sys.path.insert(0,str(ROOT/'scripts/common/common'))
    import credentials
    caller = OpenRouterCaller(BASE,credentials.secret('OPENROUTER_API_KEY'),p['budget_guard_usd'])
    def job(task):
        model_task = dict(task,sql_schema=json.loads((BASE/'schemas'/(task['wg']+'_sql.json')).read_text()))
        try:
            result = structured.evaluate(model_task,'B',caller,BASE)
        except Exception as exc:
            result = {'id':task['id'],'wg':task['wg'],'repair_sha256':task['repair_sha256'],
                'records':[],'status':'ADAPTER_EXCEPTION','error_class':type(exc).__name__}
        write(BASE/'arm_outputs/text2sql'/(task['id']+'.json'),result)
        return result['status']
    counts = Counter()
    with ThreadPoolExecutor(max_workers=p['generation_workers']) as executor:
        futures = [executor.submit(job,t) for t in tasks]
        for future in as_completed(futures):
            counts[future.result()] += 1
            if sum(counts.values())%10 == 0:
                print(json.dumps({'generated_n':sum(counts.values()),'required':378,'statuses':dict(counts),
                    'known_cost_usd':caller.actual_cost}),flush=True)
    files = sorted((BASE/'arm_outputs/text2sql').glob('*.json'))
    results = [json.loads(f.read_text()) for f in files]
    if {r['id'] for r in results} != set(p['cohort_ids']) or len(results) != 378:
        raise ValueError('generation incomplete denominator')
    pinned = {str(f.relative_to(BASE)):sha(f) for folder in ['arm_outputs/text2sql','predictions/Text2SQL','calls']
              for f in (BASE/folder).glob('*.json')}
    write(BASE/'generation_complete.json',{'n':378,'status_counts':dict(counts),
        'all_ids_complete':True,'protocol_sha256':sha(BASE/'protocol.json'),
        'usage':caller.summary_unlocked(),'prediction_and_raw_call_pins':pinned})


def execute():
    p = verify()
    generation = json.loads((BASE/'generation_complete.json').read_text())
    if generation['n'] != 378 or not generation['all_ids_complete']:
        raise ValueError('all predictions must be frozen before SQL execution')
    for name, expected in generation['prediction_and_raw_call_pins'].items():
        if sha(BASE/name) != expected:raise ValueError('generation artifact changed')
    if (BASE/'execution_complete.json').exists():raise ValueError('execution already complete')
    tasks = rows(BASE/'public_tasks.jsonl')
    for wg in WGS:
        selected = [t for t in tasks if t['wg']==wg]
        db = EMP/'relational'/(wg+'.sqlite')
        expected = p['sql_sources'][wg]['db_sha256']
        if sha(db) != expected:raise ValueError('SQL source changed before execution')
        stat = structured.file_identity(db)
        def job(t):
            record = json.loads((BASE/'arm_outputs/text2sql'/(t['id']+'.json')).read_text())
            result = structured.execute_generated(record,t,sql_db=db,expected_sql_sha=expected,
                source_guard_batch_verified=True,expected_sql_stat=stat)
            write(BASE/'executed/text2sql'/(t['id']+'.json'),result)
            return {'id':t['id'],'status':result['status']}
        with ThreadPoolExecutor(max_workers=p['execution_workers']) as executor:
            receipts = [f.result() for f in as_completed([executor.submit(job,t) for t in selected])]
        if sha(db) != expected or structured.file_identity(db) != stat:
            raise ValueError('read-only source changed during execution')
        write(BASE/'source_guards'/(wg+'.json'),{'db_sha256':expected,'before_stat':stat,
            'after_stat':structured.file_identity(db),'unchanged':True,'items':receipts})
        print(json.dumps({'wg':wg,'executed_n':len(receipts),'statuses':dict(Counter(r['status'] for r in receipts))}),flush=True)
    predictions=[];statuses=[]
    for task in tasks:
        file=BASE/'executed/text2sql'/(task['id']+'.json')
        result=json.loads(file.read_text())
        predictions.append({'id':task['id'],'repair_sha256':task['repair_sha256'],'records':result['records']})
        statuses.append({'id':task['id'],'repair_sha256':task['repair_sha256'],'status':result['status'].upper(),
            'artifact':str(file.relative_to(BASE))})
    for name,values in [('predictions.jsonl',predictions),('statuses.jsonl',statuses)]:
        file=BASE/'text2sql'/name;file.parent.mkdir(exist_ok=True)
        file.write_text(''.join(structured.canonical(r)+'\n' for r in values))
    write(BASE/'execution_complete.json',{'n':378,'all_ids_complete':True,'sql_source_unchanged':True,
        'predictions_sha256':sha(BASE/'text2sql/predictions.jsonl'),
        'statuses_sha256':sha(BASE/'text2sql/statuses.jsonl')})


def summarize():
    p=verify()
    complete=json.loads((BASE/'execution_complete.json').read_text())
    for name,key in [('predictions.jsonl','predictions_sha256'),('statuses.jsonl','statuses_sha256')]:
        if sha(BASE/'text2sql'/name)!=complete[key]:raise ValueError('executed prediction changed')
    sys.path.insert(0,str(BUNDLE))
    import score_predictions
    raw=score_predictions.run(BASE/'cohort/tasks.jsonl',BASE/'cohort/reference_gold.jsonl',BASE/'text2sql/predictions.jsonl')
    tasks=analysis.unique(rows(BASE/'cohort/tasks.jsonl'))
    statuses=analysis.unique(rows(BASE/'text2sql/statuses.jsonl'))
    if set(statuses)!=set(tasks) or len(raw['outcomes'])!=378:raise ValueError('complete denominator required')
    result={r['id']:analysis.gated(r,statuses[r['id']]['status']) for r in raw['outcomes']}
    write(BASE/'text2sql/raw_scores.json',raw)
    write(BASE/'text2sql/failure_gated_scores.json',list(result.values()))
    partitions=defaultdict(list)
    parent_ids=set(json.loads(PREVIOUS_PROTOCOL.read_text())['cohort_ids'])
    for id,r in result.items():
        task=tasks[id];types=[f['type'] for f in task['required_fields']]
        shape=('ranked' if task['collection']['kind']=='top_k_boundary_ties' else
            'boolean' if types==['boolean'] else 'scalar_numeric' if len(types)==1 and types[0] in {'integer','number'} else
            'grouped_numeric' if any(t in {'integer','number'} for t in types) else 'enumeration')
        for key in ['WG:'+id.split('_')[0],'phase:'+id.split('_')[1],
            'cohort_phase:'+('parent371' if id in parent_ids else 'extension7'),
            'asked_fields:'+('multiple' if len(types)>1 else 'single'),
            'collection:'+task['collection']['kind'],'contract_output_type:'+shape]:partitions[key].append(r)
    previous=analysis.unique(json.loads(PREVIOUS_SCORES.read_text()))
    overlap={id:result[id] for id in previous}
    if set(previous)!=parent_ids:raise ValueError('previous SQL371 cohort mismatch')
    comparisons=[dict(a='sql_actual_ddl_v2',b='previous_sql_interface',**analysis.paired(overlap,previous,m)) for m in ['f1','exact']]
    output={'kind':'New all378 SQL predictions with actual DDL interface; complete failure-gated denominator',
        'cohort_n':378,'overall':analysis.summary(list(result.values())),
        'strata':{k:analysis.summary(v) for k,v in sorted(partitions.items())},
        'paired_previous_SQL371':comparisons,'previous_SQL371':analysis.summary(list(previous.values())),
        'protocol_sha256':sha(BASE/'protocol.json'),'generation_sha256':sha(BASE/'generation_complete.json'),
        'execution_sha256':sha(BASE/'execution_complete.json'),
        'previous_scores_sha256':sha(PREVIOUS_SCORES),
        'usage':json.loads((BASE/'usage.json').read_text()),'limitations':p['limitations']}
    write(BASE/'analysis.json',output)
    r=output['overall']
    (BASE/'performance_table.md').write_text('| SQL interface | N | Complete-record macro F1 | Exact output | Failures |\n| --- | ---: | ---: | ---: | ---: |\n'+
        f"| Actual DDL v2 | {r['n']} | {r['requested_complete_record_macro_f1']:.4f} | {r['exact_outputs']}/{r['n']} | {r['failed_n']} |\n")
    print(json.dumps(output['overall']),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['freeze','generate','execute','analyze'])
    parser.add_argument('--budget',type=float,default=25.0)
    args=parser.parse_args()
    {'freeze':lambda:freeze(args.budget),'generate':generate,'execute':execute,'analyze':summarize}[args.action]()
