#!/usr/bin/env python3
"""Free checks on complete prompts and an independent synthetic SQL execution."""
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE.parent))
import structured_adapter as structured
from prepare import rows, sha, write
BUNDLE=BASE/'input_snapshots/parent371'
EXTENSION=BASE/'input_snapshots/extension7'


class MockCaller:
    def __init__(self):self.calls=0
    def call(self,request_id,messages,max_tokens):
        self.calls+=1
        assert max_tokens==4096 and 'gold' not in json.loads(messages[1]['content'])
        return {'ok':True,'content':json.dumps({'query':'SELECT COUNT(*) AS count FROM "Thing"','abstain':False}),
                'provider':'Anthropic','finish_reason':'stop','usage':{}}


def test():
    public=rows(BASE/'public_tasks.jsonl')
    original={t['id']:t for t in rows(BUNDLE/'tasks.jsonl')+rows(EXTENSION/'tasks.jsonl')}
    assert len(public)==len(original)==378
    for task in public:
        assert task['question_en']==original[task['id']]['question_en']
        assert task['repair_sha256']==original[task['id']]['repair_sha256']
        schema=json.loads((BASE/'schemas'/(task['wg']+'_sql.json')).read_text())
        msgs=structured.messages_for(dict(task,sql_schema=schema),'B')
        visible=json.loads(msgs[1]['content'])
        assert set(visible)=={'question','output_format','schema'}
        assert visible['question']==task['question_en']
        assert all(f['name'] not in {'reference_query','original_query','source_column_or_expression'} for f in visible['output_format']['required_fields'])
        assert 'reference_query' not in visible['schema'] and 'gold' not in visible['schema']
        assert 'ddl' in schema and 'native_property_types' not in schema
        assert all(name.startswith('rel_') for name in schema['relationship_direction'])
        assert all('CREATE TABLE "'+name+'"' in schema['ddl'] for name in schema['relationship_direction'])
    rejected=False
    try:structured.messages_for(dict(public[0],reference_query='SECRET',sql_schema=schema),'B')
    except ValueError:rejected=True
    assert rejected
    with tempfile.TemporaryDirectory(prefix='spectra_sql_v2_synthetic_') as temp:
        root=Path(temp);db=root/'fixture.sqlite'
        con=sqlite3.connect(db);con.execute('CREATE TABLE "Thing"(node_id INTEGER PRIMARY KEY,value ANY) STRICT')
        con.executemany('INSERT INTO "Thing" VALUES(?,?)',[(1,'a'),(2,'b')]);con.commit();con.close()
        task={'id':'SYNTHETIC_1','wg':'SYNTHETIC','repair_sha256':'0'*64,'question_en':'How many Thing nodes are there?',
            'required_fields':[{'name':'count','type':'integer','nullable':False}],
            'collection':{'kind':'unordered_records'},'cardinality_policy':{'mode':'exact','value':1},
            'sql_schema':{'ddl':'CREATE TABLE "Thing"(node_id INTEGER PRIMARY KEY,value ANY) STRICT;'}}
        before=sha(db);caller=MockCaller()
        record=structured.evaluate(task,'B',caller,root)
        assert caller.calls==1 and record['status']=='QUERY_READY'
        executed=structured.execute_generated(record,task,sql_db=db,expected_sql_sha=before)
        assert executed['status']=='OK' and executed['records']==[{'count':2}] and sha(db)==before
        try:structured.evaluate(task,'B',caller,root)
        except ValueError:pass
        else:raise AssertionError('existing scientific prediction allowed regeneration')
        assert caller.calls==1
    write(BASE/'test_results.json',{'status':'PASS','paid_model_calls':0,'complete_original378_prompts_checked':378,
        'original_question_and_repair_identity':True,'model_input_allowlist':True,
        'reference_query_private_input_rejected':True,'actual_rel_prefix_visible':True,
        'synthetic_generation_and_readonly_typed_execution':True,'same_prediction_regeneration_rejected':True,
        'synthetic_db_unchanged':True,'human_expert_n':0})
    print(json.dumps({'status':'PASS','prompts':378,'paid_calls':0}))


if __name__=='__main__':test()
