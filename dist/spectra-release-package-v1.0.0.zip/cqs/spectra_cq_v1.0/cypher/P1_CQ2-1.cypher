// SpectraCQ P1_CQ2-1 — CQ2_Tdoc_relation_tracing
// Question (English): Return the revision history (predecessor/successor versions) of TDoc R1-2501234 (revision-lineage tracing).
// Schema area: classes=['Tdoc'], rels=['IS_REVISION_OF', 'REVISED_TO']

MATCH (t:Tdoc {tdocNumber: 'R1-2501234'}) OPTIONAL MATCH (t)-[:IS_REVISION_OF]->(prev:Tdoc) OPTIONAL MATCH (t)-[:REVISED_TO]->(next:Tdoc) RETURN prev.tdocNumber AS previous, t.tdocNumber AS current, t.title, next.tdocNumber AS revised_to ORDER BY t.tdocNumber ASC LIMIT 10
